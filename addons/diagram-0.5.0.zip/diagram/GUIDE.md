## Sơ đồ

Vẽ **sơ đồ hệ thống** bằng kéo thả (service, CSDL, hàng đợi, hệ thống ngoài..., lồng trong nhóm nhiều cấp), kể cả hệ
thống hàng nghìn khối. AI đọc sơ đồ theo từng phần và vẽ / sửa sơ đồ; mỗi thay đổi là một bản mới, khôi phục được bản cũ. Sơ đồ nhỏ dạng text
(**Mermaid**: flowchart, sequence, ER, state) vẫn dùng được.

### Vẽ sơ đồ hệ thống

- Bấm [icon:add] **Sơ đồ mới** rồi chọn loại: sơ đồ hệ thống (trống hoặc từ ví dụ) hoặc Mermaid (flowchart, sequence, ER, state).
- **Thêm khối**: kéo một biểu tượng ở thanh bên trái canvas vào chỗ muốn đặt (bấm biểu tượng thì khối hiện giữa màn
  hình). Thả vào trong một nhóm thì khối nằm trong nhóm đó.
- **Nối**: rê chuột lên khối, kéo từ chấm ở cạnh khối rồi thả lên khối khác (thả vào thân khối là được).
- **Sửa**: bấm khối hoặc cạnh, sửa ở cột bên phải: tên, loại, công nghệ, ghi chú (AI đọc được), nhãn và kiểu cạnh
  (gọi đồng bộ, message, đọc / ghi dữ liệu, phụ thuộc).
- **Nhóm**: kéo khối vào / ra khỏi nhóm; chọn nhiều khối (Shift + kéo vùng) rồi **Gom vào nhóm mới**. Nhóm lồng được nhiều cấp.
- **Xoá**: phím Delete. **Hoàn tác / làm lại**: Ctrl+Z / Ctrl+Shift+Z. **Lưu**: Ctrl+S.
- [icon:account_tree] **Tự sắp xếp** cả sơ đồ (hoặc chỉ trong nhóm đang mở riêng); [icon:swap_vert] đổi hướng
  trái → phải / trên → dưới.

### Hệ thống lớn

- **Thu gọn nhóm** ([icon:unfold_less] trên đầu nhóm, hoặc **Đóng lại** ở cột bên phải): nhóm thành một ô nhỏ, các
  cạnh bên trong được gộp thành một cạnh "×N"; các khối xung quanh dồn lại. **Mở tại chỗ** để bung ra (khối
  xung quanh được đẩy ra). Trạng thái thu gọn được lưu cùng sơ đồ. Sơ đồ trên 600 khối mở ra với các nhóm con đã thu gọn.
- **Mở riêng một nhóm** ([icon:open_in_full] trên đầu nhóm, nhấp đúp vào nhóm đang thu gọn, hoặc **Mở riêng** ở cột
  bên phải): chỉ vẽ bên trong nhóm đó; thanh đường dẫn phía trên để quay ra.
- **Tìm khối** ở cột bên phải: bấm kết quả để mở đúng nhóm và đưa tới khối đó.
- Thu nhỏ để xem tổng thể: chữ chi tiết ẩn đi, tên nhóm to lên. Bản đồ nhỏ ([icon:map]) ở góc dưới.
- [icon:open_in_full] **Toàn màn hình** (Esc để thoát).

### Lưu, lịch sử, import và xuất

- Mỗi lần lưu là một **bản mới**. [icon:history] **Lịch sử**: xem từng bản (tô màu khác biệt) và khôi phục.
  Sơ đồ hệ thống chỉ lưu phần thay đổi nên lịch sử không làm file phình to.
- Hai người cùng sửa: bản lưu sau bị từ chối nếu sơ đồ đã có bản mới hơn (tải lại rồi sửa tiếp).
- [icon:upload_file] **Import**:

| File | Thành |
|---|---|
| `.drawio` | Sơ đồ hệ thống sửa được, giữ vị trí và nhóm của draw.io (mỗi trang thành một nhóm) |
| `.json` (tải từ nút [icon:data_object]) | Sơ đồ hệ thống |
| `.mmd`, `.mermaid` (hoặc `.md` có khối mermaid) | Sơ đồ Mermaid, sửa và xem trước được |
| `.puml`, `.plantuml` | Lưu nguyên văn; AI đọc được, web không vẽ được hình PlantUML |

- Xuất sơ đồ hệ thống: [icon:data_object] **JSON**, [icon:content_copy] **Mermaid** (flowchart, để dán vào tài liệu).
  Sơ đồ Mermaid: **Copy Mermaid**, **SVG**, **PNG**.

### AI vẽ và sửa sơ đồ

Không có bước duyệt: thay đổi AI gửi được lưu ngay thành **bản mới** của sơ đồ (hoặc thành sơ đồ mới).

1. Sơ đồ có bản hiện tại do AI lưu được gắn nhãn [icon:smart_toy] **AI** trong danh sách và **AI lưu** khi mở ra.
2. Không đồng ý thì mở [icon:history] **Lịch sử**: bản do AI lưu có nhãn **AI** và ghi lý do. Chọn bản trước đó để xem
   khác biệt (sơ đồ hệ thống tô màu khối thêm / sửa) rồi bấm **Khôi phục bản này**. Mọi bản cũ vẫn được giữ.
3. Sửa tiếp trên bản AI lưu như sơ đồ bình thường, rồi [icon:save] **Lưu**.

### Tool cho AI

| Tool | Làm gì |
|---|---|
| `diagram_list` | Danh sách sơ đồ: id, tên, loại, số khối / cạnh, số bản, mô tả |
| `diagram_read` | Một sơ đồ: Mermaid / PlantUML nguyên văn; sơ đồ hệ thống nhỏ thì cả danh sách khối và cạnh, lớn thì bản tóm tắt |
| `diagram_outline` | Tóm tắt một cấp của sơ đồ hệ thống: các nhóm (bao nhiêu khối bên trong) và các liên kết giữa chúng; đi sâu từng nhóm |
| `diagram_nodes` | Danh sách khối theo trang: trong một nhóm, theo loại, hoặc theo từ khoá |
| `diagram_neighbors` | Một khối (hoặc nhóm) gọi / được gọi bởi những gì, đi xa 1-4 bước |
| `diagram_search` | Tìm sơ đồ và khối có chứa từ khoá, trên mọi sơ đồ |
| `diagram_propose` | Lưu sơ đồ mới hoặc thay đổi: sơ đồ hệ thống gửi từng thao tác thêm / sửa / xoá khối, cạnh; lưu ngay thành bản mới gắn nhãn AI |

### Dữ liệu cho addon khác
Addon khác (đã khai trong addon.json của nó) đọc được sơ đồ qua Viewer Hub, chỉ đọc (không sửa):

| Export | Trả về |
|---|---|
| `diagram_list` | Danh sách sơ đồ |
| `diagram_graph` | Node và cạnh của sơ đồ hệ thống (cả sơ đồ hoặc một nhóm) |
| `diagram_source` | Nội dung Mermaid / PlantUML |
