"""Addon "diagram" (managed, Python): system diagrams as data (graph: nodes in nested groups + edges, drawn on a
canvas, built for big systems) and small diagrams as text (Mermaid; PlantUML kept as is).

The page draws graphs with drag and drop (React Flow from the Hub, @vh/flow), edits Mermaid with a live preview,
imports .drawio (→ graph) / .json graph / .mmd / .puml and keeps every saved version (graphs keep patches only). The
AI reads big graphs in pieces (diagram_outline, diagram_nodes, diagram_neighbors) and changes them with
diagram_propose: small operations for graphs, full text for Mermaid. There is no review queue: the change is saved at
once as a version by "ai" (the page marks it; History restores an older version). Standard library only; writes only
under addon.data.

Exports (other addons read through the Hub, addon.json "exports"; read-only): diagram_list,
diagram_graph (nodes and edges of a system diagram, or of one group in it), diagram_source (Mermaid / PlantUML text).
"""
import json


import base64

from viewer_hub.addons.sdk import Addon, ApiError, ToolError, decode_text, int_arg

import diagram_store
import drawio
import graph_doc
from diagram_store import Store, StoreError, summary
from graph_doc import GraphError

addon = Addon(
    "diagram", title="Sơ đồ",
    instructions=(
        "Diagrams the user keeps in Viewer Hub. Most important are system diagrams (format graph): nodes (person, "
        "system, service, database, queue, ...) nested in groups, and edges between them; they can hold thousands of "
        "nodes, so read them in pieces: diagram_outline (top groups and the links between them, then one group with "
        "under=<id>), diagram_nodes (filtered, paged), diagram_neighbors (what a node or group talks to). Small "
        "diagrams are Mermaid text: diagram_read. diagram_search finds diagrams and nodes across all of them. To draw "
        "or change a system diagram call diagram_propose with ops (add_node, update_node, remove_node, add_edge, "
        "update_edge, remove_edge); positions are optional, the page lays new nodes out. The change is saved at once "
        "as a version marked AI; the user can restore the previous version."
    ),
)
store = Store(addon.data)


def _api(fn):
    """StoreError → ApiError (Vietnamese message for the page)."""
    def wrap(request):
        try:
            return fn(request)
        except StoreError as exc:
            raise ApiError(exc.code, exc.message, exc.status) from exc
    wrap.__name__ = fn.__name__
    return wrap


def _detail(diagram: dict) -> dict:
    current = diagram["versions"][-1]
    history = [{k: v.get(k) for k in ("v", "at", "by", "note", "summary")} for v in reversed(diagram["versions"])]
    if diagram["format"] == "graph":
        return summary(diagram) | {"graph": store.graph(diagram["id"]), "history": history}
    return summary(diagram) | {
        "content": current["content"],
        "preview": diagram["graph"]["mermaid"] if diagram.get("graph") else None,
        "graphText": diagram["graph"]["text"] if diagram.get("graph") else None,
        "history": [{k: v[k] for k in ("v", "at", "by", "note")} for v in reversed(diagram["versions"])],
    }


def _body(request) -> dict:
    return request.body if isinstance(request.body, dict) else {}


# ── page API ────────────────────────────────────────────────────────────────────────────────────────────────
@addon.get("/diagrams")
@_api
def list_diagrams(_request):
    return {"diagrams": [summary(d) for d in store.all()]}


@addon.post("/diagrams")
@_api
def create_diagram(request):
    body = _body(request)
    diagram = store.create(name=body.get("name"), description=body.get("description"), content=body.get("content"),
                           fmt=body.get("format") or "mermaid", note=body.get("note") or "", graph=body.get("graph"))
    return {"diagram": _detail(diagram)}


@addon.post("/import")
@_api
def import_file(request):
    body = _body(request)
    filename = str(body.get("filename") or "").strip()
    content = str(body.get("content") or "")
    if body.get("base64"):  # a file the page could not read as UTF-8 (Shift_JIS / EUC-JP .puml, .mmd…)
        try:
            content = decode_text(base64.b64decode(str(body["base64"]), validate=True), filename)[0]
        except ValueError:
            raise StoreError("bad_file", "File gửi lên bị hỏng") from None
    graph = None
    if filename.lower().endswith(".json"):
        try:
            graph = json.loads(content)
        except ValueError as exc:
            raise StoreError("bad_file", f"File JSON không đọc được: {exc}") from exc
        if isinstance(graph, dict) and isinstance(graph.get("graph"), dict):
            graph = graph["graph"]  # an exported diagram {name, description, graph}
        fmt = "graph"
    else:
        fmt = diagram_store.format_for(filename, content)
    if fmt == "drawio":   # draw.io → an editable system diagram, keeping its positions
        try:
            graph, fmt = drawio.as_graph(drawio.parse(content)), "graph"
        except drawio.DrawioError as exc:
            raise StoreError("bad_drawio", str(exc)) from exc
    if fmt == "mermaid" and filename.lower().endswith(".md"):
        content = diagram_store.clean_mermaid_md(content)
    stem = filename.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    for ext in (".drawio.xml", ".drawio", ".dio", ".json", ".mmd", ".mermaid", ".puml", ".plantuml", ".pu", ".iuml", ".wsd", ".md", ".txt"):
        if stem.lower().endswith(ext):
            stem = stem[: -len(ext)]
            break
    diagram = store.create(name=body.get("name") or stem or "Sơ đồ", description=body.get("description") or "",
                           content=None if fmt == "graph" else content, fmt=fmt, graph=graph, source=filename,
                           note=f"Import từ {filename}" if filename else "")
    return {"diagram": _detail(diagram)}


@addon.get("/diagrams/<diagram_id>")
@_api
def get_diagram(request):
    return {"diagram": _detail(store.get(request.params["diagram_id"]))}


@addon.put("/diagrams/<diagram_id>")
@_api
def save_diagram(request):
    body = _body(request)
    diagram = store.save(request.params["diagram_id"], content=body.get("content"), name=body.get("name"),
                         description=body.get("description"), note=body.get("note") or "", graph=body.get("graph"),
                         base_version=body.get("baseVersion"))
    return {"diagram": _detail(diagram)}


@addon.delete("/diagrams/<diagram_id>")
@_api
def delete_diagram(request):
    store.delete(request.params["diagram_id"])
    return {}


@addon.get("/diagrams/<diagram_id>/versions/<v>")
@_api
def get_version(request):
    diagram = store.get(request.params["diagram_id"])
    item = store.version(diagram, request.params["v"])
    return {"version": item}


@addon.post("/diagrams/<diagram_id>/versions/<v>/restore")
@_api
def restore_version(request):
    diagram = store.get(request.params["diagram_id"])
    item = store.version(diagram, request.params["v"])
    if diagram["format"] == "graph":
        diagram = store.save(diagram["id"], graph=item["graph"], note=f"Khôi phục bản {item['v']}")
    else:
        diagram = store.save(diagram["id"], content=item["content"], note=f"Khôi phục bản {item['v']}")
    return {"diagram": _detail(diagram)}


# ── MCP tools (for the AI) ──────────────────────────────────────────────────────────────────────────────────


def _find(key) -> dict:
    if not str(key or "").strip():
        raise ToolError("id is required (see diagram_list)")
    try:
        return store.find(key)
    except StoreError as exc:
        raise ToolError(exc.message) from exc


@addon.tool("diagram_list", "List the saved diagrams, one per line: id | name | type (format) | versions | description.")
def diagram_list(_arguments):
    items = store.all()
    if not items:
        return "No diagrams yet."
    lines = [f"{len(items)} diagram(s). id | name | type (format, size) | versions | description"]
    for d in items:
        ro = ", read-only" if d.get("readOnly") else ""
        size = f", {d['stats']['nodes']} nodes / {d['stats']['edges']} edges" if d.get("stats") else ""
        desc = (d.get("description") or "").replace("\n", " ")[:160]
        lines.append(f"{d['id']} | {d['name']} | {d['type']} ({d['format']}{ro}{size}) | v{d['versions'][-1]['v']} | {desc}")
    return "\n".join(lines)


@addon.tool(
    "diagram_read",
    "One diagram by id or name: Mermaid / PlantUML source as is; a system (graph) diagram as its full node and edge "
    "list when small (≤ 400 nodes), else its outline (then use diagram_outline / diagram_nodes / diagram_neighbors). "
    "Optional version number for an older saved version.",
    {"type": "object", "properties": {
        "id": {"type": "string", "description": "Diagram id (or exact name) from diagram_list"},
        "version": {"type": "integer", "description": "Saved version number; default the current one"},
    }, "required": ["id"]},
)
def diagram_read(arguments):
    diagram = _find(arguments.get("id"))
    if arguments.get("version") not in (None, ""):
        try:
            item = store.version(diagram, arguments.get("version"))
        except StoreError as exc:
            raise ToolError(exc.message) from exc
    else:
        item = diagram["versions"][-1]
    head = (f"# {diagram['name']} ({diagram['type']}, {diagram['format']}, version {item['v']} of "
            f"{diagram['versions'][-1]['v']}, saved {item['at']})")
    if diagram.get("description"):
        head += f"\n# {diagram['description']}"
    if diagram["format"] == "graph":
        doc = item["graph"] if "graph" in item else store.graph(diagram["id"])
        if len(doc["nodes"]) <= 400:
            return f"{head}\n\n{graph_doc.full_text(doc)}"
        return (f"{head}\n# {len(doc['nodes'])} nodes, {len(doc['edges'])} edges: too big to list at once. Outline below; "
                f"drill down with diagram_outline(under=...), diagram_nodes, diagram_neighbors.\n\n{graph_doc.outline(doc, depth=1)}")
    if diagram.get("graph"):
        return f"{head}\n# draw.io import (read-only): nodes and edges\n\n{diagram['graph']['text']}"
    return f"{head}\n\n{item['content']}"


def _graph_of(arguments) -> tuple[dict, dict]:
    diagram = _find(arguments.get("id"))
    if diagram["format"] != "graph":
        raise ToolError(f"{diagram['id']} is a {diagram['format']} diagram, not a system diagram: use diagram_read")
    return diagram, store.graph(diagram["id"])


def _graph_tool(fn):
    def wrap(arguments):
        try:
            return fn(arguments)
        except GraphError as exc:
            raise ToolError(str(exc)) from exc
    wrap.__name__ = fn.__name__
    return wrap


@addon.tool(
    "diagram_outline",
    "Overview of a system diagram: the items at one level (default the top; under=<group id> for inside a group) with "
    "how many nodes each group holds, nested `depth` levels, plus the links between those items (edges between "
    "everything inside them, summed). Start here for a big diagram and drill down.",
    {"type": "object", "properties": {
        "id": {"type": "string", "description": "Diagram id (or exact name)"},
        "under": {"type": "string", "description": "Group node id to look inside; omit for the top level"},
        "depth": {"type": "integer", "description": "Levels of groups to expand (default 1, max 4)"},
        "limit": {"type": "integer", "description": "Max lines per section (default 200, max 1000)"},
    }, "required": ["id"]},
)
@_graph_tool
def diagram_outline(arguments):
    diagram, doc = _graph_of(arguments)
    head = f"# {diagram['name']} (v{diagram['versions'][-1]['v']}, {len(doc['nodes'])} nodes, {len(doc['edges'])} edges)"
    return head + "\n" + graph_doc.outline(doc, str(arguments.get("under") or ""), int_arg(arguments, "depth", 1, 1, 4),
                                           int_arg(arguments, "limit", 200, 10, 1000))


@addon.tool(
    "diagram_nodes",
    "Nodes of a system diagram, paged: all, or only those inside a group (all levels), of one kind, or matching words "
    "in id / label / note / tech. Each line: id | kind | label | parent | size (groups) or out/in edge counts.",
    {"type": "object", "properties": {
        "id": {"type": "string", "description": "Diagram id (or exact name)"},
        "under": {"type": "string", "description": "Group node id: only nodes inside it"},
        "query": {"type": "string", "description": "Words that must all appear"},
        "kind": {"type": "string", "enum": list(graph_doc.NODE_KINDS)},
        "offset": {"type": "integer", "description": "Skip this many (paging)"},
        "limit": {"type": "integer", "description": "Max nodes (default 100, max 500)"},
    }, "required": ["id"]},
)
@_graph_tool
def diagram_nodes(arguments):
    _diagram, doc = _graph_of(arguments)
    return graph_doc.node_page(doc, str(arguments.get("under") or ""), str(arguments.get("query") or ""),
                               str(arguments.get("kind") or ""), int_arg(arguments, "offset", 0, 0, 10**6),
                               int_arg(arguments, "limit", 100, 1, 500))


@addon.tool(
    "diagram_neighbors",
    "The edges around one node of a system diagram (for a group: the edges of everything inside it to the outside), "
    "1-4 steps out, and the nodes at the other ends. Use it to answer what calls / uses / depends on what.",
    {"type": "object", "properties": {
        "id": {"type": "string", "description": "Diagram id (or exact name)"},
        "node": {"type": "string", "description": "Node id"},
        "depth": {"type": "integer", "description": "Steps (default 1, max 4)"},
        "direction": {"type": "string", "enum": ["both", "out", "in"], "description": "out: what it calls; in: what calls it"},
        "limit": {"type": "integer", "description": "Max edges (default 200, max 1000)"},
    }, "required": ["id", "node"]},
)
@_graph_tool
def diagram_neighbors(arguments):
    _diagram, doc = _graph_of(arguments)
    direction = str(arguments.get("direction") or "both")
    if direction not in ("both", "out", "in"):
        raise ToolError("direction: both, out or in")
    return graph_doc.neighbors(doc, str(arguments.get("node") or ""), int_arg(arguments, "depth", 1, 1, 4), direction,
                               int_arg(arguments, "limit", 200, 1, 1000))


@addon.tool(
    "diagram_search",
    "Find diagrams containing a node name or keywords (all words must appear). Returns matching diagrams with the "
    "matching source lines.",
    {"type": "object", "properties": {
        "query": {"type": "string", "description": "Node label, id or keywords"},
        "limit": {"type": "integer", "description": "Max diagrams (default 10, max 50)"},
    }, "required": ["query"]},
)
def diagram_search(arguments):
    query = str(arguments.get("query") or "").strip()
    if not query:
        raise ToolError("query is required")
    hits = store.search(query, int_arg(arguments, "limit", 10, 1, 50))
    if not hits:
        return f"No diagram contains {query!r}."
    out = []
    for hit in hits:
        d = hit["diagram"]
        out.append(f"## {d['id']} | {d['name']} | {d['type']} ({d['format']})")
        out.extend(f"  {line[:200]}" for line in hit["lines"])
        if hit["more"]:
            out.append(f"  … {hit['more']} more matching line(s)")
    return "\n".join(out)


OPS_HELP = (
    "System diagram operations, applied in order: "
    '{"op":"add_node","id":"order-svc","label":"Order service","kind":"service","parent":"orders","tech":"Java",'
    '"note":"..."} (kind: ' + ", ".join(graph_doc.NODE_KINDS) + '; parent: a group node id; a node becomes a group '
    'when others name it as parent; id: A-Z a-z 0-9 _ . : -); {"op":"update_node","id":"...", any of label/kind/'
    'parent/note/tech}; {"op":"remove_node","id":"..."} (its children move up, its edges go); '
    '{"op":"add_edge","from":"a","to":"b","label":"REST /orders","kind":"sync|async|data|dependency"}; '
    '{"op":"update_edge","id":"e12","label":"..."}; {"op":"remove_edge","id":"e12"} (or from + to). '
    "Omit x / y: the page lays out new nodes."
)


@addon.tool(
    "diagram_propose",
    "Save a new diagram, or a change to an existing one (pass its id). It is saved at once as a new version marked "
    "as written by AI; the user sees it on the Diagram page and can restore the previous version from its history. "
    "System diagrams (graph): send `ops`, only the changes (for a new system diagram: add_node / add_edge for "
    "everything). Mermaid diagrams: send the complete Mermaid text as `content`. " + OPS_HELP,
    {"type": "object", "properties": {
        "ops": {"type": "array", "items": {"type": "object"}, "description": "System diagram operations (see the tool description)"},
        "content": {"type": "string", "description": "Full Mermaid source (Mermaid diagrams only)"},
        "id": {"type": "string", "description": "Existing diagram id to change; omit for a new diagram"},
        "name": {"type": "string", "description": "Name (required for a new diagram)"},
        "description": {"type": "string", "description": "One line: what the diagram shows (new diagram)"},
        "reason": {"type": "string", "description": "Why / what changed, kept as the version's note"},
    }},
)
def diagram_propose(arguments):
    ops = arguments.get("ops")
    if ops is None:
        if not str(arguments.get("content") or "").strip():
            raise ToolError("Send ops (system diagram) or content (Mermaid).")
        if str(arguments.get("content") or "").lstrip().startswith(("<mxfile", "@startuml")):
            raise ToolError("Send Mermaid text only.")
    try:
        diagram, changed = store.ai_write(content=arguments.get("content"), ops=ops, name=arguments.get("name") or "",
                                          description=arguments.get("description") or "",
                                          target=arguments.get("id") or "", reason=arguments.get("reason") or "")
    except StoreError as exc:
        if exc.code == "conflict":
            raise ToolError("The diagram changed while saving: read it again and resend the change.") from exc
        raise ToolError(exc.message) from exc
    version = diagram["versions"][-1]["v"]
    size = f", {diagram['stats']['nodes']} nodes, {diagram['stats']['edges']} edges" if diagram.get("stats") else ""
    if not changed:
        return f"No change: {diagram['id']} already matches (version {version}{size})."
    what = "Saved a new diagram" if version == 1 else f"Saved version {version} of"
    return (f"{what} {diagram['id']} ({diagram['name']}{size}). It is in use now, marked as written by AI; "
            f"the user can restore the previous version from its history on the Diagram page.")


# ── exports: what other addons may read (addon.json "exports") ─────────────────────────────────────────────
NODE_KEYS = ("id", "label", "kind", "parent", "tech", "note")
EDGE_KEYS = ("id", "from", "to", "label", "kind")
MAX_EXPORT_NODES = 20000


def _diagram_of(params) -> dict:
    try:
        return store.find(params.get("id"))
    except StoreError as exc:
        raise ApiError(exc.code, exc.message, exc.status) from exc


@addon.export("diagram_list")
def export_list(_params):
    out = []
    for d in store.all():
        item = {"id": d["id"], "name": d["name"], "description": d.get("description") or "", "format": d["format"],
                "type": d.get("type") or "", "version": d["versions"][-1]["v"], "updated": d.get("updated") or ""}
        if d.get("stats"):
            item |= {"nodes": d["stats"]["nodes"], "edges": d["stats"]["edges"]}
        out.append(item)
    return {"diagrams": out}


@addon.export("diagram_graph")
def export_graph(params):
    diagram = _diagram_of(params)
    if diagram["format"] != "graph":
        raise ApiError("not_graph", f"{diagram['id']} là sơ đồ {diagram['format']}: dùng diagram_source", 400)
    doc = store.graph(diagram["id"])
    nodes = doc["nodes"]
    under = str(params.get("under") or "").strip()
    if under:
        parent = {n["id"]: n.get("parent") for n in nodes}
        if under not in parent:
            raise ApiError("not_found", f"Không có node / nhóm {under!r} trong {diagram['id']}", 404)

        def inside(node_id):
            seen = set()
            while node_id and node_id not in seen:
                if node_id == under:
                    return True
                seen.add(node_id)
                node_id = parent.get(node_id)
            return False
        nodes = [n for n in nodes if n["id"] != under and inside(n["id"])]
    limit = int_arg(params, "limit", 2000, 1, MAX_EXPORT_NODES)
    kept = nodes[:limit]
    ids = {n["id"] for n in kept}
    edges = [e for e in doc["edges"] if e["from"] in ids and e["to"] in ids]
    return {"id": diagram["id"], "name": diagram["name"], "version": diagram["versions"][-1]["v"],
            "total_nodes": len(nodes), "truncated": len(nodes) > len(kept),
            "nodes": [{k: n[k] for k in NODE_KEYS if n.get(k) not in (None, "")} for n in kept],
            "edges": [{k: e[k] for k in EDGE_KEYS if e.get(k) not in (None, "")} for e in edges]}


@addon.export("diagram_source")
def export_source(params):
    diagram = _diagram_of(params)
    if diagram["format"] == "graph":
        raise ApiError("is_graph", f"{diagram['id']} là sơ đồ hệ thống: dùng diagram_graph", 400)
    item = diagram["versions"][-1]
    content = item.get("content")
    if content is None and diagram.get("graph"):
        content = diagram["graph"].get("text", "")
    return {"id": diagram["id"], "name": diagram["name"], "format": diagram["format"], "version": item["v"],
            "content": content or ""}


if __name__ == "__main__":
    addon.run()
