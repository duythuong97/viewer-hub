"""System diagrams as data (format "graph"): nodes nested in groups, and edges. Made for big systems: the page draws
them on a canvas (React Flow), the AI reads them in pieces (outline, filtered node pages, neighbours) and changes them
with small operations instead of rewriting the whole text.

    {"direction": "LR" | "TB",
     "nodes": [{"id", "label", "kind", "parent"?, "note"?, "tech"?, "x"?, "y"?, "w"?, "h"?, "folded"?}],
     "edges": [{"id", "from", "to", "label"?, "kind"?}]}

x / y are relative to the parent's top-left (missing: the page lays the node out). A node with children is a group;
folded: true draws it closed (its w / h stay its open size).

Two kinds of operations:
- AI operations (apply_ai_ops): add_node / update_node / remove_node / add_edge / update_edge / remove_edge, the way
  an AI describes a change. remove_node keeps the children (they move up to its parent) and drops its edges.
- Patches (diff / apply_patch / invert): what changed between two saved versions, with the old values, so history
  keeps only changes and any version can be rebuilt from the current one.
Standard library only.
"""
from __future__ import annotations

import math
import re
from collections import defaultdict

from viewer_hub.addons.sdk import fold  # case and half / full width: ｶﾅ = カナ, ＡＢＣ = ABC

MAX_NODES = 20_000
MAX_EDGES = 60_000
NODE_KINDS = ("person", "system", "external", "app", "service", "component", "database", "queue", "storage", "job",
              "group", "note")
EDGE_KINDS = ("sync", "async", "data", "dependency")
NODE_FIELDS = ("label", "kind", "parent", "note", "tech", "x", "y", "w", "h", "folded")
EDGE_FIELDS = ("from", "to", "label", "kind")
ID = re.compile(r"[A-Za-z0-9_.:\-]{1,80}")
TEXT_LIMITS = {"label": 200, "note": 2000, "tech": 120}


class GraphError(ValueError):
    pass


# ── normalising (everything that enters the store goes through here) ──────────────────────────────────────────
def _text(value, limit: int) -> str:
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(value or "")).strip()[:limit]


def _num(value, low: float, high: float):
    if value is None or value == "":
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(number):
        return None
    return round(min(high, max(low, number)), 1)


def _node(raw: dict, where: str) -> dict:
    if not isinstance(raw, dict):
        raise GraphError(f"{where}: node must be an object")
    node_id = str(raw.get("id") or "").strip()
    if not ID.fullmatch(node_id):
        raise GraphError(f"{where}: node id {node_id!r} must be 1-80 of A-Z a-z 0-9 _ . : -")
    kind = str(raw.get("kind") or "component").strip().lower()
    node = {"id": node_id, "label": _text(raw.get("label"), TEXT_LIMITS["label"]) or node_id,
            "kind": kind if kind in NODE_KINDS else "component"}
    parent = str(raw.get("parent") or "").strip()
    if parent:
        node["parent"] = parent
    for key in ("note", "tech"):
        text = _text(raw.get(key), TEXT_LIMITS[key])
        if text:
            node[key] = text
    if raw.get("folded") is True:
        node["folded"] = True
    for key, low, high in (("x", -1e7, 1e7), ("y", -1e7, 1e7), ("w", 20, 200_000), ("h", 20, 200_000)):
        number = _num(raw.get(key), low, high)
        if number is not None:
            node[key] = number
    return node


def _edge(raw: dict, where: str) -> dict:
    if not isinstance(raw, dict):
        raise GraphError(f"{where}: edge must be an object")
    edge_id = str(raw.get("id") or "").strip()
    if not ID.fullmatch(edge_id):
        raise GraphError(f"{where}: edge id {edge_id!r} must be 1-80 of A-Z a-z 0-9 _ . : -")
    edge = {"id": edge_id, "from": str(raw.get("from") or "").strip(), "to": str(raw.get("to") or "").strip()}
    label = _text(raw.get("label"), TEXT_LIMITS["label"])
    if label:
        edge["label"] = label
    kind = str(raw.get("kind") or "").strip().lower()
    if kind in EDGE_KINDS and kind != "sync":
        edge["kind"] = kind
    return edge


def normalize(raw) -> dict:
    """Checked, cleaned copy of a graph (ids unique, parents and edge ends exist, no parent loops)."""
    if not isinstance(raw, dict):
        raise GraphError("Sơ đồ phải là object {nodes, edges}")
    nodes_in, edges_in = raw.get("nodes") or [], raw.get("edges") or []
    if not isinstance(nodes_in, list) or not isinstance(edges_in, list):
        raise GraphError("nodes và edges phải là danh sách")
    if len(nodes_in) > MAX_NODES:
        raise GraphError(f"Sơ đồ quá lớn (tối đa {MAX_NODES} node)")
    if len(edges_in) > MAX_EDGES:
        raise GraphError(f"Sơ đồ quá lớn (tối đa {MAX_EDGES} cạnh)")
    nodes: dict[str, dict] = {}
    for i, raw_node in enumerate(nodes_in):
        node = _node(raw_node, f"node #{i + 1}")
        if node["id"] in nodes:
            raise GraphError(f"Trùng id node {node['id']!r}")
        nodes[node["id"]] = node
    for node in nodes.values():
        if node.get("parent") and node["parent"] not in nodes:
            raise GraphError(f"Node {node['id']!r}: không có nhóm cha {node['parent']!r}")
    _check_loops(nodes)
    edges: dict[str, dict] = {}
    for i, raw_edge in enumerate(edges_in):
        edge = _edge(raw_edge, f"edge #{i + 1}")
        if edge["id"] in edges:
            raise GraphError(f"Trùng id cạnh {edge['id']!r}")
        for end in ("from", "to"):
            if edge[end] not in nodes:
                raise GraphError(f"Cạnh {edge['id']!r}: không có node {edge[end]!r}")
        edges[edge["id"]] = edge
    direction = "TB" if str(raw.get("direction") or "").upper() == "TB" else "LR"
    return {"direction": direction, "nodes": list(nodes.values()), "edges": list(edges.values())}


def _check_loops(nodes: dict[str, dict]) -> None:
    done: set[str] = set()
    for start in nodes:
        path, cur = [], start
        while cur and cur not in done:
            if cur in path:
                raise GraphError(f"Node {cur!r} nằm trong chính nó (vòng lặp nhóm cha)")
            path.append(cur)
            cur = nodes[cur].get("parent", "")
        done.update(path)


def empty() -> dict:
    return {"direction": "LR", "nodes": [], "edges": []}


def stats(doc: dict) -> dict:
    groups = {n.get("parent") for n in doc["nodes"] if n.get("parent")}
    return {"nodes": len(doc["nodes"]), "edges": len(doc["edges"]), "groups": len(groups)}


# ── AI operations ───────────────────────────────────────────────────────────────────────────────────────────────
AI_OPS = ("add_node", "update_node", "remove_node", "add_edge", "update_edge", "remove_edge")


def apply_ai_ops(doc: dict, ops) -> tuple[dict, dict]:
    """doc + the AI's operations → (new normalised doc, counts). Raises GraphError naming the failing operation."""
    if not isinstance(ops, list) or not ops:
        raise GraphError("ops must be a non-empty list of operations")
    if len(ops) > 5000:
        raise GraphError("At most 5000 operations per proposal; split the change into several proposals")
    nodes = {n["id"]: dict(n) for n in doc["nodes"]}
    edges = {e["id"]: dict(e) for e in doc["edges"]}
    counts: dict[str, int] = defaultdict(int)
    next_edge = [len(edges) + 1]

    def edge_id() -> str:
        while f"e{next_edge[0]}" in edges:
            next_edge[0] += 1
        return f"e{next_edge[0]}"

    for i, op in enumerate(ops, 1):
        where = f"op #{i}"
        if not isinstance(op, dict):
            raise GraphError(f"{where}: must be an object")
        kind = str(op.get("op") or "")
        where = f"op #{i} ({kind or '?'})"
        if kind == "add_node":
            node = _node(op, where)
            if node["id"] in nodes:
                raise GraphError(f"{where}: node {node['id']!r} already exists (use update_node)")
            nodes[node["id"]] = node
        elif kind == "update_node":
            node_id = str(op.get("id") or "")
            if node_id not in nodes:
                raise GraphError(f"{where}: no node {node_id!r}")
            merged = dict(nodes[node_id])
            for key in NODE_FIELDS:
                if key in op:
                    if op[key] in (None, "", False) and key in ("parent", "note", "tech", "x", "y", "w", "h", "folded"):
                        merged.pop(key, None)
                    else:
                        merged[key] = op[key]
            nodes[node_id] = _node(merged, where)
        elif kind == "remove_node":
            node_id = str(op.get("id") or "")
            if node_id not in nodes:
                raise GraphError(f"{where}: no node {node_id!r}")
            parent = nodes[node_id].get("parent")
            for child in nodes.values():
                if child.get("parent") == node_id:
                    if parent:
                        child["parent"] = parent
                    else:
                        child.pop("parent", None)
                    child.pop("x", None)
                    child.pop("y", None)
            del nodes[node_id]
            for eid in [k for k, e in edges.items() if node_id in (e["from"], e["to"])]:
                del edges[eid]
        elif kind == "add_edge":
            raw = dict(op)
            raw["id"] = str(op.get("id") or "") or edge_id()
            edge = _edge(raw, where)
            if edge["id"] in edges:
                raise GraphError(f"{where}: edge {edge['id']!r} already exists")
            edges[edge["id"]] = edge
        elif kind in ("update_edge", "remove_edge"):
            eid = str(op.get("id") or "")
            if not eid and op.get("from") and op.get("to"):
                found = [k for k, e in edges.items() if e["from"] == op["from"] and e["to"] == op["to"]]
                if len(found) != 1:
                    raise GraphError(f"{where}: {len(found)} edges {op['from']} -> {op['to']}; pass the edge id")
                eid = found[0]
            if eid not in edges:
                raise GraphError(f"{where}: no edge {eid!r}")
            if kind == "remove_edge":
                del edges[eid]
            else:
                merged = dict(edges[eid])
                for key in ("label", "kind"):
                    if key in op:
                        merged[key] = op[key]
                edges[eid] = _edge(merged, where)
        else:
            raise GraphError(f"op #{i}: unknown op {kind!r}; use one of {', '.join(AI_OPS)}")
        counts[kind] += 1
    direction = doc.get("direction", "LR")
    try:
        result = normalize({"direction": direction, "nodes": list(nodes.values()), "edges": list(edges.values())})
    except GraphError as exc:
        raise GraphError(f"After the operations: {exc}") from exc
    return result, dict(counts)


# ── patches (history) ───────────────────────────────────────────────────────────────────────────────────────────
def diff(old: dict, new: dict) -> list[dict]:
    """The patch old → new: [{t: "n+"|"n-"|"n~"|"e+"|"e-"|"e~"|"d~", ...}] with old values (invertible)."""
    patch: list[dict] = []
    if old.get("direction", "LR") != new.get("direction", "LR"):
        patch.append({"t": "d~", "from": old.get("direction", "LR"), "to": new.get("direction", "LR")})
    for kind, fields, key in (("n", NODE_FIELDS, "nodes"), ("e", EDGE_FIELDS, "edges")):
        before = {x["id"]: x for x in old[key]}
        after = {x["id"]: x for x in new[key]}
        for item_id, item in before.items():
            if item_id not in after:
                patch.append({"t": f"{kind}-", "item": item})
        for item_id, item in after.items():
            prev = before.get(item_id)
            if prev is None:
                patch.append({"t": f"{kind}+", "item": item})
                continue
            changed = [f for f in fields if prev.get(f) != item.get(f)]
            if changed:
                patch.append({"t": f"{kind}~", "id": item_id, "from": {f: prev.get(f) for f in changed},
                              "to": {f: item.get(f) for f in changed}})
    return patch


def invert(patch: list[dict]) -> list[dict]:
    flip = {"n+": "n-", "n-": "n+", "e+": "e-", "e-": "e+"}
    out = []
    for step in reversed(patch):
        t = step["t"]
        if t in flip:
            out.append({"t": flip[t], "item": step["item"]})
        else:
            out.append({**step, "from": step["to"], "to": step["from"]})
    return out


def apply_patch(doc: dict, patch: list[dict]) -> dict:
    nodes = {n["id"]: dict(n) for n in doc["nodes"]}
    edges = {e["id"]: dict(e) for e in doc["edges"]}
    direction = doc.get("direction", "LR")
    for step in patch:
        t = step["t"]
        if t == "d~":
            direction = step["to"]
            continue
        table = nodes if t[0] == "n" else edges
        if t[1] == "+":
            table[step["item"]["id"]] = dict(step["item"])
        elif t[1] == "-":
            table.pop(step["item"]["id"], None)
        elif step["id"] in table:
            item = table[step["id"]]
            for field, value in step["to"].items():
                if value is None:
                    item.pop(field, None)
                else:
                    item[field] = value
    return {"direction": direction, "nodes": list(nodes.values()), "edges": list(edges.values())}


def patch_summary(patch: list[dict]) -> str:
    counts: dict[str, int] = defaultdict(int)
    moved = 0
    for step in patch:
        if step["t"] == "n~" and set(step["to"]) <= {"x", "y", "w", "h", "folded"}:
            moved += 1
        else:
            counts[step["t"]] += 1
    names = {"n+": "thêm {} node", "n-": "xoá {} node", "n~": "sửa {} node", "e+": "thêm {} cạnh", "e-": "xoá {} cạnh",
             "e~": "sửa {} cạnh", "d~": "đổi hướng"}
    parts = [names[t].format(n) for t, n in counts.items()]
    if moved:
        parts.append(f"dời {moved} node")
    return ", ".join(parts) or "không đổi"


# ── reading (AI tools) ──────────────────────────────────────────────────────────────────────────────────────────
class View:
    """Indexes over one doc for the read tools."""

    def __init__(self, doc: dict):
        self.doc = doc
        self.nodes = {n["id"]: n for n in doc["nodes"]}
        self.children: dict[str, list[str]] = defaultdict(list)
        for n in doc["nodes"]:
            self.children[n.get("parent", "")].append(n["id"])
        self.out: dict[str, list[dict]] = defaultdict(list)
        self.inc: dict[str, list[dict]] = defaultdict(list)
        for e in doc["edges"]:
            self.out[e["from"]].append(e)
            self.inc[e["to"]].append(e)
        self._size: dict[str, int] = {}

    def size(self, node_id: str) -> int:
        """Number of nodes inside (all levels)."""
        if node_id not in self._size:
            total, stack = 0, list(self.children.get(node_id, []))
            while stack:
                cur = stack.pop()
                total += 1
                stack.extend(self.children.get(cur, []))
            self._size[node_id] = total
        return self._size[node_id]

    def path(self, node_id: str) -> list[str]:
        out, cur = [], self.nodes[node_id].get("parent", "")
        while cur:
            out.append(cur)
            cur = self.nodes[cur].get("parent", "")
        return list(reversed(out))

    def under(self, root: str) -> list[str]:
        """Every node inside root ("" = all), depth first."""
        out, stack = [], list(reversed(self.children.get(root, [])))
        while stack:
            cur = stack.pop()
            out.append(cur)
            stack.extend(reversed(self.children.get(cur, [])))
        return out

    def name(self, node_id: str) -> str:
        node = self.nodes.get(node_id)
        return f"{node_id} \"{node['label']}\"" if node and node["label"] != node_id else node_id

    def line(self, node_id: str) -> str:
        n = self.nodes[node_id]
        bits = [n["id"], n["kind"], n["label"]]
        bits.append(f"in {n['parent']}" if n.get("parent") else "top level")
        inside = self.size(node_id)
        bits.append(f"{inside} inside" if inside else f"out {len(self.out[node_id])} / in {len(self.inc[node_id])}")
        if n.get("tech"):
            bits.append(f"tech: {n['tech']}")
        text = " | ".join(bits)
        if n.get("note"):
            text += " | note: " + n["note"].replace("\n", " ")[:160]
        return text

    def edge_line(self, e: dict) -> str:
        label = f" [{e['label']}]" if e.get("label") else ""
        kind = f" ({e['kind']})" if e.get("kind") else ""
        return f"{e['id']}: {self.name(e['from'])} -> {self.name(e['to'])}{label}{kind}"

    def top_under(self, node_id: str, root: str) -> str | None:
        """The child of root that holds node_id (node_id itself if it is one); None when outside root."""
        cur = node_id
        while cur:
            parent = self.nodes[cur].get("parent", "")
            if parent == root:
                return cur
            cur = parent
        return None


def outline(doc: dict, under: str = "", depth: int = 1, limit: int = 300) -> str:
    """The tree of groups (to `depth` levels) with sizes, and the links between the top items (aggregated)."""
    view = View(doc)
    if under and under not in view.nodes:
        raise GraphError(f"No node {under!r}")
    lines: list[str] = []
    stack = [(cid, 0) for cid in reversed(view.children.get(under, []))]
    shown = 0
    while stack:
        cur, level = stack.pop()
        if shown >= limit:
            lines.append(f"… more (raise limit, or outline one group with under=<id>)")
            break
        lines.append("  " * level + "- " + view.line(cur))
        shown += 1
        if level + 1 < depth:
            stack.extend((cid, level + 1) for cid in reversed(view.children.get(cur, [])))
    links: dict[tuple[str, str], list[dict]] = defaultdict(list)
    outside = 0
    for e in doc["edges"]:
        a, b = view.top_under(e["from"], under), view.top_under(e["to"], under)
        if a and b and a != b:
            links[(a, b)].append(e)
        elif (a is None) != (b is None):
            outside += 1
    head = f"{len(view.children.get(under, []))} item(s) {'inside ' + view.name(under) if under else 'at the top level'}"
    out = [head + " (id | kind | label | parent | size or degree):", *lines]
    if links:
        out.append(f"\nLinks between these items ({len(links)}, each line sums the edges inside them):")
        ranked = sorted(links.items(), key=lambda kv: -len(kv[1]))
        for (a, b), items in ranked[:limit]:
            labels = sorted({e["label"] for e in items if e.get("label")})[:4]
            extra = f" [{', '.join(labels)}]" if labels else ""
            out.append(f"- {view.name(a)} -> {view.name(b)} ×{len(items)}{extra}")
        if len(ranked) > limit:
            out.append(f"… {len(ranked) - limit} more links")
    if outside:
        out.append(f"\n{outside} edge(s) cross the boundary of {under}.")
    return "\n".join(out)


def node_page(doc: dict, under: str = "", query: str = "", kind: str = "", offset: int = 0, limit: int = 100) -> str:
    view = View(doc)
    if under and under not in view.nodes:
        raise GraphError(f"No node {under!r}")
    words = [w for w in fold(query).split() if w]
    picked = []
    for node_id in view.under(under):
        n = view.nodes[node_id]
        if kind and n["kind"] != kind:
            continue
        if words:
            text = fold(f"{n['id']} {n['label']} {n.get('note', '')} {n.get('tech', '')}")
            if not all(w in text for w in words):
                continue
        picked.append(node_id)
    page = picked[offset: offset + limit]
    out = [f"{len(picked)} node(s){' inside ' + view.name(under) if under else ''}"
           f"{' matching ' + repr(query) if query else ''}{' of kind ' + kind if kind else ''}; "
           f"showing {offset + 1 if page else 0}-{offset + len(page)} (id | kind | label | parent | size or degree):"]
    out.extend("- " + view.line(node_id) for node_id in page)
    if offset + len(page) < len(picked):
        out.append(f"… next page: offset={offset + len(page)}")
    return "\n".join(out)


def neighbors(doc: dict, node_id: str, depth: int = 1, direction: str = "both", limit: int = 200) -> str:
    view = View(doc)
    if node_id not in view.nodes:
        raise GraphError(f"No node {node_id!r} (find ids with diagram_nodes)")
    inside = set(view.under(node_id)) | {node_id}  # a group: its own edges and its children's
    seen = set(inside)
    frontier = set(inside)
    edges: list[dict] = []
    for _ in range(max(1, min(depth, 4))):
        nxt = set()
        for cur in frontier:
            if direction in ("both", "out"):
                for e in view.out[cur]:
                    edges.append(e)
                    if e["to"] not in seen:
                        nxt.add(e["to"])
            if direction in ("both", "in"):
                for e in view.inc[cur]:
                    edges.append(e)
                    if e["from"] not in seen:
                        nxt.add(e["from"])
        seen |= nxt
        frontier = nxt
        if len(edges) > limit * 4:
            break
    unique = list({e["id"]: e for e in edges if not (e["from"] in inside and e["to"] in inside)}.values())
    out = [view.line(node_id)]
    if view.nodes[node_id].get("parent"):
        out.append("path: " + " > ".join(view.name(p) for p in view.path(node_id)))
    out.append(f"{len(unique)} edge(s) within {depth} step(s), direction {direction}:")
    out.extend("- " + view.edge_line(e) for e in unique[:limit])
    if len(unique) > limit:
        out.append(f"… {len(unique) - limit} more (lower depth or raise limit)")
    others = sorted({x for e in unique[:limit] for x in (e["from"], e["to"])} - inside)
    if others:
        out.append("\nNodes on the other ends:")
        out.extend("- " + view.line(x) for x in others[:limit])
    return "\n".join(out)


def full_text(doc: dict) -> str:
    """Whole graph as lines (small graphs only)."""
    view = View(doc)
    out = [f"direction {doc.get('direction', 'LR')}", f"Nodes ({len(doc['nodes'])}) id | kind | label | parent | size or degree:"]
    out.extend("- " + view.line(node_id) for node_id in view.under(""))
    out.append(f"Edges ({len(doc['edges'])}):")
    out.extend("- " + view.edge_line(e) for e in doc["edges"])
    return "\n".join(out)


def search_lines(doc: dict, words: list[str], limit: int = 8) -> tuple[list[str], int]:
    view = View(doc)
    hits = []
    for n in doc["nodes"]:
        text = fold(f"{n['id']} {n['label']} {n.get('note', '')} {n.get('tech', '')}")
        if any(w in text for w in words):
            hits.append("node " + view.line(n["id"]))
    for e in doc["edges"]:
        if e.get("label") and any(w in fold(e["label"]) for w in words):
            hits.append("edge " + view.edge_line(e))
    return hits[:limit], max(0, len(hits) - limit)


def haystack(doc: dict) -> str:
    parts = [f"{n['id']} {n['label']} {n.get('note', '')} {n.get('tech', '')}" for n in doc["nodes"]]
    parts += [e.get("label", "") for e in doc["edges"]]
    return fold("\n".join(parts))
