"""Read-only import of draw.io / diagrams.net files: pages → nodes and edges (no layout, no styles).

A .drawio file is an <mxfile> with one <diagram> per page. A page holds either a plain <mxGraphModel> or, in
older / compressed files, its XML deflated + base64-encoded (+ URL-encoded). Each <mxCell vertex="1"> is a node,
each <mxCell edge="1"> an edge (source → target). Labels may be HTML: tags are dropped, entities decoded.
"""
from __future__ import annotations

import base64
import html
import re
import zlib
from urllib.parse import unquote
from xml.etree import ElementTree

MAX_CELLS = 20000


class DrawioError(ValueError):
    pass


def _text(label: str) -> str:
    """Plain text of a (possibly HTML) draw.io label."""
    if not label:
        return ""
    text = re.sub(r"<br\s*/?>|</(div|p|li)>", "\n", label, flags=re.I)
    text = re.sub(r"<[^>]*>", "", text)
    text = html.unescape(text).replace("\xa0", " ")
    return "\n".join(line.strip() for line in text.splitlines() if line.strip())


def _model(diagram: ElementTree.Element) -> ElementTree.Element | None:
    model = diagram.find("mxGraphModel")
    if model is not None:
        return model
    payload = (diagram.text or "").strip()
    if not payload:
        return None
    try:
        raw = base64.b64decode(payload)
        try:
            xml = zlib.decompress(raw, -15).decode("utf-8")
        except zlib.error:
            xml = raw.decode("utf-8")
        xml = unquote(xml)
        return ElementTree.fromstring(xml)
    except (ValueError, zlib.error, UnicodeDecodeError, ElementTree.ParseError) as exc:
        raise DrawioError("Trang draw.io bị nén theo kiểu không đọc được") from exc


def _shape(cell: ElementTree.Element) -> dict:
    """Style and geometry of a vertex (x / y relative to its parent, as in draw.io)."""
    out = {"style": cell.get("style") or ""}
    geo = cell.find("mxGeometry")
    if geo is not None:
        for key, name in (("x", "x"), ("y", "y"), ("width", "w"), ("height", "h")):
            try:
                out[name] = float(geo.get(key) or 0)
            except ValueError:
                pass
    return out


def parse(text: str) -> list[dict]:
    """[{name, nodes: [{id, label, parent}], edges: [{id, source, target, label}]}] for every page."""
    if "<!DOCTYPE" in text[:2000] or "<!ENTITY" in text:
        raise DrawioError("File draw.io không được có DOCTYPE / ENTITY")
    try:
        root = ElementTree.fromstring(text)
    except ElementTree.ParseError as exc:
        raise DrawioError(f"Không đọc được XML: {exc}") from exc
    if root.tag == "mxGraphModel":
        diagrams = [(None, root)]
    elif root.tag == "mxfile":
        diagrams = [(d.get("name"), _model(d)) for d in root.findall("diagram")]
    else:
        raise DrawioError("Không phải file draw.io (thiếu <mxfile>)")
    pages = []
    total = 0
    for index, (name, model) in enumerate(diagrams, 1):
        page = {"name": name or f"Trang {index}", "nodes": [], "edges": []}
        if model is not None:
            cells = model.iter("mxCell")
            for cell in cells:
                total += 1
                if total > MAX_CELLS:
                    raise DrawioError(f"Sơ đồ quá lớn (hơn {MAX_CELLS} phần tử)")
                if not cell.get("id"):
                    continue  # the inner cell of <UserObject>/<object>: handled below, the wrapper has the id
                label = _text(cell.get("value") or "")
                if cell.get("vertex") == "1":
                    page["nodes"].append({"id": cell.get("id") or "", "label": label, "parent": cell.get("parent") or "",
                                          **_shape(cell)})
                elif cell.get("edge") == "1":
                    page["edges"].append({"id": cell.get("id") or "", "source": cell.get("source") or "",
                                          "target": cell.get("target") or "", "label": label})
            for wrapper in list(model.iter("UserObject")) + list(model.iter("object")):
                cell = wrapper.find("mxCell")
                if cell is None:
                    continue
                item = {"id": wrapper.get("id") or "", "label": _text(wrapper.get("label") or ""),
                        "parent": cell.get("parent") or "", **_shape(cell)}
                if cell.get("edge") == "1":
                    page["edges"].append({"id": item["id"], "source": cell.get("source") or "",
                                          "target": cell.get("target") or "", "label": item["label"]})
                else:
                    page["nodes"].append(item)
            # an edge label is often its own vertex cell whose parent is the edge
            edges = {e["id"]: e for e in page["edges"]}
            ends = {e["source"] for e in page["edges"]} | {e["target"] for e in page["edges"]}
            kept = []
            for node in page["nodes"]:
                edge = edges.get(node["parent"])
                if edge is not None:
                    edge["label"] = " ".join(x for x in (edge["label"], node["label"]) if x)
                elif node["label"] or node["id"] in ends:
                    kept.append(node)
            page["nodes"] = kept
        pages.append(page)
    if not any(p["nodes"] or p["edges"] for p in pages):
        raise DrawioError("File draw.io không có node hay cạnh nào")
    return pages


def as_text(pages: list[dict]) -> str:
    """The node / edge list an AI (or a person) reads."""
    out = []
    for page in pages:
        names = {n["id"]: (n["label"] or n["id"]).replace("\n", " / ") for n in page["nodes"]}
        containers = {n["parent"] for n in page["nodes"]}
        out.append(f"# Page: {page['name']}")
        out.append(f"Nodes ({len(page['nodes'])}):")
        for node in page["nodes"]:
            extra = f"  (inside {names[node['parent']]!r})" if node["parent"] in names else ""
            kind = "  [group]" if node["id"] in containers else ""
            out.append(f"- {node['id']}: {names[node['id']] if node['label'] else '(no label)'!r}{kind}{extra}")
        out.append(f"Edges ({len(page['edges'])}):")
        for edge in page["edges"]:
            src = names.get(edge["source"], edge["source"] or "?")
            dst = names.get(edge["target"], edge["target"] or "?")
            label = f"  [{edge['label'].replace(chr(10), ' / ')}]" if edge["label"] else ""
            out.append(f"- {src!r} -> {dst!r}{label}")
        out.append("")
    return "\n".join(out).strip() + "\n"


def _mermaid_label(text: str) -> str:
    return (text or " ").replace('"', "'").replace("\n", " ")


def as_mermaid(pages: list[dict]) -> str:
    """A flowchart of the same nodes and edges, for the preview only (layout is Mermaid's, not draw.io's)."""
    lines = ["flowchart LR"]
    ids: dict[tuple[int, str], str] = {}

    def node_id(page_index: int, raw: str) -> str:
        key = (page_index, raw)
        if key not in ids:
            ids[key] = f"n{len(ids) + 1}"
        return ids[key]

    for index, page in enumerate(pages):
        indent = "  "
        if len(pages) > 1:
            lines.append(f'  subgraph p{index + 1}["{_mermaid_label(page["name"])}"]')
            indent = "    "
        for node in page["nodes"]:
            if node["label"]:
                lines.append(f'{indent}{node_id(index, node["id"])}["{_mermaid_label(node["label"])}"]')
        for edge in page["edges"]:
            if not edge["source"] or not edge["target"]:
                continue
            src, dst = node_id(index, edge["source"]), node_id(index, edge["target"])
            label = f'|"{_mermaid_label(edge["label"])}"|' if edge["label"] else ""
            lines.append(f"{indent}{src} -->{label} {dst}")
        if len(pages) > 1:
            lines.append("  end")
    return "\n".join(lines) + "\n"


def _kind(style: str, is_group: bool) -> str:
    style = style.lower()
    for marker, kind in (("umlactor", "person"), ("cylinder", "database"), ("datastore", "database"),
                         ("shape=note", "note"), ("cloud", "external"), ("queue", "queue"), ("folder", "storage")):
        if marker in style:
            return kind
    if is_group or "swimlane" in style or "container=1" in style or style.startswith("group"):
        return "group"
    return "component"


def as_graph(pages: list[dict]) -> dict:
    """An editable system diagram (graph_doc format) with draw.io's positions; pages become top-level groups."""
    nodes, edges, used = [], [], set()

    def safe(raw: str, prefix: str) -> str:
        base = (prefix + re.sub(r"[^A-Za-z0-9_.:-]+", "-", raw or "n")).strip("-")[:70] or "n"
        value, i = base, 1
        while value in used:
            i += 1
            value = f"{base}-{i}"
        used.add(value)
        return value

    many = len(pages) > 1
    for index, page in enumerate(pages, 1):
        prefix = f"p{index}-" if many else ""
        ids = {n["id"]: safe(n["id"], prefix) for n in page["nodes"]}
        page_id = safe(f"page-{index}", "") if many else ""
        if many:
            nodes.append({"id": page_id, "label": page["name"], "kind": "group"})
        parents = {n["parent"] for n in page["nodes"]}
        for n in page["nodes"]:
            node = {"id": ids[n["id"]], "label": (n["label"] or "").replace("\n", " ")[:200] or ids[n["id"]],
                    "kind": _kind(n.get("style", ""), n["id"] in parents)}
            parent = ids.get(n["parent"]) or page_id
            if parent:
                node["parent"] = parent
            for key in ("x", "y", "w", "h"):
                if key in n:
                    node[key] = n[key]
            if node.get("w", 0) < 20 or node.get("h", 0) < 20:
                node.pop("w", None)
                node.pop("h", None)
            if many and not ids.get(n["parent"]):
                node.pop("x", None)
                node.pop("y", None)
            nodes.append(node)
        for e in page["edges"]:
            if e["source"] in ids and e["target"] in ids and e["source"] != e["target"]:
                edge = {"id": safe(e["id"], prefix + "e-"), "from": ids[e["source"]], "to": ids[e["target"]]}
                if e["label"]:
                    edge["label"] = e["label"].replace("\n", " ")[:200]
                edges.append(edge)
    return {"direction": "LR", "nodes": nodes, "edges": edges}
