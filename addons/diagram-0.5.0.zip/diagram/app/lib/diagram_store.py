"""Diagrams on disk: one JSON file per diagram, with every saved version.

    <data>/diagrams/<id>.json   {id, name, description, format, type, source, readOnly, created, updated,
                                 graph?, versions: [{v, at, by, note, content}]}   (the last version is the current one)

``by`` is "web" (a person on the page) or "ai" (an agent through diagram_propose, saved at once: there is no review
queue). Versions 0.4 and older kept AI proposals in <data>/proposals/; those files are left as they are, unread.

format: "mermaid" (editable, previewed), "plantuml" (stored and read as is), "drawio" (read only: the node / edge
list, plus a generated Mermaid flowchart for the preview), "graph" (a system diagram as data, see graph_doc.py, drawn
on a canvas). A graph can be big (thousands of nodes), so it is not copied into every version:

    <data>/diagrams/<id>.json         the same metadata; versions: [{v, at, by, note, summary, size}] (no content)
    <data>/graphs/<id>/current.json   the current graph
    <data>/graphs/<id>/patch/<v>.json the patch from version v-1 to v (graph_doc.diff): older versions are rebuilt by
                                      undoing patches from the current one
"""
from __future__ import annotations

import json
import re
import secrets
import threading
import time
import unicodedata
from pathlib import Path

from viewer_hub.addons.sdk import fold

import drawio
import graph_doc
from graph_doc import GraphError

MAX_CONTENT = 500_000
MAX_NAME = 120
MAX_DESCRIPTION = 1000
MAX_VERSIONS = 200
MAX_HISTORY_BYTES = 40_000_000   # patches kept per graph diagram; older versions are dropped past this
FORMATS = ("mermaid", "plantuml", "drawio", "graph")

MERMAID_TYPES = [
    ("flowchart", "flowchart"), ("graph", "flowchart"), ("sequenceDiagram", "sequence"),
    ("erDiagram", "er"), ("stateDiagram", "state"), ("classDiagram", "class"), ("gantt", "gantt"),
    ("pie", "pie"), ("journey", "journey"), ("mindmap", "mindmap"), ("timeline", "timeline"),
    ("gitGraph", "git"), ("quadrantChart", "quadrant"), ("C4", "c4"), ("requirementDiagram", "requirement"),
    ("sankey", "sankey"), ("xychart", "xychart"), ("block", "block"), ("architecture", "architecture"),
    ("packet", "packet"), ("kanban", "kanban"),
]
PLANTUML_TYPES = [
    (r"^\s*(participant|actor|boundary|control|entity|database)\b|->>?|-->>?", "sequence"),
    (r"^\s*class\s", "class"), (r"^\s*state\s|\[\*\]", "state"), (r"^\s*(usecase|\(.+\))", "usecase"),
    (r"^\s*(start|stop)\s*$|^\s*:.*;\s*$", "activity"), (r"^\s*(component|node|package|interface)\s", "component"),
]


class StoreError(ValueError):
    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


def now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def detect_type(content: str, fmt: str) -> str:
    if fmt == "drawio":
        return "drawio"
    if fmt == "graph":
        return "system"
    lines = [line.strip() for line in content.splitlines()]
    if fmt == "mermaid":
        in_front = False
        for line in lines:
            if not line or line.startswith("%%"):
                continue
            if line == "---":          # front matter (title / config) before the diagram keyword
                in_front = not in_front
                continue
            if in_front:
                continue
            word = re.split(r"[\s:{]", line, maxsplit=1)[0]
            for prefix, kind in MERMAID_TYPES:
                if word == prefix or word.startswith(prefix + "-") or (prefix in ("C4", "xychart", "sankey", "block", "architecture", "packet") and word.startswith(prefix)):
                    return kind
            return "mermaid"
        return "mermaid"
    body = "\n".join(lines)
    for pattern, kind in PLANTUML_TYPES:
        if re.search(pattern, body, re.M):
            return kind
    return "plantuml"


def format_for(filename: str, content: str) -> str:
    name = filename.lower()
    if name.endswith((".drawio", ".drawio.xml", ".dio")):
        return "drawio"
    if name.endswith((".puml", ".plantuml", ".pu", ".iuml", ".wsd")):
        return "plantuml"
    if name.endswith((".mmd", ".mermaid", ".md", ".txt")):
        return "mermaid"
    if content.lstrip().startswith("<mxfile") or content.lstrip().startswith("<mxGraphModel"):
        return "drawio"
    if "@startuml" in content:
        return "plantuml"
    raise StoreError("bad_file", "Chỉ nhận file .mmd, .puml hoặc .drawio")


def clean_mermaid_md(content: str) -> str:
    """A .md with a ```mermaid block: keep only the first block."""
    match = re.search(r"```mermaid\s*\n(.*?)```", content, re.S)
    return match.group(1) if match else content


def _text(value, limit: int, what: str, required: bool = False) -> str:
    text = str(value or "").strip()
    if required and not text:
        raise StoreError("missing", f"Thiếu {what}")
    if len(text) > limit:
        raise StoreError("too_long", f"{what[:1].upper()}{what[1:]} dài quá (tối đa {limit} ký tự)")
    return text


def _content(value) -> str:
    content = str(value or "").replace("\r\n", "\n")
    if not content.strip():
        raise StoreError("empty", "Sơ đồ chưa có nội dung")
    if len(content) > MAX_CONTENT:
        raise StoreError("too_large", f"Sơ đồ quá lớn (tối đa {MAX_CONTENT // 1000} KB)")
    return content.rstrip() + "\n"


def summary(diagram: dict) -> dict:
    current = diagram["versions"][-1]
    return {k: diagram.get(k) for k in ("id", "name", "description", "format", "type", "source", "readOnly",
                                        "created", "updated", "stats")} | {"version": current["v"], "versions": len(diagram["versions"]),
                                                                       "by": current.get("by") or "web"}


def _graph(value) -> dict:
    try:
        return graph_doc.normalize(value)
    except GraphError as exc:
        raise StoreError("bad_graph", str(exc)) from exc


class Store:
    def __init__(self, data: Path):
        self.root = data / "diagrams"
        self.graphs = data / "graphs"
        self.lock = threading.Lock()

    # ── files ───────────────────────────────────────────────────────────────────────────────────────────────
    @staticmethod
    def _write(path: Path, value: dict) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(value, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(path)

    @staticmethod
    def _write_compact(path: Path, value) -> int:
        path.parent.mkdir(parents=True, exist_ok=True)
        data = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
        tmp = path.with_suffix(".tmp")
        tmp.write_text(data, encoding="utf-8")
        tmp.replace(path)
        return len(data.encode("utf-8"))

    @staticmethod
    def _read(path: Path) -> dict | None:
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        return value if isinstance(value, dict) else None

    @staticmethod
    def _safe_id(value: str) -> str:
        value = str(value or "").strip()
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,80}", value):
            raise StoreError("not_found", "Không có sơ đồ này", 404)
        return value

    def _new_id(self, name: str, folder: Path) -> str:
        ascii_name = unicodedata.normalize("NFKD", name.lower().replace("đ", "d")).encode("ascii", "ignore").decode()
        base = re.sub(r"[^a-z0-9]+", "-", ascii_name).strip("-")[:40] or "so-do"
        while True:
            value = f"{base}-{secrets.token_hex(3)}"
            if not (folder / f"{value}.json").exists():
                return value

    # ── diagrams ────────────────────────────────────────────────────────────────────────────────────────────
    def all(self) -> list[dict]:
        items = []
        if self.root.is_dir():
            for path in self.root.glob("*.json"):
                diagram = self._read(path)
                if diagram and diagram.get("versions"):
                    items.append(diagram)
        return sorted(items, key=lambda d: d.get("updated") or "", reverse=True)

    def get(self, diagram_id: str) -> dict:
        diagram = self._read(self.root / f"{self._safe_id(diagram_id)}.json")
        if not diagram or not diagram.get("versions"):
            raise StoreError("not_found", "Không có sơ đồ này", 404)
        return diagram

    def find(self, key: str) -> dict:
        """By id, or by exact (case-insensitive) name: what an AI passes."""
        key = str(key or "").strip()
        try:
            return self.get(key)
        except StoreError:
            pass
        matches = [d for d in self.all() if d["name"].lower() == key.lower()]
        if len(matches) == 1:
            return matches[0]
        raise StoreError("not_found", f"No diagram {key!r} (use diagram_list for ids)", 404)

    # ── graph diagrams ──────────────────────────────────────────────────────────────────────────────────────────
    def graph(self, diagram_id: str) -> dict:
        value = self._read(self.graphs / self._safe_id(diagram_id) / "current.json")
        return value if value is not None else graph_doc.empty()

    def _create_graph(self, *, name, description, graph, source, by, note) -> dict:
        doc = _graph(graph)
        with self.lock:
            stamp = now()
            diagram = {
                "id": self._new_id(name, self.root), "name": name, "description": description, "format": "graph",
                "type": "system", "source": source, "readOnly": False, "created": stamp, "updated": stamp,
                "stats": graph_doc.stats(doc),
                "versions": [{"v": 1, "at": stamp, "by": by, "note": note, "summary": "tạo mới", "size": 0}],
            }
            self._write_compact(self.graphs / diagram["id"] / "current.json", doc)
            self._write(self.root / f"{diagram['id']}.json", diagram)
        return diagram

    def _save_graph(self, diagram: dict, graph, by: str, note: str, base_version) -> None:
        """Inside the lock: new version when the graph changed."""
        current_v = diagram["versions"][-1]["v"]
        if base_version not in (None, "") and int(base_version) != current_v:
            raise StoreError("conflict", f"Sơ đồ đã có bản mới hơn (bản {current_v}) từ lúc bạn mở: tải lại rồi sửa tiếp", 409)
        doc = _graph(graph)
        old = self.graph(diagram["id"])
        patch = graph_doc.diff(old, doc)
        if not patch:
            return
        v = current_v + 1
        folder = self.graphs / diagram["id"]
        size = self._write_compact(folder / "patch" / f"{v}.json", patch)
        self._write_compact(folder / "current.json", doc)
        diagram["versions"].append({"v": v, "at": now(), "by": by, "note": _text(note, 200, "ghi chú"),
                                    "summary": graph_doc.patch_summary(patch), "size": size})
        diagram["stats"] = graph_doc.stats(doc)
        # keep the history bounded: drop the oldest versions (and the patches leading to them)
        while len(diagram["versions"]) > 1 and (len(diagram["versions"]) > MAX_VERSIONS
                                                or sum(x.get("size", 0) for x in diagram["versions"]) > MAX_HISTORY_BYTES):
            dropped = diagram["versions"].pop(0)
            (folder / "patch" / f"{dropped['v']}.json").unlink(missing_ok=True)
            first = diagram["versions"][0]
            (folder / "patch" / f"{first['v']}.json").unlink(missing_ok=True)
            first["size"] = 0

    def graph_version(self, diagram: dict, wanted: int) -> dict:
        """The graph as it was at version `wanted`: undo the patches from the current one back to it."""
        doc = self.graph(diagram["id"])
        for item in reversed(diagram["versions"]):
            if item["v"] <= wanted:
                break
            patch = json.loads((self.graphs / diagram["id"] / "patch" / f"{item['v']}.json").read_text(encoding="utf-8"))
            doc = graph_doc.apply_patch(doc, graph_doc.invert(patch))
        return doc

    def create(self, *, name, description="", content=None, fmt="mermaid", source="", by="web", note="", graph=None) -> dict:
        if fmt not in FORMATS:
            raise StoreError("bad_format", "Định dạng không hỗ trợ")
        name = _text(name, MAX_NAME, "tên sơ đồ", required=True)
        description = _text(description, MAX_DESCRIPTION, "mô tả")
        if fmt == "graph":
            return self._create_graph(name=name, description=description, graph=graph if graph is not None else graph_doc.empty(),
                                      source=source, by=by, note=note)
        content = _content(content)
        graph = None
        if fmt == "drawio":
            try:
                pages = drawio.parse(content)
            except drawio.DrawioError as exc:
                raise StoreError("bad_drawio", str(exc)) from exc
            graph = {"pages": pages, "text": drawio.as_text(pages), "mermaid": drawio.as_mermaid(pages)}
        with self.lock:
            stamp = now()
            diagram = {
                "id": self._new_id(name, self.root), "name": name, "description": description, "format": fmt,
                "type": detect_type(content, fmt), "source": source, "readOnly": fmt == "drawio",
                "created": stamp, "updated": stamp, "graph": graph,
                "versions": [{"v": 1, "at": stamp, "by": by, "note": note, "content": content}],
            }
            self._write(self.root / f"{diagram['id']}.json", diagram)
        return diagram

    def save(self, diagram_id: str, *, content=None, name=None, description=None, by="web", note="", graph=None,
             base_version=None) -> dict:
        with self.lock:
            diagram = self.get(diagram_id)
            if name is not None:
                diagram["name"] = _text(name, MAX_NAME, "tên sơ đồ", required=True)
            if description is not None:
                diagram["description"] = _text(description, MAX_DESCRIPTION, "mô tả")
            if graph is not None:
                if diagram["format"] != "graph":
                    raise StoreError("bad_format", "Sơ đồ này không phải sơ đồ hệ thống")
                self._save_graph(diagram, graph, by, note, base_version)
            if content is not None and diagram["format"] == "graph":
                raise StoreError("bad_format", "Sơ đồ hệ thống lưu bằng graph, không phải text")
            if content is not None:
                if diagram.get("readOnly"):
                    raise StoreError("read_only", "Sơ đồ draw.io chỉ đọc, không sửa được nội dung")
                content = _content(content)
                current = diagram["versions"][-1]
                if content != current["content"]:
                    diagram["versions"].append({"v": current["v"] + 1, "at": now(), "by": by,
                                                "note": _text(note, 200, "ghi chú"), "content": content})
                    diagram["versions"] = diagram["versions"][-MAX_VERSIONS:]
                    diagram["type"] = detect_type(content, diagram["format"])
            diagram["updated"] = now()
            self._write(self.root / f"{diagram['id']}.json", diagram)
        return diagram

    def version(self, diagram: dict, v) -> dict:
        try:
            wanted = int(v)
        except (TypeError, ValueError):
            raise StoreError("not_found", "Không có bản này", 404) from None
        for item in diagram["versions"]:
            if item["v"] == wanted:
                if diagram["format"] == "graph":
                    return item | {"graph": self.graph_version(diagram, wanted)}
                return item
        raise StoreError("not_found", f"Không có bản {wanted} (bản cũ quá {MAX_VERSIONS} bản đã bị bỏ)", 404)

    def delete(self, diagram_id: str) -> None:
        with self.lock:
            path = self.root / f"{self._safe_id(diagram_id)}.json"
            if not path.exists():
                raise StoreError("not_found", "Không có sơ đồ này", 404)
            path.unlink()
            folder = self.graphs / diagram_id
            if folder.is_dir():
                for item in sorted(folder.rglob("*"), reverse=True):
                    item.rmdir() if item.is_dir() else item.unlink()
                folder.rmdir()

    # ── AI writes (no review queue: saved at once as a version by "ai"; History restores an older one) ─────────
    def ai_write(self, *, content=None, ops=None, name="", description="", target="", reason="") -> tuple[dict, bool]:
        """Save what an agent sends: graph ``ops`` or full Mermaid ``content``, to diagram ``target`` or a new one.
        Returns (diagram, changed). The diagram as it was stays in its history (``by`` tells AI and people apart)."""
        note = ("AI" + (f": {_text(reason, 1000, 'lý do')}" if str(reason or "").strip() else ""))[:200]
        if ops is not None:
            base_doc, base = graph_doc.empty(), None
            if target:
                diagram = self.find(target)
                if diagram["format"] != "graph":
                    raise StoreError("bad_format", f"{diagram['id']} is a {diagram['format']} diagram: send Mermaid content for it, ops are for system (graph) diagrams")
                base, base_doc = diagram["versions"][-1]["v"], self.graph(diagram["id"])
            try:
                result, _counts = graph_doc.apply_ai_ops(base_doc, ops)
            except GraphError as exc:
                raise StoreError("bad_ops", str(exc)) from exc
            if target:
                saved = self.save(diagram["id"], graph=result, by="ai", note=note, base_version=base)
                return saved, saved["versions"][-1]["v"] != base
            return self.create(name=name, description=description, fmt="graph", graph=result, by="ai", note=note,
                               source="AI"), True
        content = _content(content)
        if target:
            diagram = self.find(target)
            if diagram.get("readOnly"):
                raise StoreError("read_only", "That diagram is a read-only draw.io import; save a new diagram instead")
            if diagram["format"] == "graph":
                raise StoreError("bad_format", f"{diagram['id']} is a system (graph) diagram: send ops, not Mermaid content")
            base = diagram["versions"][-1]["v"]
            saved = self.save(diagram["id"], content=content, by="ai", note=note)
            return saved, saved["versions"][-1]["v"] != base
        return self.create(name=name, description=description, content=content, by="ai", note=note, source="AI"), True

    # ── search ──────────────────────────────────────────────────────────────────────────────────────────────
    def search(self, query: str, limit: int = 20) -> list[dict]:
        words = [w for w in fold(str(query or "")).split() if w]  # graph_doc.search_lines folds the same way
        if not words:
            return []
        hits = []
        for diagram in self.all():
            head = fold(f"{diagram['name']}\n{diagram.get('description') or ''}")
            if diagram["format"] == "graph":
                doc = self.graph(diagram["id"])
                haystack = head + "\n" + graph_doc.haystack(doc)
                found, _more = graph_doc.search_lines(doc, words, limit=10_000)
            else:
                body = diagram["graph"]["text"] if diagram.get("graph") else diagram["versions"][-1]["content"]
                found = [line.strip() for line in body.splitlines() if any(w in fold(line) for w in words)]
                haystack = head + "\n" + fold(body)
            if all(w in haystack for w in words):
                hits.append({"diagram": diagram, "lines": found[:8], "more": max(0, len(found) - 8),
                             "score": sum(haystack.count(w) for w in words) + (5 if any(w in head for w in words) else 0)})
        hits.sort(key=lambda h: h["score"], reverse=True)
        return hits[:limit]
