import e, { createContext as t, memo as n, useCallback as r, useContext as i, useEffect as a, useMemo as o, useRef as s, useState as c } from "/static/dist/sdk/react.js";
import { Button as l, Dialog as u, Empty as d, ErrorBanner as f, IconButton as p, Loading as m, Select as h, TextField as g } from "/static/dist/sdk/md.js";
import { Badge as _, fold as v, readFileBody as y, useAction as b, useConfirm as x, useLayout as S, useLoad as C, useRouter as w, useTitle as ee } from "/static/dist/sdk/ui.js";
import { render as T, svgElement as E, svgElement as D } from "/static/dist/sdk/mermaid.js";
import { Background as O, ConnectionMode as te, Controls as ne, Handle as k, MarkerType as A, MiniMap as j, NodeResizer as M, Panel as N, Position as P, ReactFlow as F, ReactFlowProvider as I, applyEdgeChanges as L, applyNodeChanges as re, layoutGraph as ie, useReactFlow as ae, useStore as R } from "/static/dist/sdk/flow.js";
import { Fragment as z, jsx as B, jsxs as V } from "/static/dist/sdk/jsx-runtime.js";
// web/mermaid.js
function H(e, t = "page") {
	return T(e, { theme: t });
}
function U(e, t) {
	let n = URL.createObjectURL(t), r = document.createElement("a");
	r.href = n, r.download = e, document.body.appendChild(r), r.click(), r.remove(), setTimeout(() => URL.revokeObjectURL(n), 2e3);
}
function oe(e) {
	let t = E(e), n = (t.getAttribute("viewBox") || "").split(/[\s,]+/).map(Number);
	return {
		el: t,
		width: n.length === 4 && n[2] > 0 ? n[2] : parseFloat(t.getAttribute("width")) || 800,
		height: n.length === 4 && n[3] > 0 ? n[3] : parseFloat(t.getAttribute("height")) || 600
	};
}
async function se(e) {
	let { svg: t } = await H(e, "export"), { el: n, width: r, height: i } = oe(t);
	return n.setAttribute("width", String(Math.ceil(r))), n.setAttribute("height", String(Math.ceil(i))), n.removeAttribute("style"), new Blob([new XMLSerializer().serializeToString(n)], { type: "image/svg+xml" });
}
async function ce(e, t = 2) {
	let n = await se(e), { width: r, height: i } = oe(await n.text()), a = URL.createObjectURL(n);
	try {
		let e = new Image();
		await new Promise((t, n) => {
			e.onload = t, e.onerror = () => n(/* @__PURE__ */ Error("Không vẽ được ảnh từ SVG")), e.src = a;
		});
		let n = document.createElement("canvas");
		n.width = Math.ceil(r * t), n.height = Math.ceil(i * t);
		let o = n.getContext("2d");
		return o.fillStyle = "#ffffff", o.fillRect(0, 0, n.width, n.height), o.drawImage(e, 0, 0, n.width, n.height), await new Promise((e, t) => {
			try {
				n.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("Không tạo được PNG")), "image/png");
			} catch {
				t(/* @__PURE__ */ Error("Trình duyệt chặn xuất PNG cho sơ đồ này; hãy xuất SVG"));
			}
		});
	} finally {
		URL.revokeObjectURL(a);
	}
}
// web/templates.js
var W = [
	[
		"flowchart",
		"Flowchart",
		"account_tree",
		"flowchart TD\n    A[Bắt đầu] --> B{Hợp lệ?}\n    B -- Có --> C[Xử lý]\n    B -- Không --> D[Báo lỗi]\n    C --> E[Kết thúc]\n    D --> E\n"
	],
	[
		"sequence",
		"Sequence",
		"swap_horiz",
		"sequenceDiagram\n    actor U as Người dùng\n    participant W as Web\n    participant A as API\n    participant D as CSDL\n    U->>W: Bấm \"Đặt hàng\"\n    W->>A: POST /orders\n    A->>D: INSERT order\n    D-->>A: id\n    A-->>W: 201 Created\n    W-->>U: Hiện mã đơn\n"
	],
	[
		"er",
		"ER",
		"table_chart",
		"erDiagram\n    CUSTOMER ||--o{ ORDER : \"đặt\"\n    ORDER ||--|{ ORDER_ITEM : \"gồm\"\n    PRODUCT ||--o{ ORDER_ITEM : \"nằm trong\"\n    CUSTOMER {\n        int id PK\n        string name\n        string email\n    }\n    ORDER {\n        int id PK\n        int customer_id FK\n        date created_at\n    }\n    ORDER_ITEM {\n        int order_id FK\n        int product_id FK\n        int quantity\n    }\n    PRODUCT {\n        int id PK\n        string name\n        decimal price\n    }\n"
	],
	[
		"state",
		"State",
		"change_circle",
		"stateDiagram-v2\n    [*] --> Moi\n    Moi --> DangXuLy: duyệt\n    DangXuLy --> HoanThanh: giao xong\n    DangXuLy --> DaHuy: huỷ\n    Moi --> DaHuy: huỷ\n    HoanThanh --> [*]\n    DaHuy --> [*]\n"
	]
], le = "flowchart LR\n    A --> B\n", G = {
	w: 260,
	h: 110
}, ue = [
	[
		"person",
		"Người dùng",
		"person"
	],
	[
		"system",
		"Hệ thống",
		"dns"
	],
	[
		"external",
		"Hệ thống ngoài",
		"public"
	],
	[
		"app",
		"Ứng dụng (web, mobile)",
		"web"
	],
	[
		"service",
		"Service / API",
		"api"
	],
	[
		"component",
		"Thành phần",
		"widgets"
	],
	[
		"database",
		"Cơ sở dữ liệu",
		"database"
	],
	[
		"queue",
		"Hàng đợi / topic",
		"dynamic_feed"
	],
	[
		"storage",
		"File / storage",
		"folder_open"
	],
	[
		"job",
		"Batch / job",
		"schedule"
	],
	[
		"group",
		"Nhóm",
		"select_all"
	],
	[
		"note",
		"Ghi chú",
		"sticky_note_2"
	]
], K = Object.fromEntries(ue.map(([e, t, n]) => [e, {
	label: t,
	icon: n
}])), de = [
	["sync", "Gọi (đồng bộ)"],
	["async", "Message (bất đồng bộ)"],
	["data", "Đọc / ghi dữ liệu"],
	["dependency", "Phụ thuộc"]
], q = () => ({
	direction: "LR",
	nodes: [],
	edges: []
});
function fe(e) {
	let t = Math.max((e.label || "").length, (e.tech || "").length * .85);
	return {
		w: e.w || Math.round(Math.min(280, Math.max(160, 70 + t * 7.4))),
		h: e.h || (e.kind === "note" ? 80 : 64)
	};
}
function J(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
	for (let n of e.nodes) t.set(n.id, n);
	for (let r of e.nodes) {
		let e = r.parent && t.has(r.parent) ? r.parent : "";
		n.has(e) || n.set(e, []), n.get(e).push(r.id);
	}
	let r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), a = [], o = [...n.get("") || []].reverse().map((e) => [e, 0]);
	for (; o.length;) {
		let [e, t] = o.pop();
		if (!i.has(e)) {
			i.set(e, t), a.push(e);
			for (let r of [...n.get(e) || []].reverse()) o.push([r, t + 1]);
		}
	}
	for (let e = a.length - 1; e >= 0; --e) {
		let t = a[e];
		r.set(t, (n.get(t) || []).reduce((e, t) => e + 1 + (r.get(t) || 0), 0));
	}
	let s = (e) => t.get(e)?.kind === "group" || (n.get(e)?.length || 0) > 0, c = (e) => {
		let n = [], r = t.get(e)?.parent;
		for (; r && t.has(r) && n.length < 200;) n.push(r), r = t.get(r).parent;
		return n;
	};
	return {
		byId: t,
		kids: n,
		count: r,
		depth: i,
		order: a,
		isGroup: s,
		ancestors: c,
		inside: (e, t) => !t || c(e).includes(t)
	};
}
function Y(e) {
	return {
		w: e.w || 320,
		h: e.h || 200
	};
}
var pe = (e, t) => e.isGroup(t.id) ? t.folded ? G : Y(t) : fe(t), me = pe;
function he(e, t, n = "") {
	let r = /* @__PURE__ */ new Map();
	for (let e of t.order) {
		let i = t.byId.get(e), a = i.parent && i.parent !== n ? r.get(i.parent) : null;
		i.parent && i.parent !== n && !a || n && e !== n && !t.inside(e, n) || r.set(e, {
			x: (a?.x || 0) + (i.x || 0),
			y: (a?.y || 0) + (i.y || 0)
		});
	}
	return r;
}
function ge(e, t) {
	if (!e) return null;
	let n = new Map(e.nodes.map((e) => [e.id, e])), r = new Map(e.edges.map((e) => [e.id, e])), i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = (e, t, n) => n.every((n) => (e[n] || "") === (t[n] || ""));
	for (let e of t.nodes) {
		let t = n.get(e.id);
		t ? o(t, e, [
			"label",
			"kind",
			"parent",
			"note",
			"tech"
		]) || i.set(e.id, "change") : i.set(e.id, "add");
	}
	for (let e of t.edges) {
		let t = r.get(e.id);
		t ? o(t, e, [
			"from",
			"to",
			"label",
			"kind"
		]) || a.set(e.id, "change") : a.set(e.id, "add");
	}
	let s = new Set(t.nodes.map((e) => e.id)), c = new Set(t.edges.map((e) => e.id));
	return {
		nodes: i,
		edges: a,
		removedNodes: e.nodes.filter((e) => !s.has(e.id)),
		removedEdges: e.edges.filter((e) => !c.has(e.id))
	};
}
function _e(e, t) {
	return Math.abs(e) >= Math.abs(t) ? e >= 0 ? ["r", "l"] : ["l", "r"] : t >= 0 ? ["b", "t"] : ["t", "b"];
}
function ve(e, t, n, r, i) {
	let a = n.focus && t.byId.has(n.focus) ? n.focus : "", o = [], s = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), u = [...t.kids.get(a) || []].reverse();
	for (; u.length;) {
		let e = u.pop(), n = t.byId.get(e), d = t.isGroup(e), f = d && !!n.folded, p = f ? G : d ? Y(n) : fe(n), m = n.parent && n.parent !== a ? n.parent : void 0, h = m ? c.get(m) : {
			x: 0,
			y: 0
		}, g = {
			x: n.x || 0,
			y: n.y || 0
		};
		if (c.set(e, {
			x: h.x + g.x,
			y: h.y + g.y
		}), l.set(e, p), s.add(e), o.push({
			id: e,
			type: f ? "folded" : d ? "group" : "item",
			position: g,
			parentId: m,
			width: p.w,
			height: p.h,
			data: {
				node: n,
				count: t.count.get(e) || 0,
				diff: r?.nodes.get(e) || "",
				readOnly: i
			},
			deletable: !i
		}), d && !f) for (let n of [...t.kids.get(e) || []].reverse()) u.push(n);
	}
	let d = /* @__PURE__ */ new Map(), f = (e) => {
		if (d.has(e)) return d.get(e);
		let n = e, r = null, i = [];
		for (; n && t.byId.has(n);) {
			if (s.has(n)) {
				r = n;
				break;
			}
			if (n === a) break;
			i.push(n), n = t.byId.get(n).parent;
		}
		for (let e of i) d.set(e, r);
		return d.set(e, r), r;
	}, p = (e) => {
		let t = c.get(e), n = l.get(e);
		return {
			x: t.x + n.w / 2,
			y: t.y + n.h / 2
		};
	}, m = [], h = /* @__PURE__ */ new Map();
	for (let t of e.edges) {
		let e = f(t.from), n = f(t.to);
		if (!e || !n || e === n) continue;
		let a = p(e), o = p(n), [s, c] = _e(o.x - a.x, o.y - a.y);
		if (e === t.from && n === t.to) {
			let a = r?.edges.get(t.id);
			m.push({
				id: t.id,
				source: e,
				target: n,
				sourceHandle: s,
				targetHandle: c,
				label: t.label || void 0,
				className: `dg-e--${t.kind || "sync"}${a ? ` dg-d--${a}` : ""}`,
				data: { edge: t },
				deletable: !i
			});
		} else {
			let t = `${e}\u0000${n}`, r = h.get(t) || {
				a: e,
				b: n,
				sa: s,
				sb: c,
				n: 0
			};
			r.n += 1, h.set(t, r);
		}
	}
	for (let { a: e, b: t, sa: n, sb: r, n: i } of h.values()) m.push({
		id: `sum:${e}>${t}`,
		source: e,
		target: t,
		sourceHandle: n,
		targetHandle: r,
		label: i > 1 ? `×${i}` : void 0,
		className: "dg-e--sum",
		selectable: !1,
		deletable: !1,
		focusable: !1,
		data: { summed: i }
	});
	return {
		nodes: o,
		edges: m,
		root: a
	};
}
var ye = /^[A-Za-z0-9_.:-]{1,80}$/;
function be(e) {
	return String(e || "").toLowerCase().replace(/đ/g, "d").normalize("NFKD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40);
}
function xe(e, t, n = "n") {
	let r = /* @__PURE__ */ new Set([...e.nodes.map((e) => e.id), ...e.edges.map((e) => e.id)]), i = ye.test(t || "") ? t : n;
	if (!r.has(i) && i !== n) return i;
	for (let e = 1;; e += 1) if (!r.has(`${i}-${e}`)) return `${i}-${e}`;
}
function Se(e, t) {
	return {
		...e,
		nodes: [...e.nodes, t]
	};
}
function Ce(e, t, n) {
	return {
		...e,
		nodes: e.nodes.map((e) => e.id === t ? X({
			...e,
			...n
		}) : e)
	};
}
function X(e) {
	for (let t of Object.keys(e)) (e[t] === "" || e[t] == null) && delete e[t];
	return e;
}
function we(e, t, n) {
	return {
		...e,
		edges: e.edges.map((e) => e.id === t ? X({
			...e,
			...n
		}) : e)
	};
}
function Te(e, t, n, r = {}) {
	if (t === n || e.edges.some((e) => e.from === t && e.to === n && !r.label)) return e;
	let i = xe(e, "", "e");
	return {
		...e,
		edges: [...e.edges, X({
			id: i,
			from: t,
			to: n,
			...r
		})]
	};
}
function Ee(e, t, n, r) {
	let i = /* @__PURE__ */ new Set(), a = [...n];
	for (; a.length;) {
		let e = a.pop();
		i.has(e) || (i.add(e), a.push(...t.kids.get(e) || []));
	}
	let o = new Set(r);
	return {
		...e,
		nodes: e.nodes.filter((e) => !i.has(e.id)),
		edges: e.edges.filter((e) => !o.has(e.id) && !i.has(e.from) && !i.has(e.to))
	};
}
function Z(e, t) {
	return t.size ? {
		...e,
		nodes: e.nodes.map((e) => t.has(e.id) ? X({
			...e,
			...t.get(e.id)
		}) : e)
	} : e;
}
function De(e, t, n, r, i = "") {
	if (n === r || r && t.ancestors(r).includes(n)) return e;
	let a = he(e, t, i), o = a.get(n), s = r && r !== i ? a.get(r) : {
		x: 0,
		y: 0
	};
	return !o || !s ? e : Ce(e, n, {
		parent: r || null,
		x: Q(o.x - s.x),
		y: Q(o.y - s.y)
	});
}
var Q = (e) => Math.round(e * 10) / 10;
function Oe(e, t, n, r = "Nhóm mới") {
	let i = new Set(n.map((e) => t.byId.get(e)?.parent || ""));
	if (i.size !== 1 || !n.length) return {
		doc: e,
		error: "Chỉ nhóm được các khối cùng cấp (cùng nằm trong một nhóm)"
	};
	let a = [...i][0], o = Infinity, s = Infinity, c = -Infinity, l = -Infinity;
	for (let e of n) {
		let n = t.byId.get(e), r = me(t, n);
		o = Math.min(o, n.x || 0), s = Math.min(s, n.y || 0), c = Math.max(c, (n.x || 0) + r.w), l = Math.max(l, (n.y || 0) + r.h);
	}
	let u = o - 24, d = s - 24 - 44, f = xe(e, be(r) || "nhom", "nhom"), p = X({
		id: f,
		label: r,
		kind: "group",
		parent: a || null,
		x: Q(u),
		y: Q(d),
		w: Q(c - o + 48),
		h: Q(l - s + 48 + 44)
	}), m = new Set(n), h = e.nodes.map((e) => m.has(e.id) ? {
		...e,
		parent: f,
		x: Q((e.x || 0) - u),
		y: Q((e.y || 0) - d)
	} : e);
	return {
		doc: {
			...e,
			nodes: [...h, p]
		},
		id: f
	};
}
function $(e) {
	let t = J(e), n = /* @__PURE__ */ new Map(), r = (e) => ({
		...t.byId.get(e),
		...n.get(e) || {}
	});
	for (let e = t.order.length - 1; e >= 0; --e) {
		let i = t.order[e], a = t.kids.get(i);
		if (!a?.length) continue;
		let o = Infinity, s = Infinity, c = -Infinity, l = -Infinity;
		for (let e of a) {
			let n = r(e), i = me(t, n);
			o = Math.min(o, n.x || 0), s = Math.min(s, n.y || 0), c = Math.max(c, (n.x || 0) + i.w), l = Math.max(l, (n.y || 0) + i.h);
		}
		let u = r(i), d = Y(u), f = Math.max(0, 24 - o), p = Math.max(0, 68 - s);
		if (f || p) for (let e of a) {
			let t = r(e);
			n.set(e, {
				...n.get(e) || {},
				x: Q((t.x || 0) + f),
				y: Q((t.y || 0) + p)
			});
		}
		let m = Math.max(d.w, c + f + 24), h = Math.max(d.h, l + p + 24);
		(f || p || m !== u.w || h !== u.h) && n.set(i, {
			...n.get(i) || {},
			x: Q((u.x || 0) - f),
			y: Q((u.y || 0) - p),
			w: Q(m),
			h: Q(h)
		});
	}
	return Z(e, n);
}
function ke(e) {
	return e.nodes.length ? e.nodes.filter((e) => e.x == null || e.y == null).length / e.nodes.length : 0;
}
function Ae(e) {
	let t = J(e), n = /* @__PURE__ */ new Map();
	for (let [e, r] of t.kids) {
		let i = r.filter((e) => t.byId.get(e).x == null || t.byId.get(e).y == null);
		if (!i.length) continue;
		let a = r.filter((e) => !i.includes(e)).map((e) => t.byId.get(e)), o = e ? 24 : 0, s = e ? 68 : 0;
		a.length && (o = Math.max(...a.map((e) => (e.x || 0) + me(t, e).w)) + 60, s = Math.min(...a.map((e) => e.y || 0)));
		let c = s, l = 0;
		for (let e of i) {
			let r = me(t, t.byId.get(e));
			s - c > 900 && (s = c, o += l + 40, l = 0), n.set(e, {
				x: o,
				y: s
			}), s += r.h + 28, l = Math.max(l, r.w);
		}
	}
	return $(Z(e, n));
}
function je(e, t, n = "") {
	let r = [];
	for (let e of t.order) {
		if (n && !t.inside(e, n)) continue;
		let i = t.byId.get(e), a = t.isGroup(e), o = a && i.folded && e !== n, s = o ? G : a ? {
			w: 200,
			h: 64
		} : fe(i);
		r.push({
			id: e,
			parent: i.parent && i.parent !== n ? i.parent : null,
			width: s.w,
			height: s.h,
			folded: o
		});
	}
	let i = new Set(r.map((e) => e.id));
	return {
		nodes: r,
		edges: e.edges.filter((e) => i.has(e.from) && i.has(e.to)).map((e) => ({
			source: e.from,
			target: e.to
		}))
	};
}
function Me(e, t, n, r = "") {
	let i = /* @__PURE__ */ new Map(), a = r ? 24 : 0, o = r ? 68 : 0;
	for (let [e, s] of Object.entries(n)) {
		let n = t.byId.get(e);
		if (!n) continue;
		let c = !n.parent || n.parent === r, l = {
			x: Q(s.x + (c ? a : 0)),
			y: Q(s.y + (c ? o : 0))
		};
		if (t.isGroup(e)) {
			let e = s.inner || s;
			l.w = Q(e.width), l.h = Q(e.height);
		}
		i.set(e, l);
	}
	let s = Z(e, i);
	return r ? $(s) : s;
}
function Ne(e, t) {
	let n = J(e), r = n.byId.get(t);
	if (!r || !n.isGroup(t)) return e;
	let i = pe(n, r), a = Ce(e, t, { folded: !r.folded || null });
	n = J(a);
	let o = pe(n, n.byId.get(t)), s = o.w - i.w, c = o.h - i.h, l = /* @__PURE__ */ new Map(), u = t, d = i.w, f = i.h;
	for (; u;) {
		let e = n.byId.get(u), t = e.x || 0, r = e.y || 0;
		for (let i of n.kids.get(e.parent && n.byId.has(e.parent) ? e.parent : "") || []) {
			if (i === u) continue;
			let e = n.byId.get(i), a = l.get(i) || {}, o = e.x || 0, p = e.y || 0;
			o >= t + d - 1 && (a.x = Q(o + s)), p >= r + f - 1 && (a.y = Q(p + c)), ("x" in a || "y" in a) && l.set(i, a);
		}
		let i = e.parent && n.byId.get(e.parent);
		if (!i) break;
		let a = Y(i);
		if (l.set(i.id, {
			...l.get(i.id) || {},
			w: Q(Math.max(160, a.w + s)),
			h: Q(Math.max(84, a.h + c))
		}), i.folded) break;
		d = a.w, f = a.h, u = i.id;
	}
	return Z(a, l);
}
function Pe(e) {
	let t = J(e);
	return {
		...e,
		nodes: e.nodes.map((e) => e.parent && t.isGroup(e.id) ? {
			...e,
			folded: !0
		} : e)
	};
}
function Fe(e) {
	let t = J(e), n = new Map(e.nodes.map((e, t) => [e.id, `n${t + 1}`])), r = (e) => String(e || " ").replace(/"/g, "'").replace(/[\r\n]+/g, " "), i = {
		database: ["[(\"", "\")]"],
		person: ["([\"", "\"])"],
		queue: ["[[\"", "\"]]"],
		external: ["{{\"", "\"}}"],
		storage: ["[/\"", "\"/]"],
		note: [">\"", "\"]"],
		job: ["((\"", "\"))"]
	}, a = [`flowchart ${e.direction === "TB" ? "TB" : "LR"}`], o = (e, s) => {
		for (let c of t.kids.get(e) || []) {
			let e = t.byId.get(c);
			if (t.isGroup(c)) a.push(`${s}subgraph ${n.get(c)}["${r(e.label)}"]`), o(c, s + "  "), a.push(`${s}end`);
			else {
				let [t, o] = i[e.kind] || ["[\"", "\"]"];
				a.push(`${s}${n.get(c)}${t}${r(e.label)}${o}`);
			}
		}
	};
	o("", "  ");
	for (let t of e.edges) {
		let e = t.kind === "async" ? "-.->" : t.kind === "dependency" ? "-.-" : t.kind === "data" ? "==>" : "-->";
		a.push(`  ${n.get(t.from)} ${e}${t.label ? `|"${r(t.label)}"|` : ""} ${n.get(t.to)}`);
	}
	return a.join("\n") + "\n";
}
function Ie() {
	return {
		direction: "LR",
		nodes: [
			{
				id: "user",
				label: "Người dùng",
				kind: "person",
				x: 0,
				y: 120
			},
			{
				id: "he-thong",
				label: "Hệ thống",
				kind: "group",
				x: 240,
				y: 0,
				w: 640,
				h: 330
			},
			{
				id: "web",
				label: "Web app",
				kind: "app",
				tech: "React",
				parent: "he-thong",
				x: 24,
				y: 80
			},
			{
				id: "api",
				label: "API",
				kind: "service",
				tech: "REST",
				parent: "he-thong",
				x: 244,
				y: 80
			},
			{
				id: "db",
				label: "CSDL",
				kind: "database",
				tech: "Oracle",
				parent: "he-thong",
				x: 444,
				y: 80
			},
			{
				id: "queue",
				label: "Hàng đợi sự kiện",
				kind: "queue",
				parent: "he-thong",
				x: 244,
				y: 230
			},
			{
				id: "email",
				label: "Dịch vụ email",
				kind: "external",
				x: 960,
				y: 230
			}
		],
		edges: [
			{
				id: "e1",
				from: "user",
				to: "web",
				label: "dùng"
			},
			{
				id: "e2",
				from: "web",
				to: "api",
				label: "HTTPS"
			},
			{
				id: "e3",
				from: "api",
				to: "db",
				label: "SQL",
				kind: "data"
			},
			{
				id: "e4",
				from: "api",
				to: "queue",
				label: "phát sự kiện",
				kind: "async"
			},
			{
				id: "e5",
				from: "queue",
				to: "email",
				kind: "async"
			}
		]
	};
}
// web/graph/GraphCanvas.jsx
var Le = t(null), Re = 2500, ze = (e) => window.md?.snackbar(e);
function Be() {
	return /* @__PURE__ */ V(z, { children: [
		/* @__PURE__ */ B(k, {
			type: "source",
			position: P.Left,
			id: "l"
		}),
		/* @__PURE__ */ B(k, {
			type: "source",
			position: P.Right,
			id: "r"
		}),
		/* @__PURE__ */ B(k, {
			type: "source",
			position: P.Top,
			id: "t"
		}),
		/* @__PURE__ */ B(k, {
			type: "source",
			position: P.Bottom,
			id: "b"
		})
	] });
}
function Ve({ id: e, selected: t, readOnly: n, min: r }) {
	let a = i(Le);
	return !t || n ? null : /* @__PURE__ */ B(M, {
		minWidth: r[0],
		minHeight: r[1],
		lineClassName: "dg-resize-line",
		handleClassName: "dg-resize-handle",
		onResizeEnd: (t, n) => a.resized(e, n)
	});
}
var He = {
	item: n(function({ data: e }) {
		let t = e.node;
		return /* @__PURE__ */ V("div", {
			className: `dg-n dg-k--${t.kind}${e.diff ? ` dg-d--${e.diff}` : ""}`,
			title: t.note || void 0,
			children: [
				/* @__PURE__ */ B(Be, {}),
				/* @__PURE__ */ B("span", {
					className: "dg-ms dg-n__icon",
					"aria-hidden": "true",
					children: K[t.kind]?.icon || "widgets"
				}),
				/* @__PURE__ */ V("span", {
					className: "dg-n__text",
					children: [/* @__PURE__ */ B("span", {
						className: "dg-n__label",
						children: t.label
					}), /* @__PURE__ */ B("span", {
						className: "dg-n__sub",
						children: t.tech || K[t.kind]?.label
					})]
				}),
				t.note ? /* @__PURE__ */ B("span", {
					className: "dg-ms dg-n__note",
					"aria-label": "Có ghi chú",
					children: "notes"
				}) : null
			]
		});
	}),
	group: n(function({ id: e, data: t, selected: n }) {
		let r = i(Le), a = t.node;
		return /* @__PURE__ */ V("div", {
			className: `dg-g dg-k--${a.kind}${t.diff ? ` dg-d--${t.diff}` : ""}`,
			children: [
				/* @__PURE__ */ B(Ve, {
					id: e,
					selected: n,
					readOnly: t.readOnly,
					min: [160, 84]
				}),
				/* @__PURE__ */ B(Be, {}),
				/* @__PURE__ */ V("div", {
					className: "dg-g__head",
					children: [
						/* @__PURE__ */ B("button", {
							type: "button",
							className: "nodrag dg-g__btn dg-ms",
							title: "Đóng nhóm (thành một khối)",
							onClick: () => r.toggle(e),
							children: "unfold_less"
						}),
						/* @__PURE__ */ B("span", {
							className: "dg-ms dg-g__icon",
							"aria-hidden": "true",
							children: a.kind === "group" ? "select_all" : K[a.kind]?.icon
						}),
						/* @__PURE__ */ B("span", {
							className: "dg-g__label",
							children: a.label
						}),
						/* @__PURE__ */ B("span", {
							className: "dg-g__count",
							children: t.count
						}),
						/* @__PURE__ */ B("button", {
							type: "button",
							className: "nodrag dg-g__btn dg-ms",
							title: "Mở riêng nhóm này",
							onClick: () => r.focus(e),
							children: "open_in_full"
						})
					]
				})
			]
		});
	}),
	folded: n(function({ id: e, data: t, selected: n }) {
		let r = i(Le), a = t.node;
		return /* @__PURE__ */ V("div", {
			className: `dg-g dg-g--folded dg-k--${a.kind}${t.diff ? ` dg-d--${t.diff}` : ""}`,
			children: [
				/* @__PURE__ */ B(Ve, {
					id: e,
					selected: n,
					readOnly: t.readOnly,
					min: [160, 84]
				}),
				/* @__PURE__ */ B(Be, {}),
				/* @__PURE__ */ V("div", {
					className: "dg-g__head",
					children: [
						/* @__PURE__ */ B("button", {
							type: "button",
							className: "nodrag dg-g__btn dg-ms",
							title: "Mở rộng nhóm",
							onClick: () => r.toggle(e),
							children: "unfold_more"
						}),
						/* @__PURE__ */ B("span", {
							className: "dg-ms dg-g__icon",
							"aria-hidden": "true",
							children: a.kind === "group" ? "select_all" : K[a.kind]?.icon
						}),
						/* @__PURE__ */ B("span", {
							className: "dg-g__label",
							children: a.label
						}),
						/* @__PURE__ */ B("button", {
							type: "button",
							className: "nodrag dg-g__btn dg-ms",
							title: "Mở riêng nhóm này",
							onClick: () => r.focus(e),
							children: "open_in_full"
						})
					]
				}),
				/* @__PURE__ */ V("div", {
					className: "dg-g__fold",
					title: "Bấm đúp để mở nhóm",
					children: [/* @__PURE__ */ B("span", {
						className: "dg-g__big",
						children: a.label
					}), /* @__PURE__ */ V("span", {
						className: "dg-g__sum",
						children: [
							t.count,
							" khối bên trong",
							a.tech ? ` · ${a.tech}` : ""
						]
					})]
				})
			]
		});
	})
}, Ue = {
	type: "smoothstep",
	markerEnd: {
		type: A.ArrowClosed,
		width: 18,
		height: 18,
		color: "var(--dg-edge)"
	}
}, We = (e) => e.type === "group" ? "transparent" : `var(--dg-k-${e.data?.node?.kind || "component"}, #888)`;
function Ge({ target: e }) {
	let t = R((e) => Math.round(e.transform[2] * 100) / 100);
	return a(() => {
		let n = e.current;
		n && (n.style.setProperty("--dg-inv", String(Math.min(8, Math.max(1, 1 / t)))), n.classList.toggle("dg-flow--far", t < .4), n.classList.toggle("dg-flow--tiny", t < .25));
	}, [t, e]), null;
}
function Ke(e, t) {
	let n = s([]), i = s([]), a = s({
		key: null,
		at: 0
	}), [, o] = c(0);
	return {
		commit: r((r, s = null) => {
			if (r === e) return;
			let c = Date.now();
			s && a.current.key === s && c - a.current.at < 1500 || (n.current.push(e), n.current.length > 100 && n.current.shift()), i.current = [], a.current = {
				key: s,
				at: c
			}, t(r), o((e) => e + 1);
		}, [e, t]),
		undo: r(() => {
			n.current.length && (i.current.push(e), a.current = {
				key: null,
				at: 0
			}, t(n.current.pop()), o((e) => e + 1));
		}, [e, t]),
		redo: r(() => {
			i.current.length && (n.current.push(e), t(i.current.pop()), o((e) => e + 1));
		}, [e, t]),
		canUndo: n.current.length > 0,
		canRedo: i.current.length > 0
	};
}
function qe({ doc: t, onChange: n, base: i, readOnly: l, height: u }) {
	let d = ae(), f = s(null), [m, h] = c(null), g = l && m || t, _ = l ? h : n, v = o(() => J(g), [g]), y = o(() => ge(i, g), [i, g]), [b, x] = c(""), [S, C] = c({
		nodes: [],
		edges: []
	}), [w, ee] = c(g.nodes.length < Re), [T, E] = c(!1), [D, k] = c(!1), A = s(null), M = s(!1), [P, I] = c(0), { commit: R, undo: H, redo: U, canUndo: oe, canRedo: se } = Ke(g, _), ce = o(() => ({ focus: b }), [b]), W = o(() => ve(g, v, ce, y, l), [
		g,
		v,
		ce,
		y,
		l
	]), [le, G] = c(W.nodes), [de, q] = c(W.edges);
	a(() => {
		G((e) => {
			let t = new Set(e.filter((e) => e.selected).map((e) => e.id));
			return t.size ? W.nodes.map((e) => t.has(e.id) ? {
				...e,
				selected: !0
			} : e) : W.nodes;
		}), q((e) => {
			let t = new Set(e.filter((e) => e.selected).map((e) => e.id));
			return t.size ? W.edges.map((e) => t.has(e.id) ? {
				...e,
				selected: !0
			} : e) : W.edges;
		});
	}, [W]), a(() => {
		let e = A.current;
		if (!e) return;
		A.current = null, G((t) => t.map((t) => t.selected === (t.id === e) ? t : {
			...t,
			selected: t.id === e
		}));
		let t = 0, n = () => {
			d.getInternalNode(e)?.internals.positionAbsolute || t > 30 ? d.fitView({
				nodes: [{ id: e }],
				duration: 400,
				maxZoom: 1.1,
				padding: .6
			}) : (t += 1, requestAnimationFrame(n));
		};
		requestAnimationFrame(n);
	}, [
		W,
		d,
		P
	]), a(() => {
		if (M.current) {
			M.current = !1;
			return;
		}
		let e = setTimeout(() => d.fitView({
			duration: 300,
			padding: .16
		}), 30);
		return () => clearTimeout(e);
	}, [b, d]);
	let Y = r((e, t) => {
		let n = null;
		for (let r of W.nodes) {
			if (r.type !== "group" || r.id === t || t && v.ancestors(r.id).includes(t)) continue;
			let i = d.getInternalNode(r.id)?.internals.positionAbsolute;
			i && e.x >= i.x && e.x <= i.x + r.width && e.y >= i.y && e.y <= i.y + r.height && (!n || r.width * r.height < n.area) && (n = {
				id: r.id,
				area: r.width * r.height
			});
		}
		return n?.id || b;
	}, [
		W,
		v,
		d,
		b
	]), pe = r((e, t) => {
		let n = Y(t, null), r = K[e]?.label || "Khối", i = xe(g, be(r), "n"), a = e === "group" ? {
			w: 320,
			h: 200
		} : fe({
			label: r,
			kind: e
		}), o = he(g, v, b), s = n && n !== b ? o.get(n) : {
			x: 0,
			y: 0
		}, c = {
			id: i,
			label: r,
			kind: e,
			x: Math.round(t.x - s.x - a.w / 2),
			y: Math.round(t.y - s.y - a.h / 2)
		};
		n && (c.parent = n), e === "group" && Object.assign(c, a), A.current = i, R($(Se(g, c)));
	}, [
		g,
		v,
		b,
		Y,
		R
	]), me = () => {
		let e = f.current?.getBoundingClientRect();
		return d.screenToFlowPosition({
			x: e.left + e.width / 2,
			y: e.top + e.height / 2
		});
	}, _e = o(() => ({
		toggle: (e) => R(Ne(g, e), null),
		focus: (e) => x(e),
		resized: (e, t) => R($(Z(g, /* @__PURE__ */ new Map([[e, {
			x: Math.round(t.x),
			y: Math.round(t.y),
			w: Math.round(t.width),
			h: Math.round(t.height)
		}]]))))
	}), [g, R]), ye = r((e) => G((t) => re(e, t)), []), Ce = r((e) => q((t) => L(e, t)), []), X = r(({ nodes: e, edges: t }) => {
		C({
			nodes: e.map((e) => e.id),
			edges: t.filter((e) => !e.id.startsWith("sum:")).map((e) => e.id)
		});
	}, []), we = r((e, t, n) => {
		let r = g, i = new Map(n.map((e) => [e.id, {
			x: Math.round(e.position.x),
			y: Math.round(e.position.y)
		}]));
		r = Z(r, i);
		let a = J(r);
		for (let e of n) {
			if (n.some((t) => t.id !== e.id && a.ancestors(e.id).includes(t.id))) continue;
			let t = d.getInternalNode(e.id)?.internals.positionAbsolute;
			if (!t) continue;
			let i = Y({
				x: t.x + e.width / 2,
				y: t.y + e.height / 2
			}, e.id);
			(i || "") !== (a.byId.get(e.id)?.parent || "") && (r = De(r, a, e.id, i, b), a = J(r));
		}
		R($(r));
	}, [
		g,
		d,
		Y,
		b,
		R
	]), Q = r(({ source: e, target: t }) => R(Te(g, e, t)), [g, R]), Oe = r((e, t) => {
		if (t?.isValid || !t?.fromNode) return;
		let n = "changedTouches" in e ? e.changedTouches[0] : e, r = (document.elementFromPoint(n.clientX, n.clientY)?.closest(".react-flow__node"))?.getAttribute("data-id"), i = t.fromNode.id;
		r && r !== i && !r.startsWith("sum:") && R(Te(g, i, r));
	}, [g, R]), ke = r(({ nodes: e, edges: t }) => {
		let n = e.map((e) => e.id), r = t.map((e) => e.id).filter((e) => !e.startsWith("sum:"));
		(n.length || r.length) && R(Ee(g, v, n, r));
	}, [
		g,
		v,
		R
	]), Ae = (e) => {
		let t = e.dataTransfer.getData("application/x-dg-kind");
		t && !l && (e.preventDefault(), pe(t, d.screenToFlowPosition({
			x: e.clientX,
			y: e.clientY
		})));
	}, Pe = async (e = g.direction) => {
		k(!0);
		try {
			let t = await ie(je(g, v, b), {
				direction: e,
				nodeGap: 28,
				rankGap: 90,
				padding: 24,
				header: 44
			});
			R(Me({
				...g,
				direction: e
			}, v, t, b)), setTimeout(() => d.fitView({
				duration: 300,
				padding: .16
			}), 60);
		} catch (e) {
			ze(`Không sắp xếp được: ${e.message}`);
		} finally {
			k(!1);
		}
	}, Fe = (e) => {
		if (!v.byId.has(e)) return;
		let t = v.ancestors(e), n = !b || t.includes(b), r = t.slice(0, b && n ? t.indexOf(b) : t.length).some((e) => v.byId.get(e)?.folded);
		if (!n || r) {
			let e = r ? t[0] : "";
			e !== b && (M.current = !0, x(e));
		}
		A.current = e, I((e) => e + 1);
	};
	a(() => {
		let e = (e) => {
			let t = e.composedPath?.()[0] || e.target;
			if ([
				"INPUT",
				"TEXTAREA",
				"SELECT"
			].includes(t?.tagName) || t?.isContentEditable || !f.current?.contains(document.activeElement) && document.activeElement !== document.body) return;
			let n = e.ctrlKey || e.metaKey;
			n && e.key.toLowerCase() === "z" && !l ? (e.preventDefault(), e.shiftKey ? U() : H()) : n && e.key.toLowerCase() === "y" && !l ? (e.preventDefault(), U()) : e.key === "Escape" && T && E(!1);
		};
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}, [
		H,
		U,
		T,
		l
	]);
	let Ie = b ? [...v.ancestors(b).reverse(), b] : [], Be = W.nodes.length, Ve = T ? void 0 : { height: u };
	return /* @__PURE__ */ B(Le.Provider, {
		value: _e,
		children: /* @__PURE__ */ V("div", {
			className: `dg-graph${T ? " dg-graph--full" : ""}${l ? " dg-graph--ro" : ""}`,
			style: Ve,
			children: [/* @__PURE__ */ B("div", {
				className: "dg-flow",
				ref: f,
				onDragOver: (e) => {
					l || (e.preventDefault(), e.dataTransfer.dropEffect = "copy");
				},
				onDrop: Ae,
				children: /* @__PURE__ */ V(F, {
					nodes: le,
					edges: de,
					nodeTypes: He,
					defaultEdgeOptions: Ue,
					onNodesChange: ye,
					onEdgesChange: Ce,
					onSelectionChange: X,
					onNodeDragStop: l ? void 0 : we,
					onConnect: l ? void 0 : Q,
					onConnectEnd: l ? void 0 : Oe,
					onDelete: l ? void 0 : ke,
					onNodeDoubleClick: (e, t) => {
						t.type === "folded" && _e.focus(t.id);
					},
					connectionMode: te.Loose,
					nodesDraggable: !l,
					nodesConnectable: !l,
					deleteKeyCode: l ? null : ["Delete", "Backspace"],
					multiSelectionKeyCode: [
						"Shift",
						"Meta",
						"Control"
					],
					onlyRenderVisibleElements: g.nodes.length > 300,
					minZoom: .02,
					maxZoom: 2.5,
					fitView: !0,
					fitViewOptions: { padding: .16 },
					elevateNodesOnSelect: !1,
					proOptions: { hideAttribution: !0 },
					snapToGrid: !0,
					snapGrid: [4, 4],
					zoomOnDoubleClick: !1,
					children: [
						/* @__PURE__ */ B(O, {
							gap: 24,
							size: 1
						}),
						/* @__PURE__ */ B(Ge, { target: f }),
						/* @__PURE__ */ B(ne, {
							showInteractive: !1,
							position: "bottom-left"
						}),
						w ? /* @__PURE__ */ B(j, {
							pannable: !0,
							zoomable: !0,
							nodeColor: We,
							position: "bottom-right"
						}) : null,
						l ? null : /* @__PURE__ */ B(N, {
							position: "top-left",
							className: "dg-palette",
							"aria-label": "Thêm khối",
							children: ue.map(([e, t, n]) => /* @__PURE__ */ B("button", {
								type: "button",
								className: "dg-palette__item",
								draggable: !0,
								title: `${t}: kéo vào canvas (hoặc bấm để thêm vào giữa)`,
								onDragStart: (t) => {
									t.dataTransfer.setData("application/x-dg-kind", e), t.dataTransfer.effectAllowed = "copy";
								},
								onClick: () => pe(e, me()),
								children: /* @__PURE__ */ B("span", {
									className: "dg-ms",
									children: n
								})
							}, e))
						}),
						/* @__PURE__ */ V(N, {
							position: "top-right",
							className: "dg-tools",
							children: [
								l ? null : /* @__PURE__ */ V(z, { children: [
									/* @__PURE__ */ B(p, {
										icon: "undo",
										label: "Hoàn tác (Ctrl+Z)",
										disabled: !oe,
										onClick: H
									}),
									/* @__PURE__ */ B(p, {
										icon: "redo",
										label: "Làm lại (Ctrl+Shift+Z)",
										disabled: !se,
										onClick: U
									}),
									/* @__PURE__ */ B(p, {
										icon: "account_tree",
										label: b ? "Tự sắp xếp trong nhóm này" : "Tự sắp xếp toàn bộ",
										disabled: D,
										onClick: () => Pe()
									}),
									/* @__PURE__ */ B(p, {
										icon: g.direction === "TB" ? "swap_horiz" : "swap_vert",
										disabled: D,
										label: g.direction === "TB" ? "Sắp xếp trái → phải" : "Sắp xếp trên → dưới",
										onClick: () => Pe(g.direction === "TB" ? "LR" : "TB")
									})
								] }),
								/* @__PURE__ */ B(p, {
									icon: "map",
									label: w ? "Ẩn bản đồ nhỏ" : "Hiện bản đồ nhỏ",
									selected: w,
									toggle: !0,
									onClick: () => ee((e) => !e)
								}),
								/* @__PURE__ */ B(p, {
									icon: T ? "close_fullscreen" : "open_in_full",
									label: T ? "Thoát toàn màn hình (Esc)" : "Toàn màn hình",
									onClick: () => E((e) => !e)
								})
							]
						}),
						Ie.length ? /* @__PURE__ */ V(N, {
							position: "top-left",
							className: "dg-crumbs",
							children: [/* @__PURE__ */ V("button", {
								type: "button",
								onClick: () => x(""),
								children: [/* @__PURE__ */ B("span", {
									className: "dg-ms",
									children: "home"
								}), "Toàn bộ"]
							}), Ie.map((t) => /* @__PURE__ */ V(e.Fragment, { children: [/* @__PURE__ */ B("span", {
								className: "dg-ms",
								children: "chevron_right"
							}), /* @__PURE__ */ B("button", {
								type: "button",
								onClick: () => x(t),
								disabled: t === b,
								children: v.byId.get(t)?.label
							})] }, t))]
						}) : null,
						!g.nodes.length && !l ? /* @__PURE__ */ B(N, {
							position: "top-center",
							className: "dg-hint",
							children: "Kéo một khối từ thanh bên trái vào đây. Nối hai khối: kéo từ chấm ở cạnh khối này sang khối kia."
						}) : null,
						/* @__PURE__ */ V(N, {
							position: "bottom-center",
							className: "dg-status",
							children: [
								g.nodes.length,
								" khối · ",
								g.edges.length,
								" cạnh",
								Be < g.nodes.length ? ` · đang hiện ${Be}` : ""
							]
						})
					]
				})
			}), /* @__PURE__ */ B(Qe, {
				doc: g,
				idx: v,
				diff: y,
				selection: S,
				readOnly: l,
				commit: R,
				focus: b,
				setFocus: _e.focus,
				toggle: _e.toggle,
				goTo: Fe
			})]
		})
	});
}
function Je({ doc: e, goTo: t }) {
	let [n, r] = c(""), i = o(() => {
		let t = n.toLowerCase().split(/\s+/).filter(Boolean);
		if (!t.length) return [];
		let r = [];
		for (let n of e.nodes) {
			let e = `${n.id} ${n.label} ${n.tech || ""} ${n.note || ""}`.toLowerCase();
			if (t.every((t) => e.includes(t)) && r.push(n), r.length >= 30) break;
		}
		return r;
	}, [e, n]);
	return /* @__PURE__ */ V("div", {
		className: "dg-search",
		children: [/* @__PURE__ */ B(g, {
			label: "Tìm khối",
			leadingIcon: "search",
			value: n,
			onChange: r,
			onKeyDown: (e) => {
				e.key === "Enter" && i[0] && t(i[0].id);
			}
		}), i.length ? /* @__PURE__ */ B("div", {
			className: "dg-search__hits",
			children: i.map((e) => /* @__PURE__ */ V("button", {
				type: "button",
				className: "dg-row",
				onClick: () => t(e.id),
				children: [/* @__PURE__ */ B("span", {
					className: "dg-ms",
					children: K[e.kind]?.icon
				}), /* @__PURE__ */ V("span", {
					className: "dg-row__text",
					children: [/* @__PURE__ */ B("span", {
						className: "dg-row__name",
						children: e.label
					}), /* @__PURE__ */ B("span", {
						className: "md-body-small md-muted",
						children: e.id
					})]
				})]
			}, e.id))
		}) : n.trim() ? /* @__PURE__ */ B("p", {
			className: "md-body-small md-muted",
			children: "Không có khối khớp."
		}) : null]
	});
}
function Ye({ doc: e, idx: t, id: n, readOnly: r, commit: i, focus: a, setFocus: o, toggle: s }) {
	let c = t.byId.get(n);
	if (!c) return null;
	let u = t.isGroup(n), d = (t) => (r) => i(Ce(e, n, { [t]: r }), `${n}:${t}`), f = c.parent ? t.byId.get(c.parent) : null, p = t.count.get(n) || 0;
	return /* @__PURE__ */ V("div", {
		className: "md-stack dg-form nokey",
		children: [
			/* @__PURE__ */ V("div", {
				className: "md-row",
				children: [
					/* @__PURE__ */ B("span", {
						className: "dg-ms",
						children: K[c.kind]?.icon
					}),
					/* @__PURE__ */ B("span", {
						className: "md-title-small dg-grow",
						children: u ? "Nhóm" : K[c.kind]?.label
					}),
					/* @__PURE__ */ B("span", {
						className: "md-body-small md-muted",
						title: "id (AI dùng id này)",
						children: c.id
					})
				]
			}),
			/* @__PURE__ */ B(g, {
				label: "Tên",
				value: c.label,
				readOnly: r,
				maxLength: 200,
				onChange: d("label")
			}),
			/* @__PURE__ */ B(h, {
				label: "Loại",
				value: c.kind,
				disabled: r,
				onChange: (t) => i(Ce(e, n, { kind: t })),
				options: ue.map(([e, t]) => [e, t])
			}),
			/* @__PURE__ */ B(g, {
				label: "Công nghệ (vd. Java, Oracle, Kafka)",
				value: c.tech || "",
				readOnly: r,
				maxLength: 120,
				onChange: d("tech")
			}),
			/* @__PURE__ */ B(g, {
				label: "Ghi chú (AI đọc được)",
				type: "textarea",
				rows: 4,
				value: c.note || "",
				readOnly: r,
				maxLength: 2e3,
				onChange: d("note")
			}),
			f ? /* @__PURE__ */ V("div", {
				className: "md-body-small",
				children: [
					"Trong nhóm ",
					/* @__PURE__ */ B("b", { children: f.label }),
					r ? null : /* @__PURE__ */ V(z, { children: [" · ", /* @__PURE__ */ B("a", {
						href: "#",
						onClick: (r) => {
							r.preventDefault(), i($(De(e, t, n, f.parent || "", a)));
						},
						children: "đưa ra ngoài"
					})] })
				]
			}) : null,
			u ? /* @__PURE__ */ V("div", {
				className: "dg-form__row",
				children: [
					/* @__PURE__ */ V("span", {
						className: "md-body-small md-muted dg-grow",
						children: [p, " khối bên trong"]
					}),
					a === n ? null : /* @__PURE__ */ B(l, {
						icon: c.folded ? "unfold_more" : "unfold_less",
						onClick: () => s(n),
						children: c.folded ? "Mở tại chỗ" : "Đóng lại"
					}),
					a === n ? null : /* @__PURE__ */ B(l, {
						icon: "open_in_full",
						onClick: () => o(n),
						children: "Mở riêng"
					})
				]
			}) : null,
			r ? null : /* @__PURE__ */ B(l, {
				icon: "delete",
				danger: !0,
				onClick: () => i(Ee(e, t, [n], [])),
				children: u && p ? `Xoá nhóm và ${p} khối bên trong` : "Xoá"
			})
		]
	});
}
function Xe({ doc: e, idx: t, id: n, readOnly: r, commit: i }) {
	let a = e.edges.find((e) => e.id === n);
	if (!a) return null;
	let o = (e) => t.byId.get(e)?.label || e;
	return /* @__PURE__ */ V("div", {
		className: "md-stack dg-form nokey",
		children: [
			/* @__PURE__ */ V("div", {
				className: "md-title-small",
				children: [
					o(a.from),
					" → ",
					o(a.to)
				]
			}),
			/* @__PURE__ */ B(g, {
				label: "Nhãn (vd. REST /orders, Kafka topic)",
				value: a.label || "",
				readOnly: r,
				maxLength: 200,
				onChange: (t) => i(we(e, n, { label: t }), `${n}:label`)
			}),
			/* @__PURE__ */ B(h, {
				label: "Kiểu",
				value: a.kind || "sync",
				disabled: r,
				onChange: (t) => i(we(e, n, { kind: t === "sync" ? null : t })),
				options: de
			}),
			r ? null : /* @__PURE__ */ V("div", {
				className: "dg-form__row",
				children: [/* @__PURE__ */ B(l, {
					icon: "swap_horiz",
					onClick: () => i(we(e, n, {
						from: a.to,
						to: a.from
					})),
					children: "Đảo chiều"
				}), /* @__PURE__ */ B(l, {
					icon: "delete",
					danger: !0,
					onClick: () => i(Ee(e, t, [], [n])),
					children: "Xoá"
				})]
			})
		]
	});
}
function Ze({ diff: e, idx: t, goTo: n }) {
	if (!e) return null;
	let r = [...e.nodes].filter(([, e]) => e === "add").map(([e]) => e), i = [...e.nodes].filter(([, e]) => e === "change").map(([e]) => e), a = [...e.edges.values()].filter((e) => e === "add").length, o = [...e.edges.values()].filter((e) => e === "change").length, s = (e) => e.slice(0, 60).map((e) => /* @__PURE__ */ B("button", {
		type: "button",
		className: "dg-row",
		onClick: () => n(e),
		children: /* @__PURE__ */ B("span", {
			className: "dg-row__text",
			children: /* @__PURE__ */ B("span", {
				className: "dg-row__name",
				children: t.byId.get(e)?.label || e
			})
		})
	}, e));
	return /* @__PURE__ */ V("div", {
		className: "md-stack dg-changes",
		children: [
			/* @__PURE__ */ B("div", {
				className: "md-title-small",
				children: "Thay đổi so với bản hiện tại"
			}),
			/* @__PURE__ */ V("div", {
				className: "md-body-small",
				children: [
					/* @__PURE__ */ V("span", {
						className: "dg-chip dg-d--add",
						children: [
							"+",
							r.length,
							" khối"
						]
					}),
					" ",
					/* @__PURE__ */ V("span", {
						className: "dg-chip dg-d--change",
						children: [
							"~",
							i.length,
							" khối"
						]
					}),
					" ",
					/* @__PURE__ */ V("span", {
						className: "dg-chip dg-d--remove",
						children: [
							"−",
							e.removedNodes.length,
							" khối"
						]
					}),
					" ",
					"· cạnh +",
					a,
					" ~",
					o,
					" −",
					e.removedEdges.length
				]
			}),
			r.length ? /* @__PURE__ */ V(z, { children: [/* @__PURE__ */ B("div", {
				className: "md-label-medium",
				children: "Thêm"
			}), s(r)] }) : null,
			i.length ? /* @__PURE__ */ V(z, { children: [/* @__PURE__ */ B("div", {
				className: "md-label-medium",
				children: "Sửa"
			}), s(i)] }) : null,
			e.removedNodes.length ? /* @__PURE__ */ V(z, { children: [/* @__PURE__ */ B("div", {
				className: "md-label-medium",
				children: "Xoá"
			}), e.removedNodes.slice(0, 60).map((e) => /* @__PURE__ */ V("div", {
				className: "md-body-small dg-removed",
				children: [
					e.label,
					" ",
					/* @__PURE__ */ V("span", {
						className: "md-muted",
						children: [
							"(",
							e.id,
							")"
						]
					})
				]
			}, e.id))] }) : null
		]
	});
}
function Qe({ doc: e, idx: t, diff: n, selection: r, readOnly: i, commit: a, focus: o, setFocus: s, toggle: c, goTo: u }) {
	let { nodes: d, edges: f } = r, p;
	return p = d.length === 1 && !f.length ? /* @__PURE__ */ B(Ye, {
		doc: e,
		idx: t,
		id: d[0],
		readOnly: i,
		commit: a,
		focus: o,
		setFocus: s,
		toggle: c
	}, d[0]) : f.length === 1 && !d.length ? /* @__PURE__ */ B(Xe, {
		doc: e,
		idx: t,
		id: f[0],
		readOnly: i,
		commit: a
	}, f[0]) : d.length + f.length > 1 ? /* @__PURE__ */ V("div", {
		className: "md-stack dg-form",
		children: [
			/* @__PURE__ */ V("div", {
				className: "md-title-small",
				children: [
					"Đã chọn ",
					d.length,
					" khối, ",
					f.length,
					" cạnh"
				]
			}),
			!i && d.length ? /* @__PURE__ */ B(l, {
				icon: "select_all",
				onClick: () => {
					let n = Oe(e, t, d);
					n.error ? ze(n.error) : a(n.doc);
				},
				children: "Gom vào nhóm mới"
			}) : null,
			i ? null : /* @__PURE__ */ B(l, {
				icon: "delete",
				danger: !0,
				onClick: () => a(Ee(e, t, d, f)),
				children: "Xoá các mục đã chọn"
			})
		]
	}) : n ? /* @__PURE__ */ B(Ze, {
		diff: n,
		idx: t,
		goTo: u
	}) : /* @__PURE__ */ B("div", {
		className: "md-body-small md-muted dg-help",
		children: i ? /* @__PURE__ */ B("p", { children: "Bấm một khối hoặc cạnh để xem chi tiết." }) : /* @__PURE__ */ V(z, { children: [
			/* @__PURE__ */ V("p", { children: [/* @__PURE__ */ B("b", { children: "Thêm khối:" }), " kéo biểu tượng ở góc trái vào canvas (thả vào trong một nhóm để đặt khối vào nhóm đó)."] }),
			/* @__PURE__ */ V("p", { children: [/* @__PURE__ */ B("b", { children: "Nối:" }), " kéo từ chấm ở cạnh một khối sang khối khác."] }),
			/* @__PURE__ */ V("p", { children: [/* @__PURE__ */ B("b", { children: "Chọn nhiều:" }), " giữ Shift rồi kéo một vùng, hoặc Shift + bấm."] }),
			/* @__PURE__ */ V("p", { children: [
				/* @__PURE__ */ B("b", { children: "Xoá:" }),
				" phím Delete. ",
				/* @__PURE__ */ B("b", { children: "Hoàn tác:" }),
				" Ctrl+Z."
			] }),
			/* @__PURE__ */ V("p", { children: [/* @__PURE__ */ B("b", { children: "Hệ thống lớn:" }), " thu gọn nhóm, hoặc mở riêng một nhóm; ô tìm kiếm đưa tới đúng khối."] })
		] })
	}), /* @__PURE__ */ V("aside", {
		className: "dg-inspector",
		children: [/* @__PURE__ */ B(Je, {
			doc: e,
			goTo: u
		}), p]
	});
}
function $e(e) {
	return /* @__PURE__ */ B(I, { children: /* @__PURE__ */ B(qe, { ...e }) });
}
// web/graph/GraphPage.jsx
var et = (e) => window.md?.snackbar(e), tt = "max(520px, calc(100vh - 330px))", nt = 600;
async function rt(e) {
	let t = ke(e);
	if (!t) return e;
	if (t < .3) return Ae(e);
	e.nodes.length > nt && (e = Pe(e));
	let n = J(e), r = await ie(je(e, n), {
		direction: e.direction,
		nodeGap: 28,
		rankGap: 90,
		padding: 24,
		header: 44
	});
	return Me(e, n, r);
}
function it(e) {
	let [t, n] = c(null), [r, i] = c(null), [o, s] = c(null);
	return a(() => {
		let t = !0;
		if (n(null), e) return rt(e).then((e) => {
			t && (i(e), n(e));
		}, (e) => t && s(e)), () => {
			t = !1;
		};
	}, [e]), [
		t,
		n,
		o,
		r
	];
}
function at(e) {
	return (e || "so-do").replace(/[\\/:*?"<>|]+/g, "-").trim() || "so-do";
}
function ot({ name: e, description: t, doc: n }) {
	return /* @__PURE__ */ V(z, { children: [/* @__PURE__ */ B(p, {
		icon: "data_object",
		label: "Tải JSON (import lại được, AI đọc được)",
		onClick: () => U(`${at(e)}.json`, new Blob([JSON.stringify({
			name: e,
			description: t,
			graph: n
		}, null, 1)], { type: "application/json" }))
	}), /* @__PURE__ */ B(p, {
		icon: "content_copy",
		label: "Copy dạng Mermaid flowchart",
		onClick: async () => {
			try {
				await navigator.clipboard.writeText(Fe(n)), et("Đã copy Mermaid (flowchart)");
			} catch {
				et("Trình duyệt không cho copy");
			}
		}
	})] });
}
function st({ api: e, id: t, draft: n, guard: r, onBack: i, onSaved: s }) {
	let u = C(() => t ? e.get(`/diagrams/${t}`) : Promise.resolve(null), [t]), [d, h] = c(null), v = d || u.data?.diagram || null, [y, S, w, T] = it(o(() => v ? v.graph : n?.graph || q(), [v, n])), [E, D] = c(n?.name || ""), [O, te] = c(n?.description || ""), [ne, k] = c(""), [A, j] = c(!1), [M, N] = b(), [P, F] = x();
	ee(v?.name || E || "Sơ đồ hệ thống mới"), a(() => {
		v && (D(v.name), te(v.description || ""));
	}, [v?.id, v?.version]);
	let I = v ? !!y && y !== T || E !== v.name || O !== (v.description || "") : !!y && y.nodes.length > 0, L = () => {
		if (!E.trim()) {
			et("Đặt tên cho sơ đồ trước khi lưu");
			return;
		}
		let t = v ? e.put(`/diagrams/${v.id}`, {
			graph: y,
			baseVersion: v.version,
			name: E,
			description: O,
			note: ne
		}) : e.post("/diagrams", {
			format: "graph",
			graph: y,
			name: E,
			description: O
		});
		return M(() => t, "Đã lưu").then((e) => {
			e && (k(""), h(e.diagram), s(e.diagram));
		});
	};
	return a(() => (r.current = async () => !I || P({
		title: "Bỏ các thay đổi chưa lưu?",
		text: "Những gì vừa vẽ / sửa sẽ mất.",
		confirm: "Bỏ thay đổi",
		icon: "undo"
	}), () => {
		r.current = null;
	})), a(() => {
		let e = (e) => {
			(e.ctrlKey || e.metaKey) && e.key === "s" && (e.preventDefault(), !N && I && L());
		};
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}), t && u.error ? /* @__PURE__ */ B(f, { children: u.error.message }) : w ? /* @__PURE__ */ V(f, { children: ["Không vẽ được sơ đồ: ", w.message] }) : t && !v || !y ? /* @__PURE__ */ B(m, {}) : /* @__PURE__ */ V(z, { children: [
		F,
		A && v ? /* @__PURE__ */ B(ct, {
			api: e,
			diagram: v,
			onClose: () => j(!1),
			onRestored: (e) => {
				h(e), s(e);
			}
		}) : null,
		/* @__PURE__ */ V("div", {
			className: "md-stack",
			children: [/* @__PURE__ */ B("section", {
				className: "md-card md-card--outlined dg-head",
				children: /* @__PURE__ */ V("div", {
					className: "md-card__body md-stack",
					children: [/* @__PURE__ */ V("div", {
						className: "md-row dg-toolbar",
						children: [
							/* @__PURE__ */ B("span", {
								className: "dg-back",
								children: /* @__PURE__ */ B(p, {
									icon: "arrow_back",
									label: "Danh sách sơ đồ",
									onClick: () => i(!1)
								})
							}),
							/* @__PURE__ */ B(_, {
								icon: "hub",
								children: "Sơ đồ hệ thống"
							}),
							v ? /* @__PURE__ */ V("span", {
								className: "md-body-small md-muted",
								children: [
									"bản ",
									v.version,
									" · ",
									v.updated
								]
							}) : null,
							v?.by === "ai" ? /* @__PURE__ */ B(_, {
								tone: "warning",
								icon: "smart_toy",
								children: "AI lưu"
							}) : null,
							I ? /* @__PURE__ */ B(_, {
								tone: "warning",
								children: "chưa lưu"
							}) : null,
							/* @__PURE__ */ B("span", { className: "md-spacer" }),
							/* @__PURE__ */ B(ot, {
								name: E,
								description: O,
								doc: y
							}),
							v ? /* @__PURE__ */ B(p, {
								icon: "history",
								label: `Lịch sử (${v.versions} bản)`,
								onClick: () => j(!0)
							}) : null,
							v ? /* @__PURE__ */ B(p, {
								icon: "delete",
								danger: !0,
								label: "Xoá sơ đồ",
								onClick: async () => {
									await P({
										title: `Xoá sơ đồ “${v.name}”?`,
										text: `Sơ đồ và cả ${v.versions} bản đã lưu bị xoá hẳn, AI cũng không đọc được nữa. Không hoàn tác được.`,
										confirm: "Xoá",
										icon: "delete"
									}) && M(() => e.delete(`/diagrams/${v.id}`), "Đã xoá").then((e) => {
										e && (r.current = null, i(!0));
									});
								}
							}) : null,
							/* @__PURE__ */ B(l, {
								variant: "filled",
								icon: "save",
								onClick: L,
								title: "Lưu (Ctrl+S)",
								disabled: N || !I,
								children: "Lưu"
							})
						]
					}), /* @__PURE__ */ V("div", {
						className: "dg-meta",
						children: [
							/* @__PURE__ */ B(g, {
								label: "Tên sơ đồ",
								value: E,
								onChange: D,
								maxLength: 120
							}),
							/* @__PURE__ */ B(g, {
								label: "Mô tả (AI đọc để biết sơ đồ nói gì)",
								value: O,
								onChange: te,
								maxLength: 1e3
							}),
							v ? /* @__PURE__ */ B(g, {
								label: "Ghi chú cho bản sắp lưu (tuỳ chọn)",
								value: ne,
								onChange: k,
								maxLength: 200
							}) : null
						]
					})]
				})
			}), /* @__PURE__ */ B($e, {
				doc: y,
				onChange: S,
				height: tt
			}, `${v?.id || "new"}-${v?.version || 0}`)]
		})
	] });
}
function ct({ api: e, diagram: t, onClose: n, onRestored: r }) {
	let [i, a] = c(null), [o, s] = b(), [d, f] = x(), p = (n) => o(() => e.get(`/diagrams/${t.id}/versions/${n}`)).then((e) => e && a(e.version)), m = async (i) => {
		await d({
			title: `Khôi phục bản ${i.v}?`,
			text: "Sơ đồ của bản này thành bản mới nhất. Các bản khác vẫn được giữ.",
			confirm: "Khôi phục",
			icon: "history",
			danger: !1
		}) && o(() => e.post(`/diagrams/${t.id}/versions/${i.v}/restore`), `Đã khôi phục bản ${i.v}`).then((e) => {
			e && (r(e.diagram), n());
		});
	};
	return /* @__PURE__ */ V(u, {
		headline: `Các bản đã lưu: ${t.name}`,
		icon: "history",
		onClose: n,
		wide: !0,
		actions: (e) => /* @__PURE__ */ B(l, {
			onClick: e,
			children: "Đóng"
		}),
		children: [f, /* @__PURE__ */ V("div", {
			className: "dg-history",
			children: [/* @__PURE__ */ B("div", {
				className: "md-list dg-history__list",
				children: t.history.map((e) => /* @__PURE__ */ V("button", {
					type: "button",
					className: `dg-history__item${i?.v === e.v ? " dg-history__item--on" : ""}`,
					onClick: () => p(e.v),
					children: [
						/* @__PURE__ */ V("span", {
							className: "md-title-small",
							children: ["Bản ", e.v]
						}),
						" ",
						e.v === t.version ? /* @__PURE__ */ B(_, {
							tone: "primary",
							children: "hiện tại"
						}) : null,
						" ",
						e.by === "ai" ? /* @__PURE__ */ B(_, {
							icon: "smart_toy",
							children: "AI"
						}) : null,
						/* @__PURE__ */ V("div", {
							className: "md-body-small md-muted",
							children: [e.at, e.summary ? ` · ${e.summary}` : ""]
						}),
						e.note ? /* @__PURE__ */ B("div", {
							className: "md-body-small",
							children: e.note
						}) : null
					]
				}, e.v))
			}), /* @__PURE__ */ B("div", {
				className: "dg-history__view",
				children: i ? /* @__PURE__ */ V(z, { children: [
					/* @__PURE__ */ V("div", {
						className: "md-row",
						children: [
							/* @__PURE__ */ V("span", {
								className: "md-title-small",
								children: [
									"Bản ",
									i.v,
									": ",
									i.graph.nodes.length,
									" khối, ",
									i.graph.edges.length,
									" cạnh"
								]
							}),
							/* @__PURE__ */ B("span", { className: "md-spacer" }),
							i.v === t.version ? null : /* @__PURE__ */ B(l, {
								icon: "history",
								disabled: s,
								onClick: () => m(i),
								children: "Khôi phục bản này"
							})
						]
					}),
					/* @__PURE__ */ B(lt, {
						source: i.graph,
						base: i.v === t.version ? null : t.graph
					}, i.v),
					i.v === t.version ? null : /* @__PURE__ */ B("p", {
						className: "md-body-small md-muted",
						children: "Tô màu: khác biệt của bản này so với bản hiện tại."
					})
				] }) : /* @__PURE__ */ B("p", {
					className: "md-muted",
					children: "Chọn một bản để xem."
				})
			})]
		})]
	});
}
function lt({ source: e, base: t }) {
	let [n, , r] = it(e);
	return r ? /* @__PURE__ */ B(f, { children: r.message }) : n ? /* @__PURE__ */ B($e, {
		doc: n,
		base: t,
		readOnly: !0,
		onChange: () => {},
		height: "60vh"
	}) : /* @__PURE__ */ B(m, {});
}
// web/diagram.css?inline
var ut = ".dg-toolbar{flex-wrap:wrap;gap:8px}.dg-search{min-width:220px}.dg-grid{grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px;display:grid}.dg-item{text-align:left;font:inherit;color:inherit;cursor:pointer;background:0 0;padding:0}.dg-item:focus-visible{outline-offset:2px;outline:2px solid}.dg-tags{flex-wrap:wrap;gap:6px;margin:6px 0}.dg-desc{-webkit-line-clamp:3;-webkit-box-orient:vertical;margin-bottom:4px;display:-webkit-box;overflow:hidden}.dg-meta{grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;display:grid}.dg-split{grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:start;gap:12px;display:grid}.dg-pane{min-width:0}.dg-note{flex:1;max-width:520px}.dg-code,.dg-code-view{tab-size:4;color:inherit;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:13px;line-height:1.5}.dg-code{box-sizing:border-box;resize:vertical;white-space:pre;background:0 0;border:1px solid #7f7f7f73;border-radius:8px;width:100%;min-height:max(360px,100vh - 400px);padding:10px 12px}.dg-code:focus{outline-offset:-1px;outline:2px solid}.dg-code-view{white-space:pre-wrap;word-break:break-word;max-height:420px;margin:8px 0 0;overflow:auto}.dg-preview{min-height:120px;overflow:auto}.dg-canvas{justify-content:center;display:flex}.dg-canvas svg{max-width:100%;height:auto}.dg-canvas--stale{opacity:.45}.dg-error{white-space:pre-wrap;opacity:.9;border-left:3px solid;margin:0 0 8px;padding:8px 10px}.dg-templates{flex-wrap:wrap;gap:8px;display:flex}.dg-history{grid-template-columns:240px minmax(0,1fr);gap:16px;min-width:min(900px,80vw);display:grid}.dg-history__list{max-height:60vh;overflow:auto}.dg-history__item{text-align:left;width:100%;font:inherit;color:inherit;cursor:pointer;background:0 0;border:0;border-radius:8px;padding:8px 10px;display:block}.dg-history__item:hover,.dg-history__item--on{background:#7f7f7f26}.dg-history__view{min-width:0;max-height:60vh;overflow:auto}@media (width<=900px){.dg-split,.dg-meta,.dg-history{grid-template-columns:1fr}}.dg-shell{grid-template-columns:300px minmax(0,1fr);align-items:start;gap:16px;display:grid}.dg-side{flex-direction:column;max-height:calc(100vh - 140px);display:flex;position:sticky;top:8px;overflow:hidden}.dg-side__head{flex-direction:column;gap:12px;padding:12px;display:flex}.dg-side__list{flex:1;padding:4px 0 8px;overflow:auto}.dg-side__note{margin:8px 16px 12px}.dg-row{width:100%;color:inherit;font:inherit;text-align:left;cursor:pointer;background:0 0;border:0;align-items:center;gap:10px;padding:8px 16px;display:flex}.dg-row:hover{background:#7f7f7f1a}.dg-row:focus-visible{outline-offset:-2px;outline:2px solid}.dg-row--on{background:#7f7f7f2e;box-shadow:inset 3px 0}.dg-row__text{flex-direction:column;flex:1;gap:2px;min-width:0;display:flex}.dg-row__name{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.dg-row md-icon{--md-icon-size:18px;opacity:.8}.dg-main{min-width:0}.dg-back{display:none}.dg-head>.md-card__body{gap:12px;padding-block:12px 4px}.dg-head .dg-toolbar{min-height:40px}.dg-side{overflow:visible}.dg-side__list{min-height:0}.dg-welcome{padding:48px 24px}.dg-welcome .md-empty p{max-width:560px;margin-inline:auto}.dg-new{position:relative}.dg-new__caret{--md-icon-size:20px;vertical-align:middle;margin-inline:2px -6px}.dg-menu{z-index:20;background:var(--md-sys-color-surface-container,#f3edf7);min-width:280px;color:var(--md-sys-color-on-surface,inherit);border-radius:12px;padding:6px 0;position:absolute;top:calc(100% + 4px);left:0;box-shadow:0 4px 16px #00000047}.dg-menu__item{width:100%;color:inherit;font:var(--md-sys-typescale-body-large,inherit);text-align:left;cursor:pointer;background:0 0;border:0;align-items:center;gap:12px;padding:8px 16px;display:flex}.dg-menu__item:hover,.dg-menu__item:focus-visible{background:#7f7f7f24;outline:none}.dg-menu__item md-icon{--md-icon-size:20px;opacity:.85}.dg-menu__sep{background:var(--md-sys-color-outline-variant,#7f7f7f4d);height:1px;margin:6px 0}@media (width<=1000px){.dg-shell{grid-template-columns:1fr}.dg-side{max-height:none;position:static}.dg-shell--open .dg-side,.dg-shell:not(.dg-shell--open) .dg-main{display:none}}.dg-template-select{min-width:200px}.dg-split--editor{align-items:stretch}.dg-split--editor .dg-preview{min-height:max(360px,100vh - 400px)}", dt = ".dg-graph{--dg-edge:var(--md-sys-color-outline,#79747e);--dg-k-person:#2e7d32;--dg-k-system:#1565c0;--dg-k-external:#6d6d6d;--dg-k-app:#00838f;--dg-k-service:#3949ab;--dg-k-component:#5e35b1;--dg-k-database:#ad1457;--dg-k-queue:#ef6c00;--dg-k-storage:#8d6e63;--dg-k-job:#00897b;--dg-k-group:#546e7a;--dg-k-note:#b28704;--dg-add:#2e7d32;--dg-change:#e08a00;--dg-remove:#c62828;border:1px solid var(--md-sys-color-outline-variant,#7f7f7f66);background:var(--md-sys-color-surface,transparent);border-radius:12px;grid-template-columns:minmax(0,1fr) 300px;min-height:480px;display:grid;overflow:hidden}.dg-graph--full{z-index:900;border-radius:0;height:100vh;position:fixed;inset:0}.dg-flow{--dg-inv:1;min-width:0;height:100%;position:relative}.dg-flow .react-flow{--xy-background-color:var(--md-sys-color-surface-container-lowest,transparent);--xy-background-pattern-color:var(--md-sys-color-outline-variant,#ccc);--xy-edge-stroke:var(--dg-edge);--xy-edge-stroke-selected:var(--md-sys-color-primary);--xy-connectionline-stroke:var(--md-sys-color-primary);--xy-edge-label-background-color:var(--md-sys-color-surface-container-lowest,#fff);--xy-edge-label-color:var(--md-sys-color-on-surface-variant,#444);--xy-minimap-background-color:var(--md-sys-color-surface-container,#f4f4f4);--xy-minimap-mask-background-color:color-mix(in srgb, var(--md-sys-color-on-surface,#000) 12%, transparent);--xy-controls-button-background-color:var(--md-sys-color-surface-container-high,#fff);--xy-controls-button-background-color-hover:var(--md-sys-color-surface-container-highest,#eee);--xy-controls-button-color:var(--md-sys-color-on-surface,#222);--xy-controls-button-border-color:var(--md-sys-color-outline-variant,#ddd);--xy-selection-background-color:color-mix(in srgb, var(--md-sys-color-primary) 10%, transparent);--xy-selection-border:1px dotted var(--md-sys-color-primary);--xy-node-boxshadow-selected:none;--xy-node-border-radius:10px;color:var(--md-sys-color-on-surface)}.dg-ms{font-family:var(--md-icon-font,\"Material Symbols Outlined\");letter-spacing:normal;text-transform:none;white-space:nowrap;font-feature-settings:\"liga\";-webkit-font-smoothing:antialiased;direction:ltr;font-size:20px;font-style:normal;font-weight:400;line-height:1}.react-flow__node-item{background:0 0;border:0;padding:0}.dg-n{box-sizing:border-box;background:var(--md-sys-color-surface-container-low,#fff);border:1px solid var(--md-sys-color-outline-variant,#ccc);width:100%;height:100%;box-shadow:inset 4px 0 0 var(--dg-k,#888);font:var(--md-sys-typescale-body-medium);border-radius:10px;align-items:center;gap:10px;padding:8px 12px 8px 14px;display:flex}.dg-n__icon{color:var(--dg-k);flex:none}.dg-n__text{flex-direction:column;flex:1;min-width:0;display:flex;overflow:hidden}.dg-n__label{-webkit-line-clamp:2;-webkit-box-orient:vertical;font-weight:500;line-height:1.25;display:-webkit-box;overflow:hidden}.dg-n__sub{font:var(--md-sys-typescale-body-small);color:var(--md-sys-color-on-surface-variant);white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.dg-n__note{color:var(--md-sys-color-on-surface-variant);flex:none;font-size:16px}.dg-k--person{--dg-k:var(--dg-k-person)}.dg-k--system{--dg-k:var(--dg-k-system)}.dg-k--external{--dg-k:var(--dg-k-external)}.dg-k--app{--dg-k:var(--dg-k-app)}.dg-k--service{--dg-k:var(--dg-k-service)}.dg-k--component{--dg-k:var(--dg-k-component)}.dg-k--database{--dg-k:var(--dg-k-database)}.dg-k--queue{--dg-k:var(--dg-k-queue)}.dg-k--storage{--dg-k:var(--dg-k-storage)}.dg-k--job{--dg-k:var(--dg-k-job)}.dg-k--group{--dg-k:var(--dg-k-group)}.dg-k--note{--dg-k:var(--dg-k-note)}.dg-n.dg-k--external{border-style:dashed}.dg-n.dg-k--note{background:color-mix(in srgb, var(--dg-k-note) 14%, var(--md-sys-color-surface-container-low,#fff))}.dg-n.dg-k--person,.dg-n.dg-k--database{border-radius:22px}.react-flow__node.selected>.dg-n,.react-flow__node.selected>.dg-g{outline:2px solid var(--md-sys-color-primary);outline-offset:2px}.react-flow__node-group,.react-flow__node-folded{background:0 0;border:0;border-radius:12px;padding:0}.dg-g{box-sizing:border-box;border:1.5px dashed color-mix(in srgb, var(--dg-k,#888) 70%, transparent);background:color-mix(in srgb, var(--dg-k,#888) 6%, transparent);border-radius:12px;width:100%;height:100%}.dg-g__head{align-items:center;gap:6px;height:44px;padding:0 8px 0 6px;display:flex;position:relative}.dg-g__icon{color:var(--dg-k);font-size:18px}.dg-g__label{font:var(--md-sys-typescale-title-small);white-space:nowrap;text-overflow:ellipsis;flex:1;font-weight:600;overflow:hidden}.dg-g__count{font:var(--md-sys-typescale-label-small);color:var(--md-sys-color-on-surface-variant);background:var(--md-sys-color-surface-container-high,#7f7f7f26);border-radius:8px;padding:2px 6px}.dg-g__btn{color:var(--md-sys-color-on-surface-variant);cursor:pointer;background:0 0;border:0;border-radius:50%;flex:none;justify-content:center;align-items:center;width:28px;height:28px;font-size:18px;display:inline-flex}.dg-g--folded{background:color-mix(in srgb, var(--dg-k,#888) 12%, var(--md-sys-color-surface-container-low,#fff));border-style:solid;flex-direction:column;display:flex}.dg-g__fold{color:inherit;flex-direction:column;flex:1;justify-content:center;align-items:center;gap:6px;min-height:0;padding:0 16px 24px;display:flex;overflow:hidden}.dg-g__big{font:var(--md-sys-typescale-headline-small);font-size:calc(22px * min(var(--dg-inv), 6));text-align:center;-webkit-line-clamp:3;-webkit-box-orient:vertical;max-width:100%;line-height:1.15;display:-webkit-box;overflow:hidden}.dg-g__sum{font:var(--md-sys-typescale-body-medium);font-size:calc(14px * min(var(--dg-inv), 6));color:var(--md-sys-color-on-surface-variant)}.dg-g--folded .dg-g__head .dg-g__label{visibility:hidden}.dg-g__btn:hover{background:var(--md-sys-color-surface-container-highest,#7f7f7f33)}.dg-flow .react-flow__handle{border:2px solid var(--md-sys-color-surface,#fff);background:var(--md-sys-color-primary);opacity:0;width:9px;height:9px;transition:opacity .12s}.dg-flow .react-flow__node:hover .react-flow__handle,.dg-flow .react-flow__node.selected .react-flow__handle,.dg-flow .react-flow.connecting .react-flow__handle,.dg-flow .react-flow__handle.connectingto{opacity:1}.dg-graph--ro .react-flow__handle{visibility:hidden}.dg-flow .react-flow__resize-control{z-index:4}.dg-flow .react-flow__handle{z-index:6}.dg-flow .react-flow__handle:before{content:\"\";inset:calc(-7px * min(var(--dg-inv), 3));border-radius:50%;position:absolute}.dg-flow .dg-resize-handle{background:var(--md-sys-color-primary);border:1px solid var(--md-sys-color-surface);border-radius:2px;width:9px;height:9px}.dg-flow .dg-resize-line{border-color:var(--md-sys-color-primary)}.react-flow__edge.dg-e--async .react-flow__edge-path{stroke-dasharray:7 5}.react-flow__edge.dg-e--data .react-flow__edge-path{stroke-width:2.2px}.react-flow__edge.dg-e--dependency .react-flow__edge-path{stroke-dasharray:2 4}.react-flow__edge.dg-e--sum .react-flow__edge-path{stroke-dasharray:3 3;opacity:.75}.react-flow__edge-text{font:var(--md-sys-typescale-label-small)}.dg-n.dg-d--add,.dg-g.dg-d--add{border:2px solid var(--dg-add);box-shadow:inset 4px 0 0 var(--dg-add), 0 0 0 4px color-mix(in srgb, var(--dg-add) 18%, transparent)}.dg-n.dg-d--change,.dg-g.dg-d--change{border:2px solid var(--dg-change);box-shadow:inset 4px 0 0 var(--dg-change), 0 0 0 4px color-mix(in srgb, var(--dg-change) 18%, transparent)}.react-flow__edge.dg-d--add .react-flow__edge-path{stroke:var(--dg-add);stroke-width:2.5px}.react-flow__edge.dg-d--change .react-flow__edge-path{stroke:var(--dg-change);stroke-width:2.5px}.dg-chip{color:#fff;border-radius:10px;padding:1px 8px;font-weight:600;display:inline-block}.dg-chip.dg-d--add{background:var(--dg-add)}.dg-chip.dg-d--change{background:var(--dg-change)}.dg-chip.dg-d--remove{background:var(--dg-remove)}.dg-removed{color:var(--dg-remove);text-decoration:line-through}.dg-flow--far .dg-n__sub,.dg-flow--far .dg-n__note,.dg-flow--far .react-flow__edge-textwrapper,.dg-flow--far .dg-g__count,.dg-flow--far .dg-g__btn{display:none}.dg-flow--tiny .react-flow__handle{visibility:hidden}.dg-flow--far .dg-g__label{max-width:calc(100% - 16px);font-size:calc(15px * var(--dg-inv));line-height:1.1;position:absolute;bottom:6px;left:8px}.dg-flow--tiny .dg-n__icon,.dg-flow--tiny .dg-n__label{visibility:hidden}.dg-flow--tiny .dg-n{box-shadow:inset 8px 0 0 var(--dg-k)}.dg-palette{background:var(--md-sys-color-surface-container,#f4f4f4);box-shadow:var(--md-sys-elevation-1,0 1px 3px #0003);border-radius:12px;flex-direction:column;gap:2px;padding:4px;display:flex}.dg-palette__item{cursor:grab;width:36px;height:36px;color:var(--md-sys-color-on-surface);background:0 0;border:0;border-radius:8px;justify-content:center;align-items:center;display:flex}.dg-palette__item:hover{background:var(--md-sys-color-surface-container-highest,#7f7f7f33)}.dg-tools{background:var(--md-sys-color-surface-container,#f4f4f4);box-shadow:var(--md-sys-elevation-1,0 1px 3px #0003);border-radius:24px;flex-direction:column;gap:2px;padding:2px;display:flex}.dg-flow .react-flow__panel.dg-crumbs{margin-left:64px}.dg-crumbs{background:var(--md-sys-color-secondary-container);max-width:calc(100% - 150px);color:var(--md-sys-color-on-secondary-container);font:var(--md-sys-typescale-label-large);border-radius:18px;align-items:center;gap:2px;padding:4px 10px;display:flex;overflow:hidden}.dg-crumbs button{color:inherit;font:inherit;cursor:pointer;white-space:nowrap;text-overflow:ellipsis;background:0 0;border:0;border-radius:10px;align-items:center;gap:4px;max-width:220px;padding:2px 6px;display:inline-flex;overflow:hidden}.dg-crumbs button:hover:not(:disabled){background:#7f7f7f33}.dg-crumbs button:disabled{cursor:default;font-weight:600}.dg-crumbs .dg-ms{font-size:16px}.dg-hint{text-align:center;background:var(--md-sys-color-surface-container-high);max-width:420px;font:var(--md-sys-typescale-body-medium);border-radius:12px;margin-top:64px;padding:10px 16px}.dg-status{font:var(--md-sys-typescale-label-small);color:var(--md-sys-color-on-surface-variant);background:color-mix(in srgb, var(--md-sys-color-surface) 80%, transparent);border-radius:10px;padding:2px 10px}.dg-inspector{border-left:1px solid var(--md-sys-color-outline-variant,#7f7f7f66);background:var(--md-sys-color-surface-container-low,transparent);flex-direction:column;gap:16px;min-height:0;padding:12px;display:flex;overflow:auto}.dg-inspector md-outlined-text-field,.dg-inspector md-outlined-select{width:100%}.dg-search__hits{max-height:240px;margin-top:4px;overflow:auto}.dg-search .dg-row,.dg-changes .dg-row{border-radius:8px;padding:6px 8px}.dg-form__row{flex-wrap:wrap;align-items:center;gap:8px;display:flex}.dg-grow{flex:1;min-width:0}.dg-help p{margin:0 0 8px}@media (width<=1000px){.dg-graph{grid-template-rows:minmax(420px,1fr) auto;grid-template-columns:1fr}.dg-inspector{border-left:0;border-top:1px solid var(--md-sys-color-outline-variant);max-height:360px}}";
// web/index.jsx
if (!document.getElementById("vh-diagram-css")) {
	let e = document.createElement("style");
	e.id = "vh-diagram-css", e.textContent = `${ut}\n${dt}`, document.head.appendChild(e);
}
var ft = (e) => e && e.target ? e.target.value : e, pt = ".drawio,.dio,.xml,.json,.mmd,.mermaid,.md,.puml,.plantuml,.pu,.iuml,.wsd", mt = 20971520, ht = {
	mermaid: "Mermaid",
	plantuml: "PlantUML",
	drawio: "draw.io",
	graph: "Hệ thống"
}, gt = (e) => window.md?.snackbar(e), _t = (e) => e.format === "graph" ? `Hệ thống · ${e.stats?.nodes ?? 0} khối` : e.type && e.type !== e.format ? `${ht[e.format] || e.format} · ${e.type}` : ht[e.format] || e.format;
function vt({ text: e, delay: t = 300 }) {
	let n = s(null), [r, i] = c(null), [o, l] = c(!1);
	return a(() => {
		let r = !0;
		if (!e?.trim()) {
			n.current?.replaceChildren(), i(null);
			return;
		}
		let a = setTimeout(async () => {
			l(!0);
			try {
				let { svg: t } = await H(e);
				if (!r || !n.current) return;
				let a = D(t);
				a.removeAttribute("height"), n.current.replaceChildren(a), i(null);
			} catch (e) {
				r && i(String(e?.message || e).split("\n").slice(0, 6).join("\n"));
			} finally {
				r && l(!1);
			}
		}, t);
		return () => {
			r = !1, clearTimeout(a);
		};
	}, [e, t]), /* @__PURE__ */ V("div", {
		className: "dg-preview",
		children: [r ? /* @__PURE__ */ B("pre", {
			className: "dg-error md-body-small",
			children: r
		}) : null, /* @__PURE__ */ B("div", {
			ref: n,
			className: `dg-canvas${r || o ? " dg-canvas--stale" : ""}`
		})]
	});
}
function yt({ format: e, text: t }) {
	return e === "plantuml" ? /* @__PURE__ */ V("div", {
		className: "dg-preview",
		children: [/* @__PURE__ */ B(d, {
			icon: "visibility_off",
			title: "Không xem trước được PlantUML"
		}), /* @__PURE__ */ B("p", {
			className: "md-body-small md-muted",
			children: "Nội dung được lưu nguyên văn để AI đọc. Muốn xem hình, chuyển sơ đồ sang Mermaid."
		})]
	}) : /* @__PURE__ */ B(vt, { text: t });
}
function bt({ name: e, text: t, format: n, copyText: r }) {
	let [i, a] = b(), o = (e || "so-do").replace(/[\\/:*?"<>|]+/g, "-").trim() || "so-do", s = async () => {
		try {
			await navigator.clipboard.writeText(r ?? t), gt(n === "mermaid" || n === "drawio" ? "Đã copy Mermaid" : "Đã copy nội dung");
		} catch {
			gt("Trình duyệt không cho copy");
		}
	}, c = n !== "plantuml";
	return /* @__PURE__ */ V(z, { children: [
		/* @__PURE__ */ B(l, {
			icon: "content_copy",
			onClick: s,
			children: n === "plantuml" ? "Copy text" : "Copy Mermaid"
		}),
		c ? /* @__PURE__ */ B(l, {
			icon: "image",
			disabled: a,
			onClick: () => i(async () => U(`${o}.svg`, await se(t)), "Đã xuất SVG"),
			children: "SVG"
		}) : null,
		c ? /* @__PURE__ */ B(l, {
			icon: "photo",
			disabled: a,
			onClick: () => i(async () => U(`${o}.png`, await ce(t)), "Đã xuất PNG"),
			children: "PNG"
		}) : null
	] });
}
function xt({ api: e, diagram: t, onClose: n, onRestored: r }) {
	let [i, a] = c(null), [o, s] = b(), [d, f] = x(), p = (n) => o(() => e.get(`/diagrams/${t.id}/versions/${n}`)).then((e) => e && a(e.version)), m = async (i) => {
		await d({
			title: `Khôi phục bản ${i.v}?`,
			text: "Nội dung bản này thành bản mới nhất. Các bản khác vẫn được giữ.",
			confirm: "Khôi phục",
			icon: "history",
			danger: !1
		}) && o(() => e.post(`/diagrams/${t.id}/versions/${i.v}/restore`), `Đã khôi phục bản ${i.v}`).then((e) => {
			e && (r(e.diagram), n());
		});
	};
	return /* @__PURE__ */ V(u, {
		headline: `Các bản đã lưu: ${t.name}`,
		icon: "history",
		onClose: n,
		actions: (e) => /* @__PURE__ */ B(l, {
			onClick: e,
			children: "Đóng"
		}),
		children: [f, /* @__PURE__ */ V("div", {
			className: "dg-history",
			children: [/* @__PURE__ */ B("div", {
				className: "md-list dg-history__list",
				children: t.history.map((e) => /* @__PURE__ */ V("button", {
					type: "button",
					className: `dg-history__item${i?.v === e.v ? " dg-history__item--on" : ""}`,
					onClick: () => p(e.v),
					children: [
						/* @__PURE__ */ V("span", {
							className: "md-title-small",
							children: ["Bản ", e.v]
						}),
						" ",
						e.v === t.version ? /* @__PURE__ */ B(_, {
							tone: "primary",
							children: "hiện tại"
						}) : null,
						" ",
						e.by === "ai" ? /* @__PURE__ */ B(_, {
							icon: "smart_toy",
							children: "AI"
						}) : null,
						/* @__PURE__ */ V("div", {
							className: "md-body-small md-muted",
							children: [e.at, e.note ? ` · ${e.note}` : ""]
						})
					]
				}, e.v))
			}), /* @__PURE__ */ B("div", {
				className: "dg-history__view",
				children: i ? /* @__PURE__ */ V(z, { children: [
					/* @__PURE__ */ V("div", {
						className: "md-row",
						children: [
							/* @__PURE__ */ V("span", {
								className: "md-title-small",
								children: ["Bản ", i.v]
							}),
							/* @__PURE__ */ B("span", { className: "md-spacer" }),
							i.v !== t.version && !t.readOnly ? /* @__PURE__ */ B(l, {
								icon: "history",
								disabled: s,
								onClick: () => m(i),
								children: "Khôi phục bản này"
							}) : null
						]
					}),
					t.format === "mermaid" ? /* @__PURE__ */ B(vt, {
						text: i.content,
						delay: 0
					}) : null,
					/* @__PURE__ */ B("pre", {
						className: "dg-code-view",
						children: i.content
					})
				] }) : /* @__PURE__ */ B("p", {
					className: "md-muted",
					children: "Chọn một bản để xem."
				})
			})]
		})]
	});
}
function St({ api: e, id: t, draft: n, guard: r, onBack: i, onSaved: o }) {
	let s = C(() => t ? e.get(`/diagrams/${t}`) : Promise.resolve(null), [t]), [u, d] = c(null), v = u || s.data?.diagram || null, [y, S] = c(n?.name || ""), [w, T] = c(n?.description || ""), [E, D] = c(n?.content ?? "flowchart LR\n    A --> B\n"), [O, te] = c(""), [ne, k] = c(!1), [A, j] = b(), [M, N] = x();
	ee(v?.name || y || "Sơ đồ mới"), a(() => {
		v && !n && (S(v.name || ""), T(v.description || ""), D(v.content ?? ""));
	}, [v?.id, v?.version]);
	let P = v?.format || "mermaid", F = !!v?.readOnly, I = !v || E !== v.content || y !== v.name || w !== (v.description || ""), L = () => {
		let t = F ? {
			name: y,
			description: w
		} : {
			name: y,
			description: w,
			content: E,
			note: O
		}, n = v ? e.put(`/diagrams/${v.id}`, t) : e.post("/diagrams", t);
		return A(() => n, "Đã lưu").then((e) => {
			e && (te(""), d(e.diagram), o(e.diagram));
		});
	}, re = async (e) => {
		let t = W.find((t) => t[0] === e);
		t && (!E.trim() || E === "flowchart LR\n    A --> B\n" || await M({
			title: `Thay nội dung bằng mẫu ${t[1]}?`,
			text: "Nội dung đang gõ (chưa lưu) sẽ mất.",
			confirm: "Thay",
			icon: "draw",
			danger: !1
		})) && D(t[3]);
	}, ie = async () => {
		await M({
			title: `Xoá sơ đồ “${v.name}”?`,
			text: `Sơ đồ và cả ${v.versions} bản đã lưu bị xoá hẳn, AI cũng không đọc được nữa. Không hoàn tác được.`,
			confirm: "Xoá",
			icon: "delete"
		}) && A(() => e.delete(`/diagrams/${v.id}`), "Đã xoá").then((e) => {
			e && (r.current = null, i(!0));
		});
	}, ae = !F && I && (v ? !0 : E.trim() !== "flowchart LR\n    A --> B" && E.trim() !== (n?.content || "").trim());
	if (a(() => (r.current = async () => !ae || M({
		title: "Bỏ các thay đổi chưa lưu?",
		text: "Nội dung vừa sửa sẽ mất.",
		confirm: "Bỏ thay đổi",
		icon: "undo"
	}), () => {
		r.current = null;
	})), a(() => {
		let e = (e) => {
			(e.ctrlKey || e.metaKey) && e.key === "s" && (e.preventDefault(), !j && y.trim() && E.trim() && (!v || I) && L());
		};
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}), t && s.error) return /* @__PURE__ */ B(f, { children: s.error.message });
	if (t && !v) return /* @__PURE__ */ B(m, {});
	let R = F ? v.preview : E;
	return /* @__PURE__ */ V(z, { children: [
		N,
		ne && v ? /* @__PURE__ */ B(xt, {
			api: e,
			diagram: v,
			onClose: () => k(!1),
			onRestored: (e) => {
				D(e.content), d(e), o(e);
			}
		}) : null,
		/* @__PURE__ */ V("div", {
			className: "md-stack",
			children: [/* @__PURE__ */ B("section", {
				className: "md-card md-card--outlined dg-head",
				children: /* @__PURE__ */ V("div", {
					className: "md-card__body md-stack",
					children: [/* @__PURE__ */ V("div", {
						className: "md-row dg-toolbar",
						children: [
							/* @__PURE__ */ B("span", {
								className: "dg-back",
								children: /* @__PURE__ */ B(p, {
									icon: "arrow_back",
									label: "Danh sách sơ đồ",
									onClick: () => i(!1)
								})
							}),
							v ? /* @__PURE__ */ B(_, { children: _t(v) }) : /* @__PURE__ */ B(_, {
								icon: "code",
								children: "Mermaid"
							}),
							v ? /* @__PURE__ */ V("span", {
								className: "md-body-small md-muted",
								children: [
									"bản ",
									v.version,
									" · ",
									v.updated
								]
							}) : null,
							v?.by === "ai" ? /* @__PURE__ */ B(_, {
								tone: "warning",
								icon: "smart_toy",
								children: "AI lưu"
							}) : null,
							F ? /* @__PURE__ */ B(_, {
								tone: "primary",
								icon: "lock",
								children: "Chỉ đọc"
							}) : null,
							/* @__PURE__ */ B("span", { className: "md-spacer" }),
							/* @__PURE__ */ B(bt, {
								name: y,
								text: R,
								format: P,
								copyText: F ? v.preview : E
							}),
							v ? /* @__PURE__ */ V(l, {
								icon: "history",
								onClick: () => k(!0),
								children: [
									"Lịch sử (",
									v.versions,
									")"
								]
							}) : null,
							v ? /* @__PURE__ */ B(p, {
								icon: "delete",
								danger: !0,
								label: "Xoá sơ đồ",
								onClick: ie
							}) : null,
							/* @__PURE__ */ B(l, {
								variant: "filled",
								icon: "save",
								onClick: L,
								title: "Lưu (Ctrl+S)",
								disabled: j || !y.trim() || !E.trim() || v && !I,
								children: F ? "Lưu tên và mô tả" : "Lưu"
							})
						]
					}), /* @__PURE__ */ V("div", {
						className: "dg-meta",
						children: [
							/* @__PURE__ */ B(g, {
								label: "Tên sơ đồ",
								value: y,
								onChange: (e) => S(ft(e)),
								maxLength: 120
							}),
							/* @__PURE__ */ B(g, {
								label: "Mô tả (AI đọc để biết sơ đồ nói gì)",
								value: w,
								onChange: (e) => T(ft(e)),
								maxLength: 1e3
							}),
							v && !F ? /* @__PURE__ */ B(g, {
								label: "Ghi chú cho bản sắp lưu (tuỳ chọn)",
								value: O,
								onChange: (e) => te(ft(e)),
								maxLength: 200
							}) : null
						]
					})]
				})
			}), /* @__PURE__ */ V("div", {
				className: "dg-split dg-split--editor",
				children: [/* @__PURE__ */ B("section", {
					className: "md-card md-card--outlined dg-pane",
					children: /* @__PURE__ */ B("div", {
						className: "md-card__body md-stack",
						children: F ? /* @__PURE__ */ V(z, { children: [/* @__PURE__ */ B("div", {
							className: "md-title-small",
							children: "Node và cạnh (từ file draw.io)"
						}), /* @__PURE__ */ B("pre", {
							className: "dg-code-view",
							children: v.graphText
						})] }) : /* @__PURE__ */ V(z, { children: [/* @__PURE__ */ V("div", {
							className: "md-row",
							children: [
								/* @__PURE__ */ B("span", {
									className: "md-title-small",
									children: P === "plantuml" ? "PlantUML" : "Mermaid"
								}),
								/* @__PURE__ */ B("span", { className: "md-spacer" }),
								P === "mermaid" ? /* @__PURE__ */ B(h, {
									className: "dg-template-select",
									label: "Mẫu",
									value: "",
									onChange: (e) => re(ft(e)),
									options: [["", "Chọn mẫu…"], ...W.map((e) => [e[0], e[1]])]
								}) : null
							]
						}), /* @__PURE__ */ B("textarea", {
							className: "dg-code",
							spellCheck: !1,
							value: E,
							"aria-label": "Nội dung sơ đồ",
							onChange: (e) => D(e.target.value),
							onKeyDown: (e) => {
								if (e.key === "Tab" && !e.shiftKey) {
									e.preventDefault();
									let t = e.target, n = t.selectionStart, r = t.selectionEnd, i = E.slice(0, n) + "    " + E.slice(r);
									D(i), requestAnimationFrame(() => {
										t.selectionStart = t.selectionEnd = n + 4;
									});
								}
							}
						})] })
					})
				}), /* @__PURE__ */ B("section", {
					className: "md-card md-card--outlined dg-pane",
					children: /* @__PURE__ */ V("div", {
						className: "md-card__body",
						children: [/* @__PURE__ */ B(yt, {
							format: F ? "mermaid" : P,
							text: R
						}), F ? /* @__PURE__ */ B("p", {
							className: "md-body-small md-muted",
							children: "Hình xem trước do Mermaid tự xếp, không giống bố cục gốc của draw.io."
						}) : null]
					})
				})]
			})]
		})
	] });
}
var Ct = [
	[
		"hub",
		"Sơ đồ hệ thống",
		"Kéo thả khối, nhóm lồng nhau; cho cả hệ thống lớn",
		() => ({
			format: "graph",
			graph: q(),
			name: ""
		})
	],
	[
		"lightbulb",
		"Sơ đồ hệ thống từ ví dụ",
		"Bắt đầu với vài khối mẫu",
		() => ({
			format: "graph",
			graph: Ie(),
			name: ""
		})
	],
	null,
	...W.map(([e, t, n, r]) => [
		n,
		`Mermaid · ${t}`,
		null,
		() => ({
			content: r,
			name: ""
		})
	]),
	[
		"draft",
		"Mermaid · Trống",
		null,
		() => ({
			content: le,
			name: ""
		})
	]
];
function wt({ onNew: e }) {
	let [t, n] = c(!1), r = s(null);
	return a(() => {
		if (!t) return;
		let e = (e) => {
			r.current?.contains(e.target) || n(!1);
		}, i = (e) => {
			e.key === "Escape" && n(!1);
		};
		return document.addEventListener("pointerdown", e), document.addEventListener("keydown", i), r.current?.querySelector(".dg-menu__item")?.focus(), () => {
			document.removeEventListener("pointerdown", e), document.removeEventListener("keydown", i);
		};
	}, [t]), /* @__PURE__ */ V("div", {
		className: "dg-new",
		ref: r,
		children: [/* @__PURE__ */ V(l, {
			variant: "filled",
			icon: "add",
			onClick: () => n((e) => !e),
			title: "Chọn loại sơ đồ",
			children: ["Sơ đồ mới", /* @__PURE__ */ B("md-icon", {
				class: "dg-new__caret",
				children: t ? "arrow_drop_up" : "arrow_drop_down"
			})]
		}), t ? /* @__PURE__ */ B("div", {
			className: "dg-menu",
			role: "menu",
			children: Ct.map((t, r) => t ? /* @__PURE__ */ V("button", {
				type: "button",
				role: "menuitem",
				className: "dg-menu__item",
				onClick: () => {
					n(!1), e(t[3]());
				},
				children: [/* @__PURE__ */ B("md-icon", { children: t[0] }), /* @__PURE__ */ V("span", {
					className: "dg-row__text",
					children: [/* @__PURE__ */ B("span", { children: t[1] }), t[2] ? /* @__PURE__ */ B("span", {
						className: "md-body-small md-muted",
						children: t[2]
					}) : null]
				})]
			}, t[1]) : /* @__PURE__ */ B("div", {
				className: "dg-menu__sep",
				role: "separator"
			}, `sep${r}`))
		}) : null]
	});
}
function Tt({ api: e, data: t, error: n, reload: r, current: i, go: a }) {
	let [l, u] = c(""), [d, h] = b(), x = s(null), S = v(l).split(/\s+/).filter(Boolean), C = (e) => {
		let t = v(e);
		return S.every((e) => t.includes(e));
	}, w = o(() => (t?.diagrams || []).filter((e) => C(`${e.name} ${e.description || ""} ${e.type} ${e.format}`)), [t, l]);
	return /* @__PURE__ */ V("aside", {
		className: "md-card md-card--outlined dg-side",
		children: [/* @__PURE__ */ V("div", {
			className: "dg-side__head",
			children: [/* @__PURE__ */ V("div", {
				className: "md-row",
				children: [
					/* @__PURE__ */ B(wt, { onNew: (e) => a("/new", e) }),
					/* @__PURE__ */ B("span", { className: "md-spacer" }),
					/* @__PURE__ */ B(p, {
						icon: "upload_file",
						label: "Import .drawio hoặc .json (thành sơ đồ hệ thống), .mmd (Mermaid), .puml (PlantUML)",
						disabled: h,
						onClick: () => x.current?.click()
					}),
					/* @__PURE__ */ B("input", {
						ref: x,
						type: "file",
						accept: pt,
						hidden: !0,
						onChange: async (t) => {
							let n = t.target.files?.[0];
							if (t.target.value = "", !n) return;
							if (n.size > mt) {
								gt("File quá lớn (tối đa 20 MB)");
								return;
							}
							let i = await d(async () => e.post("/import", {
								filename: n.name,
								...await y(n)
							}), `Đã import ${n.name}`);
							i && (r(), a(`/${i.diagram.id}`));
						}
					})
				]
			}), /* @__PURE__ */ B(g, {
				label: "Tìm sơ đồ",
				leadingIcon: "search",
				value: l,
				onChange: (e) => u(ft(e))
			})]
		}), /* @__PURE__ */ V("div", {
			className: "dg-side__list",
			children: [
				n ? /* @__PURE__ */ B(f, { children: n.message }) : null,
				!t && !n ? /* @__PURE__ */ B(m, {}) : null,
				t && !t.diagrams.length ? /* @__PURE__ */ B("p", {
					className: "md-body-small md-muted dg-side__note",
					children: "Chưa có sơ đồ nào."
				}) : null,
				t && t.diagrams.length && !w.length ? /* @__PURE__ */ B("p", {
					className: "md-body-small md-muted dg-side__note",
					children: "Không có sơ đồ khớp."
				}) : null,
				w.map((e) => /* @__PURE__ */ V("button", {
					type: "button",
					className: `dg-row dg-row--item${i === e.id ? " dg-row--on" : ""}`,
					onClick: () => a(`/${e.id}`),
					title: e.description || e.name,
					children: [
						/* @__PURE__ */ V("span", {
							className: "dg-row__text",
							children: [/* @__PURE__ */ B("span", {
								className: "md-title-small dg-row__name",
								children: e.name
							}), /* @__PURE__ */ V("span", {
								className: "md-body-small md-muted",
								children: [
									_t(e),
									" · bản ",
									e.version,
									" · ",
									e.updated.slice(0, 10)
								]
							})]
						}),
						e.by === "ai" ? /* @__PURE__ */ B(_, {
							tone: "warning",
							icon: "smart_toy",
							children: "AI"
						}) : null,
						e.format === "graph" ? /* @__PURE__ */ B("md-icon", {
							title: "Sơ đồ hệ thống",
							children: "hub"
						}) : null,
						e.readOnly ? /* @__PURE__ */ B("md-icon", {
							title: "Chỉ đọc",
							children: "lock"
						}) : null
					]
				}, e.id))
			]
		})]
	});
}
function Et({ count: e }) {
	return ee("Sơ đồ"), /* @__PURE__ */ B("section", {
		className: "md-card md-card--outlined dg-welcome",
		children: /* @__PURE__ */ V(d, {
			icon: "hub",
			title: e ? "Chọn một sơ đồ ở danh sách bên trái" : "Chưa có sơ đồ nào",
			children: [
				"Bấm ",
				/* @__PURE__ */ B("b", { children: "Sơ đồ mới" }),
				" để chọn loại: ",
				/* @__PURE__ */ B("b", { children: "sơ đồ hệ thống" }),
				" (kéo thả khối, nhóm lồng nhau, dùng cho cả hệ thống hàng nghìn khối) hoặc ",
				/* @__PURE__ */ B("b", { children: "Mermaid" }),
				" (flowchart, sequence, ER, state dạng text). Nút import bên cạnh nhận .drawio, .json, .mmd, .puml."
			]
		})
	});
}
function Dt({ module: e, api: t, subpath: n }) {
	S("wide");
	let { navigate: r } = w(), i = C(() => t.get("/diagrams"), []), a = s(null), [o, l] = c(null), u = decodeURIComponent((n || "/").replace(/^\/+|\/+$/g, "")), p = async (t, n = null) => {
		(!a.current || await a.current()) && (a.current = null, l(n ? {
			...n,
			nonce: Date.now()
		} : null), r(`${e.path}${t}`));
	}, h = (t) => {
		i.reload(), l(null), r(`${e.path}/${t.id}`, { replace: !0 });
	}, g, _ = (e) => {
		e && i.reload(), p("/");
	};
	if (u === "proposals" || u.startsWith("proposal/")) g = /* @__PURE__ */ B(Et, { count: i.data?.diagrams.length || 0 });
	else if (u === "new") {
		let e = o || {
			format: "graph",
			graph: q(),
			name: ""
		};
		g = e.format === "graph" ? /* @__PURE__ */ B(st, {
			api: t,
			id: null,
			draft: e,
			guard: a,
			onBack: _,
			onSaved: h
		}, `new-${e.nonce || 0}`) : /* @__PURE__ */ B(St, {
			api: t,
			id: null,
			draft: e,
			guard: a,
			onBack: _,
			onSaved: h
		}, `new-${e.nonce || 0}`);
	} else if (u) {
		let e = i.data?.diagrams.find((e) => e.id === u)?.format;
		g = i.error ? /* @__PURE__ */ B(f, { children: i.error.message }) : !e && (i.loading || !i.data) ? /* @__PURE__ */ B(m, {}) : e ? B(e === "graph" ? st : St, {
			api: t,
			id: u,
			guard: a,
			onBack: _,
			onSaved: () => i.reload()
		}, u) : /* @__PURE__ */ B(d, {
			icon: "search_off",
			title: "Không tìm thấy sơ đồ này",
			children: "Có thể sơ đồ đã bị xoá. Chọn một sơ đồ khác ở danh sách bên trái."
		});
	} else g = /* @__PURE__ */ B(Et, { count: i.data?.diagrams.length || 0 });
	return /* @__PURE__ */ V("div", {
		className: `dg-shell${u ? " dg-shell--open" : ""}`,
		children: [/* @__PURE__ */ B(Tt, {
			api: t,
			...i,
			current: u,
			go: p
		}), /* @__PURE__ */ B("div", {
			className: "dg-main",
			children: g
		})]
	});
}
export { Dt as default };
