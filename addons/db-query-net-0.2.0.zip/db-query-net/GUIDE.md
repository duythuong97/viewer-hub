## DB Query .NET

Cho AI chạy **một câu SELECT** (chỉ đọc) trên Oracle. Giống addon **DB Query**, nhưng nói chuyện với Oracle bằng driver
**.NET** (`Oracle.ManagedDataAccess.Core`). Dùng khi addon **DB Query** báo lỗi `NJS-116` hoặc `NJS-138` (Oracle cũ,
kiểu mật khẩu cũ mà chế độ Thin của Node không hỗ trợ).

- Máy cần có **.NET 8 trở lên** (`dotnet --version`). Viewer Hub tự chạy addon này, bạn không phải mở gì thêm. Chưa có
  .NET thì trang báo "Cần .NET 8+".
- Addon này chỉ có một tool, `db_query`. Muốn xem cấu trúc bảng, AI tự truy vấn `all_tables`, `all_tab_columns`…

### Cách dùng

1. Bấm **Thêm kết nối** (hoặc **Sửa danh sách kết nối**) và nhập mỗi dòng một kết nối:
   `tên | connect string | user | schema | mô tả`. Connect string là `host:port/service`
   (vd. `10.0.0.5:1521/ORCLPDB1`), `tcps://host:port/service` hoặc nguyên chuỗi `(DESCRIPTION=…)` như trong tnsnames.ora.
2. Mỗi kết nối là một thẻ. Gõ mật khẩu rồi bấm **Kiểm tra kết nối**. Thành công thì thẻ chuyển sang **Sẵn sàng**.
3. **Mật khẩu không được lưu**: chỉ giữ trong bộ nhớ của addon, mỗi lần mở lại Viewer Hub phải nhập lại.
   **Quên mật khẩu** xoá nó khỏi bộ nhớ.
4. AI chỉ chạy được câu `SELECT` / `WITH`, tối đa 50 dòng, tối đa 30 giây mỗi câu.

### Tool cho AI

| Tool | AI dùng để |
|---|---|
| `db_query` | Chạy đúng một câu SELECT / WITH trên một kết nối đã nhập mật khẩu, để xem dữ liệu mẫu hoặc cấu trúc bảng (tối đa 50 dòng) |
