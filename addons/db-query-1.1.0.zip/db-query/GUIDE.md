## DB Query

Cho AI chạy **một câu SELECT** (chỉ đọc) trên Oracle để xem dữ liệu mẫu và cấu trúc bảng, ví dụ khi viết data test.
Addon dùng driver **.NET** (`Oracle.ManagedDataAccess.Core`), nên đăng nhập được cả những tài khoản Oracle cũ (kiểu mật
khẩu 10G) mà các driver thuần JavaScript từ chối.

- Máy cần có **.NET 8 trở lên** (`dotnet --version`). Viewer Hub tự chạy addon này, bạn không phải mở gì thêm. Chưa có
  .NET thì trang báo "Cần .NET 8+".
- Addon chỉ có một tool, `db_query`. Muốn xem cấu trúc bảng, AI tự truy vấn `all_tables`, `all_tab_columns`,
  `all_constraints`…

### Cách dùng

1. Bấm **Thêm kết nối** (hoặc **Sửa danh sách kết nối**), bấm **Thêm** và điền các ô của một kết nối:
   - **Tên**, **User**, **Schema** (schema được đọc), **Mô tả** (không bắt buộc).
   - **Cách kết nối**: **Service name** (phổ biến, điền Host, Port mặc định 1521, Service name), **SID** (Oracle cũ, điền
     Host, Port, SID) hoặc **TNS** (dán nguyên chuỗi `(DESCRIPTION=…)` như trong tnsnames.ora).
   - **Giao thức**: chọn **TCPS (SSL)** nếu máy chủ yêu cầu kết nối mã hoá.
2. Mỗi kết nối là một thẻ. Gõ mật khẩu rồi bấm **Kiểm tra kết nối**. Thành công thì thẻ chuyển sang **Sẵn sàng**.
3. **Mật khẩu không được lưu**: chỉ giữ trong bộ nhớ của addon, mỗi lần mở lại Viewer Hub phải nhập lại.
   **Quên mật khẩu** xoá nó khỏi bộ nhớ.
4. AI chỉ chạy được câu `SELECT` / `WITH`, tối đa 50 dòng, tối đa 30 giây mỗi câu.

### Tool cho AI

| Tool | AI dùng để |
|---|---|
| `db_query` | Chạy đúng một câu SELECT / WITH trên một kết nối đã nhập mật khẩu, để xem dữ liệu mẫu hoặc cấu trúc bảng (tối đa 50 dòng) |
