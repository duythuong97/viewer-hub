import { useEffect as e, useMemo as t, useRef as n, useState as r } from "/static/dist/sdk/react.js";
import { Button as i, Dialog as a, Empty as o, ErrorBanner as s, IconButton as c, Loading as l, Select as u, TextField as d } from "/static/dist/sdk/md.js";
import { Badge as f, fold as p, readFileBody as m, useAction as h, useConfirm as g, useLoad as _, useTitle as v } from "/static/dist/sdk/ui.js";
import { Fragment as y, jsx as b, jsxs as x } from "/static/dist/sdk/jsx-runtime.js";
// web/schema.jsx
var S = [
	["minLength", "min length"],
	["maxLength", "max length"],
	["minimum", "min"],
	["maximum", "max"],
	["exclusiveMinimum", ">"],
	["exclusiveMaximum", "<"],
	["minItems", "min items"],
	["maxItems", "max items"],
	["pattern", "pattern"],
	["default", "mặc định"],
	["multipleOf", "bội của"]
], C = (e) => e && typeof e == "object" && !Array.isArray(e), w = (e) => typeof e == "string" ? e : JSON.stringify(e);
function T(e) {
	if (!C(e) || !Array.isArray(e.allOf)) return e;
	let t = { ...e };
	delete t.allOf;
	let n = { ...t.properties || {} }, r = [...t.required || []], i = [];
	for (let a of e.allOf) {
		let e = T(a);
		if (C(e)) {
			if (e.properties || e.type === "object") {
				for (let [t, r] of Object.entries(e.properties || {})) t in n || (n[t] = r);
				for (let t of e.required || []) r.includes(t) || r.push(t);
				!t.description && e.description && (t.description = e.description);
			} else i.push(e);
		}
	}
	return (Object.keys(n).length || !i.length) && (t.type = t.type || "object", t.properties = n, r.length && (t.required = r)), i.length && (t.allOf = i), t;
}
function E(e) {
	if (!C(e)) return "any";
	if (e["x-circular"]) return `${e["x-circular"]} (đệ quy)`;
	if (e["x-truncated"]) return `${e["x-truncated"]} (không mở thêm)`;
	if (e["x-missing-ref"]) return `? ($ref không tìm thấy: ${e["x-missing-ref"]})`;
	let t = T(e), n = Array.isArray(t.type) ? t.type.join(" | ") : t.type, r = t["x-ref"], i;
	return i = n === "array" || !n && t.items ? `array of ${E(t.items)}` : r && (!n || n === "object" || t.properties) ? r : n ? (r ? `${r}: ` : "") + n + (t.format ? ` (${t.format})` : "") : t.properties ? "object" : t.oneOf || t.anyOf ? `${t.oneOf ? "oneOf" : "anyOf"} ${(t.oneOf || t.anyOf).slice(0, 6).map(E).join(" | ")}` : t.enum ? "enum" : "any", Array.isArray(t.enum) && (i += ` [${t.enum.slice(0, 20).map(w).join(", ")}${t.enum.length > 20 ? ", …" : ""}]`), t.nullable && (i += " | null"), i;
}
function D(e) {
	let t = [];
	for (let [n, r] of S) n in e && !C(e[n]) && !Array.isArray(e[n]) && t.push(`${r} ${w(e[n])}`);
	return e.readOnly && t.push("chỉ đọc"), e.writeOnly && t.push("chỉ ghi"), e.deprecated && t.push("deprecated"), t;
}
function O(e) {
	if (!C(e) || e["x-circular"] || e["x-truncated"] || e["x-missing-ref"]) return [];
	let t = T(e);
	if (t.type === "array" || !t.type && t.items) return O(t.items);
	let n = new Set(t.required || []), r = Object.entries(t.properties || {}).map(([e, t]) => [
		e,
		t,
		n.has(e)
	]);
	C(t.additionalProperties) && Object.keys(t.additionalProperties).length && r.push([
		"<khoá bất kỳ>",
		t.additionalProperties,
		!1
	]);
	for (let e of [
		"oneOf",
		"anyOf",
		"allOf"
	]) (t[e] || []).forEach((t, n) => r.push([
		`(${e} ${n + 1})`,
		t,
		!1
	]));
	return r;
}
function k({ name: e, schema: t, required: n, depth: r }) {
	let i = O(t), a = C(t) ? T(t) : {}, o = D(a), s = /* @__PURE__ */ x("span", {
		className: "as-row",
		children: [
			e == null ? null : /* @__PURE__ */ b("span", {
				className: "as-name",
				children: e
			}),
			/* @__PURE__ */ b("span", {
				className: "as-type",
				children: E(t)
			}),
			n ? /* @__PURE__ */ b("span", {
				className: "as-req",
				children: "bắt buộc"
			}) : null,
			o.length ? /* @__PURE__ */ b("span", {
				className: "as-extra",
				children: o.join(", ")
			}) : null,
			a.description ? /* @__PURE__ */ b("span", {
				className: "as-desc",
				children: a.description
			}) : null
		]
	});
	return i.length ? r > 12 ? /* @__PURE__ */ x("div", {
		className: "as-leaf",
		children: [
			s,
			" ",
			/* @__PURE__ */ b("span", {
				className: "md-muted",
				children: "…"
			})
		]
	}) : /* @__PURE__ */ x("details", {
		className: "as-node",
		open: r < 2,
		children: [/* @__PURE__ */ b("summary", { children: s }), /* @__PURE__ */ b("div", {
			className: "as-kids",
			children: i.map(([e, t, n]) => /* @__PURE__ */ b(k, {
				name: e,
				schema: t,
				required: n,
				depth: r + 1
			}, e))
		})]
	}) : /* @__PURE__ */ b("div", {
		className: "as-leaf",
		children: s
	});
}
function A({ schema: e }) {
	return e == null ? /* @__PURE__ */ b("div", {
		className: "md-muted md-body-small",
		children: "(không có)"
	}) : /* @__PURE__ */ b("div", {
		className: "as-tree",
		children: /* @__PURE__ */ b(k, {
			name: null,
			schema: e,
			required: !1,
			depth: 0
		})
	});
}
function j({ value: e, generated: t }) {
	if (e == null) return null;
	let n = typeof e == "string" ? e : JSON.stringify(e, null, 2);
	return /* @__PURE__ */ x("details", {
		className: "as-example",
		children: [/* @__PURE__ */ x("summary", {
			className: "md-body-small",
			children: ["Ví dụ", t ? " (sinh từ schema)" : ""]
		}), /* @__PURE__ */ b("pre", { children: n.length > 2e4 ? `${n.slice(0, 2e4)}\n…` : n })]
	});
}
// web/api.css?inline
var M = ".as-wrap{flex-wrap:wrap;gap:8px}.as-grid{grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px;display:grid}.as-card{text-align:left;font:inherit;color:inherit;cursor:pointer;background:0 0;padding:0}.as-card:focus-visible,.as-item:focus-visible{outline-offset:2px;outline:2px solid}.as-tags{margin:6px 0}.as-clamp{-webkit-line-clamp:3;-webkit-box-orient:vertical;margin-bottom:4px;display:-webkit-box;overflow:hidden}.as-search{min-width:260px}.as-mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}.as-pre{white-space:pre-wrap;margin:6px 0}.as-overview{grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:12px;display:grid}.as-split{grid-template-columns:minmax(280px,2fr) minmax(0,3fr);align-items:start;gap:16px;display:grid}.as-list{min-width:0}.as-detail{min-width:0;max-height:calc(100vh - 32px);position:sticky;top:8px;overflow:auto}.as-group>summary{cursor:pointer;padding:6px 0}.as-item{text-align:left;width:100%;font:inherit;color:inherit;cursor:pointer;background:0 0;border:0;border-radius:8px;flex-wrap:wrap;align-items:center;gap:6px;padding:6px 8px;display:flex}.as-item:hover,.as-item--on{background:#7f7f7f26}.as-path{word-break:break-all}.as-sum{flex-basis:100%;padding-left:4px}.as-method{text-align:center;opacity:.85;border:1px solid;border-radius:4px;min-width:52px;padding:0 4px;font:600 11px/18px ui-monospace,Menlo,Consolas,monospace;display:inline-block}.as-method--delete{border-style:dashed}.as-req{font-size:11px;font-weight:600}.as-tree{padding-left:14px;font-size:13px}.as-node>summary{cursor:pointer;list-style-position:outside}.as-kids{border-left:1px solid #7f7f7f59;margin-left:14px;padding-left:10px}.as-leaf{padding:1px 0 1px 14px}.as-row{flex-wrap:wrap;align-items:baseline;gap:4px 8px;display:inline-flex}.as-name{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-weight:600}.as-type{opacity:.85;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}.as-extra{opacity:.7;font-size:12px}.as-desc{opacity:.75;font-size:12px}.as-example pre,.as-media pre{white-space:pre-wrap;word-break:break-word;background:#7f7f7f1a;border-radius:6px;max-height:360px;margin:4px 0;padding:8px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px;overflow:auto}.as-content{flex-direction:column;gap:8px;margin:6px 0 0 4px;display:flex}.as-response{border-top:1px solid #7f7f7f40;padding:8px 0}.as-file{flex-direction:column;gap:6px;display:flex}.as-dialog{min-width:min(560px,80vw)}@media (width<=900px){.as-split{grid-template-columns:1fr}.as-detail{max-height:none;position:static}}";
// web/index.jsx
if (!document.getElementById("vh-api-specs-css")) {
	let e = document.createElement("style");
	e.id = "vh-api-specs-css", e.textContent = M, document.head.appendChild(e);
}
var N = (e) => e && e.target ? e.target.value : e, P = [
	".yaml",
	".yml",
	".json",
	".wsdl",
	".xsd",
	".xml"
], F = 7340032, I = {
	upload: ["upload_file", "tải lên"],
	folder: ["folder", "thư mục"],
	pack: ["inventory_2", "data pack"]
};
async function L(e, t) {
	let n = [], r = 0;
	for (let i of Array.from(e || [])) {
		let e = i.webkitRelativePath || i.name;
		t && e.includes("/") && (e = e.slice(e.indexOf("/") + 1));
		let a = e.toLowerCase();
		if (P.some((e) => a.endsWith(e)) && !e.split("/").some((e) => e.startsWith(".") || e === "node_modules")) {
			if (r += i.size, r > F) throw Error("Tổng dung lượng quá 7 MB: hãy dùng cách “Đọc thẳng thư mục trên máy”.");
			n.push({
				path: e,
				...await m(i)
			});
		}
	}
	if (!n.length) throw Error("Không có file .yaml, .yml, .json, .wsdl, .xsd nào.");
	return n;
}
function R({ api: t, current: o, onClose: c, onDone: l }) {
	let f = !!o, [p, m] = r(o?.name || ""), [g, _] = r(o?.description || ""), [v, S] = r(o ? o.source === "folder" ? "path" : "keep" : "files"), [C, w] = r(o?.folder || ""), [T, E] = r(null), [D, O] = r(null), [k, A] = h(), j = n(null);
	e(() => {
		j.current?.setAttribute("webkitdirectory", "");
	}, [v]);
	let M = async (e, t) => {
		O(null);
		try {
			let n = await L(e.target.files, t);
			if (E({
				files: n,
				label: `${n.length} file: ${n.slice(0, 4).map((e) => e.path).join(", ")}${n.length > 4 ? ", …" : ""}`
			}), !p.trim() && e.target.files?.[0]) {
				let n = e.target.files[0], r = t ? (n.webkitRelativePath || "").split("/")[0] : n.name.replace(/\.[^.]+$/, "");
				r && m(r);
			}
		} catch (e) {
			E(null), O(e.message);
		}
		e.target.value = "";
	}, F = () => {
		let e = {
			name: p,
			description: g
		};
		v === "path" && (e.folder = C), (v === "files" || v === "dir") && T && (e.files = T.files);
		let n = f ? t.put(`/sets/${o.id}`, e) : t.post("/sets", e);
		k(() => n, f ? "Đã lưu" : "Đã thêm bộ đặc tả").then((e) => {
			e && (l(e.set), c());
		});
	}, I = f ? o.source === "folder" ? [["path", "Đọc thẳng thư mục trên máy"]] : [
		["keep", "Giữ các file hiện có"],
		["files", "Thay bằng file khác"],
		["dir", "Thay bằng cả thư mục"]
	] : [
		["files", "Tải file lên"],
		["dir", "Tải cả thư mục lên"],
		["path", "Đọc thẳng thư mục trên máy"]
	], R = p.trim() && (v === "keep" || (v === "path" ? C.trim() : T));
	return /* @__PURE__ */ b(a, {
		headline: f ? `Sửa “${o.name}”` : "Thêm đặc tả",
		icon: f ? "edit" : "add",
		onClose: c,
		actions: (e) => /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b(i, {
			onClick: e,
			children: "Huỷ"
		}), /* @__PURE__ */ b(i, {
			variant: "filled",
			icon: "save",
			disabled: A || !R,
			onClick: F,
			children: f ? "Lưu" : "Thêm"
		})] }),
		children: /* @__PURE__ */ x("div", {
			className: "md-stack as-dialog",
			children: [
				/* @__PURE__ */ b(d, {
					label: "Tên bộ đặc tả",
					value: p,
					onChange: (e) => m(N(e)),
					maxLength: 120
				}),
				/* @__PURE__ */ b(d, {
					label: "Mô tả (AI đọc để biết bộ này là API gì)",
					type: "textarea",
					rows: 2,
					value: g,
					onChange: (e) => _(N(e)),
					maxLength: 2e3
				}),
				I.length > 1 ? /* @__PURE__ */ b(u, {
					label: "Nguồn",
					value: v,
					onChange: (e) => {
						S(N(e)), E(null), O(null);
					},
					options: I
				}) : null,
				v === "files" ? /* @__PURE__ */ x("label", {
					className: "as-file",
					children: [/* @__PURE__ */ b("span", {
						className: "md-body-medium",
						children: "Chọn file OpenAPI / Swagger (.yaml, .yml, .json) hoặc WSDL (.wsdl, .xsd)"
					}), /* @__PURE__ */ b("input", {
						type: "file",
						multiple: !0,
						accept: P.join(","),
						onChange: (e) => M(e, !1)
					})]
				}) : null,
				v === "dir" ? /* @__PURE__ */ x("label", {
					className: "as-file",
					children: [/* @__PURE__ */ b("span", {
						className: "md-body-medium",
						children: "Chọn thư mục: mọi file đặc tả bên trong được tải lên (giữ cấu trúc để $ref giữa các file chạy đúng)"
					}), /* @__PURE__ */ b("input", {
						ref: j,
						type: "file",
						multiple: !0,
						onChange: (e) => M(e, !0)
					})]
				}) : null,
				v === "path" ? /* @__PURE__ */ b(d, {
					label: "Đường dẫn thư mục (đầy đủ)",
					value: C,
					onChange: (e) => w(N(e)),
					supportingText: "Addon đọc thẳng thư mục này mỗi lần dùng: file đổi thì web và AI thấy ngay. Ví dụ: D:\\\\specs\\\\shop"
				}) : null,
				T ? /* @__PURE__ */ b("div", {
					className: "md-body-small",
					children: T.label
				}) : null,
				D ? /* @__PURE__ */ b(s, { children: D }) : null
			]
		})
	});
}
function z({ m: e }) {
	return /* @__PURE__ */ b("span", {
		className: `as-method as-method--${String(e).toLowerCase()}`,
		children: e
	});
}
function B({ items: e }) {
	return e?.length ? /* @__PURE__ */ b("div", {
		className: "as-content",
		children: e.map((e) => /* @__PURE__ */ x("div", {
			className: "as-media",
			children: [
				/* @__PURE__ */ b("div", {
					className: "md-body-small as-mono",
					children: e.mediaType
				}),
				/* @__PURE__ */ b(A, { schema: e.schema }),
				/* @__PURE__ */ b(j, {
					value: e.example,
					generated: e.exampleGenerated
				})
			]
		}, e.mediaType))
	}) : null;
}
function V(e) {
	if (/^2/.test(e)) return "success";
	if (/^3/.test(e)) return "primary";
	if (/^[45]/.test(e)) return "error";
}
function H({ d: e }) {
	return /* @__PURE__ */ x("div", {
		className: "md-stack",
		children: [
			/* @__PURE__ */ x("div", { children: [
				/* @__PURE__ */ x("div", {
					className: "md-row as-wrap",
					children: [
						/* @__PURE__ */ b(z, { m: e.method }),
						/* @__PURE__ */ b("span", {
							className: "as-mono md-title-medium",
							children: e.path
						}),
						e.deprecated ? /* @__PURE__ */ b(f, {
							tone: "warning",
							children: "deprecated"
						}) : null
					]
				}),
				e.summary ? /* @__PURE__ */ b("div", {
					className: "md-title-small",
					children: e.summary
				}) : null,
				/* @__PURE__ */ b("div", {
					className: "md-body-small md-muted",
					children: [
						e.operationId && `operationId ${e.operationId}`,
						e.tags.length && `tag ${e.tags.join(", ")}`,
						`${e.spec.title} ${e.spec.version}`.trim(),
						e.spec.specVersion,
						e.spec.file
					].filter(Boolean).join(" · ")
				}),
				e.servers.length ? /* @__PURE__ */ b("div", {
					className: "md-body-small as-mono",
					children: e.servers.join("  ·  ")
				}) : null,
				e.description ? /* @__PURE__ */ b("p", {
					className: "as-pre",
					children: e.description
				}) : null
			] }),
			/* @__PURE__ */ x("section", { children: [/* @__PURE__ */ b("div", {
				className: "md-title-small",
				children: "Tham số"
			}), e.parameters.length ? /* @__PURE__ */ b("div", {
				className: "md-table-wrap",
				children: /* @__PURE__ */ x("table", {
					className: "md-table",
					children: [/* @__PURE__ */ b("thead", { children: /* @__PURE__ */ x("tr", { children: [
						/* @__PURE__ */ b("th", { children: "Tên" }),
						/* @__PURE__ */ b("th", { children: "Ở" }),
						/* @__PURE__ */ b("th", { children: "Kiểu" }),
						/* @__PURE__ */ b("th", { children: "Mô tả" })
					] }) }), /* @__PURE__ */ b("tbody", { children: e.parameters.map((e) => /* @__PURE__ */ x("tr", { children: [
						/* @__PURE__ */ x("td", {
							className: "as-mono",
							children: [e.name, e.required ? /* @__PURE__ */ b("span", {
								className: "as-req",
								children: " *"
							}) : null]
						}),
						/* @__PURE__ */ b("td", { children: e.in }),
						/* @__PURE__ */ b("td", {
							className: "as-mono",
							children: E(e.schema)
						}),
						/* @__PURE__ */ x("td", { children: [
							e.description,
							e.deprecated ? " (deprecated)" : "",
							e.example == null ? null : /* @__PURE__ */ x("div", {
								className: "md-muted md-body-small",
								children: ["ví dụ: ", JSON.stringify(e.example)]
							})
						] })
					] }, `${e.in}:${e.name}`)) })]
				})
			}) : /* @__PURE__ */ b("div", {
				className: "md-muted md-body-small",
				children: "Không có"
			})] }),
			/* @__PURE__ */ x("section", { children: [/* @__PURE__ */ x("div", {
				className: "md-title-small",
				children: ["Request body ", e.requestBody?.required ? /* @__PURE__ */ b(f, { children: "bắt buộc" }) : null]
			}), e.requestBody ? /* @__PURE__ */ x(y, { children: [e.requestBody.description ? /* @__PURE__ */ b("p", {
				className: "as-pre",
				children: e.requestBody.description
			}) : null, /* @__PURE__ */ b(B, { items: e.requestBody.content })] }) : /* @__PURE__ */ b("div", {
				className: "md-muted md-body-small",
				children: "Không có"
			})] }),
			/* @__PURE__ */ x("section", { children: [/* @__PURE__ */ b("div", {
				className: "md-title-small",
				children: "Response và mã lỗi"
			}), e.responses.map((e) => /* @__PURE__ */ x("div", {
				className: "as-response",
				children: [
					/* @__PURE__ */ x("div", {
						className: "md-row as-wrap",
						children: [/* @__PURE__ */ b(f, {
							tone: V(e.code),
							children: e.code
						}), /* @__PURE__ */ b("span", { children: e.description })]
					}),
					e.headers.length ? /* @__PURE__ */ x("div", {
						className: "md-body-small",
						children: ["Header: ", e.headers.map((e) => /* @__PURE__ */ x("span", {
							className: "as-mono",
							children: [
								e.name,
								" (",
								E(e.schema),
								")",
								e.description ? ` – ${e.description}` : "",
								"; "
							]
						}, e.name))]
					}) : null,
					/* @__PURE__ */ b(B, { items: e.content })
				]
			}, e.code))] })
		]
	});
}
function U({ d: e }) {
	let t = (e, t) => /* @__PURE__ */ x("section", { children: [
		/* @__PURE__ */ x("div", {
			className: "md-title-small",
			children: [
				e,
				": ",
				/* @__PURE__ */ b("span", {
					className: "as-mono",
					children: t.message || "không có"
				})
			]
		}),
		t.parts?.length ? /* @__PURE__ */ x("div", {
			className: "md-body-small md-muted",
			children: ["part: ", t.parts.map((e) => `${e.name} = ${e.element || e.type}`).join(", ")]
		}) : null,
		t.schema ? /* @__PURE__ */ b(A, { schema: t.schema }) : null
	] });
	return /* @__PURE__ */ x("div", {
		className: "md-stack",
		children: [
			/* @__PURE__ */ x("div", { children: [
				/* @__PURE__ */ x("div", {
					className: "md-row as-wrap",
					children: [/* @__PURE__ */ b(z, { m: "SOAP" }), /* @__PURE__ */ x("span", {
						className: "as-mono md-title-medium",
						children: [
							e.service,
							".",
							e.operation
						]
					})]
				}),
				e.documentation ? /* @__PURE__ */ b("p", {
					className: "as-pre",
					children: e.documentation
				}) : null,
				/* @__PURE__ */ b("div", {
					className: "md-body-small md-muted",
					children: [
						`portType ${e.portType}`,
						e.soap,
						e.style && `style ${e.style}`,
						e.spec.file
					].filter(Boolean).join(" · ")
				}),
				e.address ? /* @__PURE__ */ b("div", {
					className: "md-body-small as-mono",
					children: e.address
				}) : null,
				e.soapAction ? /* @__PURE__ */ x("div", {
					className: "md-body-small",
					children: ["SOAPAction: ", /* @__PURE__ */ b("span", {
						className: "as-mono",
						children: e.soapAction
					})]
				}) : null
			] }),
			t("Input", e.input),
			t("Output", e.output),
			/* @__PURE__ */ x("section", { children: [/* @__PURE__ */ b("div", {
				className: "md-title-small",
				children: "Fault"
			}), e.faults.length ? e.faults.map((e) => /* @__PURE__ */ x("div", {
				className: "as-response",
				children: [/* @__PURE__ */ x("div", {
					className: "md-row",
					children: [/* @__PURE__ */ b(f, {
						tone: "error",
						children: e.name
					}), /* @__PURE__ */ b("span", {
						className: "as-mono",
						children: e.message
					})]
				}), e.schema ? /* @__PURE__ */ b(A, { schema: e.schema }) : null]
			}, e.name)) : /* @__PURE__ */ b("div", {
				className: "md-muted md-body-small",
				children: "Không có"
			})] })
		]
	});
}
function W({ api: e, setId: t, endpoint: n }) {
	let { data: r, error: i } = _(() => e.get(`/sets/${t}/endpoint`, { id: n.id }), [t, n.id]);
	return i ? /* @__PURE__ */ b(s, { children: i.message }) : r ? r.endpoint.kind === "wsdl" ? /* @__PURE__ */ b(U, { d: r.endpoint }) : /* @__PURE__ */ b(H, { d: r.endpoint }) : /* @__PURE__ */ b(l, {});
}
function G({ api: e, setId: t, entry: n }) {
	let { data: r, error: i } = _(() => e.get(`/sets/${t}/schema`, {
		name: n.name,
		file: n.file
	}), [
		t,
		n.name,
		n.file
	]);
	return i ? /* @__PURE__ */ b(s, { children: i.message }) : r ? /* @__PURE__ */ x("div", {
		className: "md-stack",
		children: [/* @__PURE__ */ x("div", { children: [
			/* @__PURE__ */ b("span", {
				className: "md-title-medium as-mono",
				children: n.name
			}),
			" ",
			/* @__PURE__ */ b(f, { children: n.kind === "schema" ? "schema" : `XSD ${n.kind}` }),
			/* @__PURE__ */ b("div", {
				className: "md-body-small md-muted",
				children: n.file
			})
		] }), /* @__PURE__ */ b(A, { schema: r.schema })]
	}) : /* @__PURE__ */ b(l, {});
}
function K({ api: e, setId: n, onBack: a, onChanged: u }) {
	let { data: m, error: S, reload: C } = _(() => e.get(`/sets/${n}`), [n]), [w, T] = r("endpoints"), [E, D] = r(""), [O, k] = r(null), [A, j] = r(!1), [M] = h(), [P, F] = g();
	v(m?.set.name || "API Specs");
	let L = p(E).split(/\s+/).filter(Boolean), B = t(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of m?.endpoints || []) {
			let n = p(`${t.method} ${t.path} ${t.summary} ${t.description} ${t.operationId} ${t.tags.join(" ")}`);
			if (!L.every((e) => n.includes(e))) continue;
			let r = t.tags[0] || "(không có tag)";
			e.has(r) || e.set(r, []), e.get(r).push(t);
		}
		return [...e.entries()];
	}, [m, E]), V = t(() => (m?.schemas || []).filter((e) => L.every((t) => p(e.name).includes(t))), [m, E]), H = t(() => Object.fromEntries((m?.apis || []).flatMap((e) => (e.tags || []).map((e) => [e.name, e.description]))), [m]);
	if (S) return /* @__PURE__ */ x("div", {
		className: "md-stack",
		children: [/* @__PURE__ */ b("div", { children: /* @__PURE__ */ b(i, {
			icon: "arrow_back",
			onClick: a,
			children: "Danh sách"
		}) }), /* @__PURE__ */ b(s, { children: S.message })]
	});
	if (!m) return /* @__PURE__ */ b(l, {});
	let U = m.set, K = async () => {
		await P({
			title: `Xoá bộ đặc tả “${U.name}”?`,
			text: U.source === "folder" ? "Chỉ bỏ khỏi addon; thư mục và file trên máy không bị đụng tới. AI không đọc được bộ này nữa." : "Các file đã tải lên bị xoá khỏi addon, AI không đọc được nữa. Không hoàn tác được.",
			confirm: "Xoá",
			icon: "delete"
		}) && M(() => e.delete(`/sets/${U.id}`), "Đã xoá").then((e) => {
			e && (u(), a());
		});
	}, q = m.endpoints.length;
	return /* @__PURE__ */ x(y, { children: [
		F,
		A ? /* @__PURE__ */ b(R, {
			api: e,
			current: U,
			onClose: () => j(!1),
			onDone: () => {
				C(), u();
			}
		}) : null,
		/* @__PURE__ */ x("div", {
			className: "md-stack",
			children: [
				/* @__PURE__ */ x("div", {
					className: "md-row as-wrap",
					children: [
						/* @__PURE__ */ b(c, {
							icon: "arrow_back",
							label: "Quay lại danh sách",
							onClick: a
						}),
						/* @__PURE__ */ b("span", {
							className: "md-title-large",
							children: U.name
						}),
						/* @__PURE__ */ b(f, {
							icon: I[U.source]?.[0],
							tone: U.source === "pack" ? "primary" : void 0,
							children: I[U.source]?.[1]
						}),
						U.kinds?.map((e) => /* @__PURE__ */ b(f, { children: e }, e)),
						/* @__PURE__ */ b("span", { className: "md-spacer" }),
						/* @__PURE__ */ b(c, {
							icon: "refresh",
							label: "Đọc lại",
							onClick: C
						}),
						U.readOnly ? null : /* @__PURE__ */ b(i, {
							icon: "edit",
							onClick: () => j(!0),
							children: "Sửa"
						}),
						U.readOnly ? null : /* @__PURE__ */ b(c, {
							icon: "delete",
							danger: !0,
							label: "Xoá bộ đặc tả",
							onClick: K
						})
					]
				}),
				U.description ? /* @__PURE__ */ b("p", {
					className: "as-pre md-body-medium",
					children: U.description
				}) : null,
				U.source === "upload" ? null : /* @__PURE__ */ b("div", {
					className: "md-body-small md-muted as-mono",
					children: U.folder
				}),
				m.errors.length ? /* @__PURE__ */ x(s, { children: [
					m.errors.length,
					" file không đọc được: ",
					m.errors.join(" · ")
				] }) : null,
				m.apis.length ? null : /* @__PURE__ */ b(o, {
					icon: "api",
					title: "Không tìm thấy file OpenAPI / Swagger / WSDL nào trong bộ này"
				}),
				m.apis.length ? /* @__PURE__ */ b("section", {
					className: "md-card md-card--outlined",
					children: /* @__PURE__ */ b("div", {
						className: "md-card__body as-overview",
						children: m.apis.map((e) => /* @__PURE__ */ x("div", { children: [
							/* @__PURE__ */ x("div", {
								className: "md-title-small",
								children: [
									e.title,
									" ",
									e.version ? /* @__PURE__ */ b("span", {
										className: "md-muted",
										children: e.version
									}) : null
								]
							}),
							/* @__PURE__ */ x("div", {
								className: "md-body-small md-muted",
								children: [
									e.specVersion,
									" · ",
									e.file,
									" · ",
									e.endpoints,
									" ",
									e.kind === "wsdl" ? "operation" : "endpoint"
								]
							}),
							e.servers?.length ? /* @__PURE__ */ b("div", {
								className: "md-body-small as-mono",
								children: e.servers.join("  ·  ")
							}) : null,
							e.services?.map((e) => /* @__PURE__ */ x("div", {
								className: "md-body-small",
								children: [
									"Service ",
									/* @__PURE__ */ b("b", { children: e.name }),
									": ",
									e.ports.map((e) => `${e.name} (${e.soap || "?"}) ${e.address}`).join("; ")
								]
							}, e.name)),
							e.messages?.length ? /* @__PURE__ */ x("div", {
								className: "md-body-small md-muted",
								children: ["Message: ", e.messages.join(", ")]
							}) : null
						] }, e.file))
					})
				}) : null,
				/* @__PURE__ */ x("div", {
					className: "md-row as-wrap",
					children: [
						/* @__PURE__ */ x(i, {
							variant: w === "endpoints" ? "tonal" : "text",
							icon: "route",
							onClick: () => T("endpoints"),
							children: [
								"Endpoint (",
								q,
								")"
							]
						}),
						/* @__PURE__ */ x(i, {
							variant: w === "schemas" ? "tonal" : "text",
							icon: "data_object",
							onClick: () => T("schemas"),
							children: [
								"Schema / kiểu dữ liệu (",
								m.schemas.length,
								")"
							]
						}),
						/* @__PURE__ */ b("span", { className: "md-spacer" }),
						/* @__PURE__ */ b("div", {
							className: "as-search",
							children: /* @__PURE__ */ b(d, {
								label: w === "endpoints" ? "Tìm theo đường dẫn, tên, mô tả" : "Tìm schema",
								leadingIcon: "search",
								value: E,
								onChange: (e) => D(N(e))
							})
						})
					]
				}),
				/* @__PURE__ */ x("div", {
					className: "as-split",
					children: [/* @__PURE__ */ b("div", {
						className: "as-list",
						children: w === "endpoints" ? /* @__PURE__ */ x(y, { children: [B.length ? null : /* @__PURE__ */ b(o, {
							icon: "search_off",
							title: "Không có endpoint khớp"
						}), B.map(([e, t]) => /* @__PURE__ */ x("details", {
							open: !0,
							className: "as-group",
							children: [/* @__PURE__ */ x("summary", { children: [
								/* @__PURE__ */ b("span", {
									className: "md-title-small",
									children: e
								}),
								" ",
								/* @__PURE__ */ x("span", {
									className: "md-muted md-body-small",
									children: [t.length, H[e] ? ` · ${H[e]}` : ""]
								})
							] }), t.map((e) => /* @__PURE__ */ x("button", {
								type: "button",
								onClick: () => k({
									type: "ep",
									item: e
								}),
								className: `as-item${O?.item?.id === e.id ? " as-item--on" : ""}`,
								children: [
									/* @__PURE__ */ b(z, { m: e.method }),
									/* @__PURE__ */ b("span", {
										className: "as-mono as-path",
										children: e.path
									}),
									e.deprecated ? /* @__PURE__ */ b(f, {
										tone: "warning",
										children: "deprecated"
									}) : null,
									e.summary ? /* @__PURE__ */ b("span", {
										className: "md-body-small md-muted as-sum",
										children: e.summary
									}) : null
								]
							}, e.id))]
						}, e))] }) : /* @__PURE__ */ x(y, { children: [V.length ? null : /* @__PURE__ */ b(o, {
							icon: "search_off",
							title: "Không có schema khớp"
						}), V.map((e) => /* @__PURE__ */ x("button", {
							type: "button",
							onClick: () => k({
								type: "schema",
								item: e
							}),
							className: `as-item${O?.type === "schema" && O.item.name === e.name && O.item.file === e.file ? " as-item--on" : ""}`,
							children: [/* @__PURE__ */ b("span", {
								className: "as-mono",
								children: e.name
							}), /* @__PURE__ */ x("span", {
								className: "md-body-small md-muted",
								children: [
									" ",
									e.kind === "schema" ? "" : e.kind,
									" · ",
									e.file
								]
							})]
						}, `${e.file}:${e.name}`))] })
					}), /* @__PURE__ */ b("section", {
						className: "md-card md-card--outlined as-detail",
						children: /* @__PURE__ */ x("div", {
							className: "md-card__body",
							children: [
								O ? null : /* @__PURE__ */ b(o, {
									icon: "touch_app",
									title: w === "endpoints" ? "Chọn một endpoint để xem chi tiết" : "Chọn một schema"
								}),
								O?.type === "ep" ? /* @__PURE__ */ b(W, {
									api: e,
									setId: U.id,
									endpoint: O.item
								}, O.item.id) : null,
								O?.type === "schema" ? /* @__PURE__ */ b(G, {
									api: e,
									setId: U.id,
									entry: O.item
								}, O.item.file + O.item.name) : null
							]
						})
					})]
				})
			]
		})
	] });
}
function q({ module: e, api: t }) {
	let n = _(() => t.get("/sets"), []), [i, a] = r(null);
	return i ? /* @__PURE__ */ b(K, {
		api: t,
		setId: i,
		onBack: () => a(null),
		onChanged: n.reload
	}) : /* @__PURE__ */ b(J, {
		module: e,
		api: t,
		list: n,
		onOpen: a
	});
}
function J({ module: e, api: t, list: n, onOpen: a }) {
	let [u, d] = r(!1);
	v("API Specs");
	let { data: p, error: m } = n;
	return /* @__PURE__ */ x("div", {
		className: "md-stack",
		children: [
			u ? /* @__PURE__ */ b(R, {
				api: t,
				onClose: () => d(!1),
				onDone: (e) => {
					n.reload(), a(e.id);
				}
			}) : null,
			/* @__PURE__ */ x("div", {
				className: "md-row",
				children: [
					/* @__PURE__ */ b(i, {
						variant: "filled",
						icon: "add",
						onClick: () => d(!0),
						children: "Thêm đặc tả"
					}),
					/* @__PURE__ */ b("span", { className: "md-spacer" }),
					/* @__PURE__ */ b(c, {
						icon: "refresh",
						label: "Tải lại",
						onClick: n.reload
					})
				]
			}),
			m ? /* @__PURE__ */ b(s, { children: m.message }) : null,
			!p && !m ? /* @__PURE__ */ b(l, {}) : null,
			p && !p.sets.length ? /* @__PURE__ */ b(o, {
				icon: "api",
				title: "Chưa có bộ đặc tả nào"
			}) : null,
			/* @__PURE__ */ b("div", {
				className: "as-grid",
				children: p?.sets.map((e) => /* @__PURE__ */ b("button", {
					type: "button",
					className: "md-card md-card--outlined as-card",
					onClick: () => a(e.id),
					children: /* @__PURE__ */ x("div", {
						className: "md-card__body",
						children: [
							/* @__PURE__ */ b("div", {
								className: "md-title-medium",
								children: e.name
							}),
							/* @__PURE__ */ x("div", {
								className: "md-row as-wrap as-tags",
								children: [
									/* @__PURE__ */ b(f, {
										icon: I[e.source]?.[0],
										tone: e.source === "pack" ? "primary" : void 0,
										children: I[e.source]?.[1]
									}),
									e.kinds?.map((e) => /* @__PURE__ */ b(f, { children: e }, e)),
									e.errors ? /* @__PURE__ */ x(f, {
										tone: "warning",
										icon: "warning",
										children: [e.errors, " file lỗi"]
									}) : null,
									e.problem ? /* @__PURE__ */ b(f, {
										tone: "error",
										icon: "error",
										children: e.problem
									}) : null
								]
							}),
							e.description ? /* @__PURE__ */ b("div", {
								className: "md-body-small as-clamp",
								children: e.description
							}) : null,
							e.problem ? null : /* @__PURE__ */ x("div", {
								className: "md-body-small md-muted",
								children: [
									e.endpoints,
									" endpoint · ",
									e.schemas,
									" schema · ",
									e.fileCount,
									" file"
								]
							})
						]
					})
				}, e.id))
			})
		]
	});
}
export { q as default };
