## API Specs

Đọc file **OpenAPI / Swagger** (YAML, JSON) và **WSDL** để bạn và AI hiểu API: endpoint, tham số, request, response,
mã lỗi. Chỉ đọc file trên máy, không gọi mạng.

### Thêm đặc tả

Bấm [icon:add] **Thêm đặc tả**, đặt **Tên** và **Mô tả** (AI dựa vào mô tả để biết bộ này là API gì), rồi chọn nguồn:

| Nguồn | Khi nào |
|---|---|
| **Tải file lên** | Một vài file `.yaml`, `.yml`, `.json`, `.wsdl`, `.xsd` (tối đa 7 MB một lần) |
| **Tải cả thư mục lên** | Nhiều file `$ref` sang nhau: cấu trúc thư mục được giữ |
| **Đọc thẳng thư mục trên máy** | Thư mục lớn hoặc hay đổi: nhập đường dẫn đầy đủ, addon đọc lại mỗi khi file đổi |

Admin có thể phát sẵn **data pack**: mỗi thư mục con trong `packs/` của addon (hoặc trong **Thư mục data pack** ở
phần Cài đặt) là một bộ đặc tả, có thể kèm `pack.json` `{"name": "...", "description": "..."}`. Bộ từ data pack hiện
nhãn [icon:inventory_2] **data pack** và chỉ đọc.

Bấm [icon:edit] **Sửa** để đổi tên, mô tả hoặc thay file; [icon:delete] để xoá (bộ đọc thẳng thư mục: chỉ bỏ khỏi
addon, file trên máy giữ nguyên).

### Xem trên web

- Mở một bộ đặc tả: phần đầu tóm tắt từng API (phiên bản, server; WSDL: service, port, địa chỉ, message).
- Tab **Endpoint**: endpoint nhóm theo tag (WSDL: theo service). Gõ vào ô **Tìm** để lọc theo đường dẫn, tên hoặc mô tả.
- Bấm một endpoint để xem **tham số**, **request body**, **response và mã lỗi**, header, ví dụ. `$ref` đã được thay bằng
  nội dung schema (kể cả `$ref` sang file khác trong cùng bộ); schema tự tham chiếu hiện **(đệ quy)**.
- WSDL: operation có địa chỉ, SOAPAction, message input / output / fault và cấu trúc kiểu dữ liệu XSD.
- Tab **Schema / kiểu dữ liệu**: mọi schema (OpenAPI `components.schemas`, Swagger `definitions`) và kiểu XSD.

File nào không đọc được (sai cú pháp, quá 20 MB) được liệt kê ở đầu trang; các file khác vẫn dùng bình thường.

### Tool cho AI

| Tool | Làm gì |
|---|---|
| `api_list` | Các bộ đặc tả đang có, hoặc tìm endpoint theo từ khoá; mỗi endpoint một dòng: method, path, tóm tắt |
| `api_describe` | Chi tiết một endpoint hoặc operation WSDL: tham số, request, response, mã lỗi (đã thay sẵn `$ref`) |
| `api_schema` | Một schema hoặc kiểu dữ liệu theo tên (vd. `Order`, `CustomerType`) |

### Dữ liệu cho addon khác
Addon khác (đã khai trong addon.json của nó) đọc được các bộ đặc tả này qua Viewer Hub, chỉ đọc:

| Export | Trả về |
|---|---|
| `api_sets` | Danh sách bộ đặc tả |
| `api_endpoints` | Endpoint của một bộ hoặc tìm theo từ khoá |
| `api_endpoint` | Chi tiết một endpoint / thao tác SOAP |
