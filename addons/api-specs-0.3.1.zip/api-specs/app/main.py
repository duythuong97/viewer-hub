"""Addon "api-specs" (managed, Python): OpenAPI / Swagger (YAML, JSON) and WSDL files, read for the AI and on the web.

Spec sets come from uploads, a folder on this machine, or an admin data pack (lib/specsets.py). The page lists
endpoints by tag and shows one endpoint with $refs inlined; the AI gets the same through api_list / api_describe /
api_schema. Pure Python (own YAML reader), local files only, no network. Writes only under addon.data.

Exports (other addons read the same sets through the Hub, addon.json "exports"): api_sets, api_endpoints (list or
search), api_endpoint (one endpoint / SOAP operation in full, $refs inlined).
"""
from pathlib import Path

from viewer_hub.addons.sdk import Addon, ApiError, ToolError, fold, int_arg

import schema_text
from specsets import Sets, SetError

addon = Addon(
    "api-specs", title="API Specs",
    instructions=(
        "API specifications the user added to Viewer Hub (OpenAPI / Swagger and WSDL). api_list first (sets, or "
        "endpoints matching keywords), then api_describe for one endpoint / SOAP operation (parameters, request, "
        "responses, error codes, $refs already inlined) and api_schema for a named schema / XSD type."
    ),
)
sets = Sets(addon.data, addon.assets, addon.settings)
HTTP_METHODS = ("GET", "PUT", "POST", "DELETE", "OPTIONS", "HEAD", "PATCH", "TRACE", "SOAP")


def _api(fn):
    def wrap(request):
        try:
            return fn(request)
        except SetError as exc:
            raise ApiError(exc.code, exc.message, exc.status) from exc
    wrap.__name__ = fn.__name__
    return wrap


def _body(request) -> dict:
    return request.body if isinstance(request.body, dict) else {}


def _summary(meta: dict) -> dict:
    out = dict(meta)
    try:
        loaded = sets.load(meta)
        out |= {"endpoints": len(loaded.endpoints), "schemas": len(loaded.schemas), "errors": len(loaded.errors),
                "kinds": sorted({a["specVersion"] for a in loaded.apis}), "fileCount": len(loaded.paths)}
    except SetError as exc:
        out |= {"problem": exc.message}
    return out


# ── page API ────────────────────────────────────────────────────────────────────────────────────────────────
@addon.get("/sets")
@_api
def list_sets(_request):
    return {"sets": [_summary(m) for m in sets.all()]}


@addon.post("/sets")
@_api
def create_set(request):
    body = _body(request)
    meta = sets.create(name=body.get("name"), description=body.get("description"), files=body.get("files"),
                       folder=body.get("folder") or None)
    return {"set": _summary(meta)}


@addon.put("/sets/<set_id>")
@_api
def update_set(request):
    body = _body(request)
    meta = sets.update(request.params["set_id"], name=body.get("name"), description=body.get("description"),
                       files=body.get("files"), folder=body.get("folder"))
    return {"set": _summary(meta)}


@addon.delete("/sets/<set_id>")
@_api
def delete_set(request):
    sets.delete(request.params["set_id"])
    return {}


@addon.get("/sets/<set_id>")
@_api
def get_set(request):
    meta = sets.get(request.params["set_id"])
    loaded = sets.load(meta)
    return {"set": _summary(meta), "apis": loaded.apis, "endpoints": loaded.endpoints, "schemas": loaded.schemas,
            "errors": loaded.errors, "files": sorted(loaded.paths)}


@addon.get("/sets/<set_id>/endpoint")
@_api
def get_endpoint(request):
    loaded = sets.load(sets.get(request.params["set_id"]))
    wanted = request.query.get("id", "")
    ep = next((e for e in loaded.endpoints if e["id"] == wanted), None)
    if ep is None:
        raise ApiError("not_found", "Không có endpoint này (file đặc tả đã đổi?)", 404)
    return {"endpoint": loaded.detail(ep)}


@addon.get("/sets/<set_id>/schema")
@_api
def get_schema(request):
    loaded = sets.load(sets.get(request.params["set_id"]))
    name, file = request.query.get("name", ""), request.query.get("file", "")
    entry = next((s for s in loaded.schemas if s["name"] == name and (not file or s["file"] == file)), None)
    if entry is None:
        raise ApiError("not_found", f"Không có schema “{name}”", 404)
    return {"schema": loaded.schema(entry), "entry": entry}


# ── text for the AI ─────────────────────────────────────────────────────────────────────────────────────────
def _all_loaded(set_key=None):
    metas = [sets.find(set_key)] if set_key else sets.all()
    out = []
    for meta in metas:
        try:
            out.append(sets.load(meta))
        except SetError:
            continue
    return out


def _ep_line(ep: dict, set_id: str | None = None) -> str:
    text = f"{ep['method']} {ep['path']}"
    if ep.get("summary"):
        text += f" — {ep['summary']}"
    elif ep.get("operationId") and ep["kind"] == "openapi":
        text += f" — {ep['operationId']}"
    if ep.get("deprecated"):
        text += " (deprecated)"
    if set_id:
        text += f"  [{set_id}]"
    return text


def _search(loaded_sets, query: str):
    words = [w for w in fold(query).split() if w]  # fold: case and half / full width (ｶﾅ = カナ, ＡＢＣ = ABC)
    hits = []
    for loaded in loaded_sets:
        for ep in loaded.endpoints:
            hay = fold(" ".join([ep["method"], ep["path"], ep["summary"], ep["description"], ep["operationId"],
                            " ".join(ep["tags"]), ep["api"]]))
            if all(w in hay for w in words):
                strong = fold(" ".join([ep["path"], ep["operationId"], ep["summary"]]))
                hits.append((sum(3 if w in strong else 1 for w in words), loaded.meta["id"], ep))
    hits.sort(key=lambda h: -h[0])
    return hits


def _schema_lines(schema, title=None, indent=1, max_lines=250) -> list[str]:
    if schema is None:
        return ["  (none)"]
    return schema_text.render(schema, title, indent, max_lines)


def _example_lines(item: dict, indent="    ") -> list[str]:
    if item.get("example") is None:
        return []
    head = f"{indent}Example{' (generated from the schema)' if item.get('exampleGenerated') else ''}:"
    body = schema_text.dump_example(item["example"], 2500)
    return [head] + [f"{indent}  {line}" for line in body.splitlines()]


def describe_text(d: dict, set_meta: dict) -> str:
    out = []
    if d["kind"] == "openapi":
        out.append(f"{d['method']} {d['path']}" + (f" — {d['summary']}" if d["summary"] else "")
                   + (" (DEPRECATED)" if d["deprecated"] else ""))
        meta = [f"set {set_meta['id']}", f"{d['spec']['title']} {d['spec']['version']}".strip(),
                d["spec"]["specVersion"], d["spec"]["file"]]
        if d["operationId"]:
            meta.append(f"operationId {d['operationId']}")
        if d["tags"]:
            meta.append("tags " + ", ".join(d["tags"]))
        out.append("(" + " | ".join(meta) + ")")
        if d["servers"]:
            out.append("Servers: " + ", ".join(d["servers"]))
        if d["description"]:
            out += ["", d["description"].strip()]
        if d["security"]:
            sec = "; ".join(", ".join(f"{k}{(' ' + ' '.join(v)) if v else ''}" for k, v in s.items())
                            for s in d["security"] if isinstance(s, dict)) or "none"
            out.append(f"Security: {sec}")
        out += ["", "Parameters:" if d["parameters"] else "Parameters: none"]
        for p in d["parameters"]:
            line = f"- {p['name']} ({p['in']}{', required' if p['required'] else ''}): {schema_text.label(p['schema'])}"
            if p["description"]:
                line += f" — {' '.join(p['description'].split())[:300]}"
            if p["deprecated"]:
                line += " (deprecated)"
            if p["example"] is not None:
                line += f" (e.g. {schema_text.dump_example(p['example'], 200)})"
            out.append(line)
            sub = p["schema"] or {}
            if isinstance(sub, dict) and (sub.get("properties") or (sub.get("items") or {}).get("properties")):
                out += _schema_lines(sub, None, 2, 60)[1:]
        rb = d["requestBody"]
        out.append("")
        if not rb:
            out.append("Request body: none")
        else:
            out.append(f"Request body{' (required)' if rb['required'] else ''}:" + (f" {rb['description']}" if rb["description"] else ""))
            for c in rb["content"]:
                out.append(f"  {c['mediaType']}:")
                out += _schema_lines(c["schema"], None, 2)
                out += _example_lines(c)
        out += ["", "Responses:"]
        for r in d["responses"]:
            out.append(f"- {r['code']}" + (f" — {' '.join(r['description'].split())[:300]}" if r["description"] else ""))
            for h in r["headers"]:
                out.append(f"    header {h['name']}: {schema_text.label(h['schema'])}" + (f" — {h['description']}" if h["description"] else ""))
            for c in r["content"]:
                out.append(f"  {c['mediaType']}:")
                out += _schema_lines(c["schema"], None, 2)
                out += _example_lines(c)
        return "\n".join(out)
    # WSDL operation
    out.append(f"SOAP {d['service']}.{d['operation']}" + (f" — {d['documentation']}" if d["documentation"] else ""))
    out.append(f"(set {set_meta['id']} | {d['spec']['title']} | WSDL 1.1 | {d['spec']['file']} | portType {d['portType']})")
    if d["address"]:
        out.append(f"Address: {d['address']}")
    extra = [x for x in (d["soap"], f"style {d['style']}" if d["style"] else "",
                         f"SOAPAction {d['soapAction']!r}" if d["soapAction"] else "") if x]
    if extra:
        out.append(" | ".join(extra))
    if d["spec"]["targetNamespace"]:
        out.append(f"targetNamespace: {d['spec']['targetNamespace']}")
    for label, io in (("Input", d["input"]), ("Output", d["output"])):
        parts = ", ".join(f"{p['name']}={p['element'] or p['type']}" for p in io["parts"])
        out += ["", f"{label} message: {io['message'] or 'none'}" + (f" (parts: {parts})" if parts else "")]
        if io["schema"] is not None:
            out += _schema_lines(io["schema"], None, 1)
            sample = schema_text.example(io["schema"])
            if sample:
                out += _example_lines({"example": sample, "exampleGenerated": True}, "  ")
    out += ["", "Faults:" if d["faults"] else "Faults: none"]
    for f in d["faults"]:
        out.append(f"- {f['name']} (message {f['message']})")
        if f["schema"] is not None:
            out += _schema_lines(f["schema"], None, 2, 60)
    return "\n".join(out)


def _match_endpoints(loaded_sets, text: str):
    text = " ".join(str(text or "").split())
    method, _, rest = text.partition(" ")
    if method.upper() in HTTP_METHODS and rest:
        method, target = method.upper(), rest.strip()
    else:
        method, target = None, text
    exact, by_id, by_path, by_template = [], [], [], []
    from openapi import path_matches
    for loaded in loaded_sets:
        for ep in loaded.endpoints:
            if method and ep["method"] != method:
                continue
            pair = (loaded, ep)
            if ep["path"] == target or (ep["kind"] == "wsdl" and ep["path"].lower() == target.lower()):
                exact.append(pair)
            elif ep["operationId"] and ep["operationId"].lower() == target.lower():
                by_id.append(pair)
            elif ep["kind"] == "openapi" and target.startswith("/") and ep["path"].rstrip("/") == target.rstrip("/"):
                by_path.append(pair)
            elif ep["kind"] == "openapi" and target.startswith("/") and path_matches(ep["path"], target):
                by_template.append(pair)
    return exact or by_id or by_path or by_template


def _tool_call(fn):
    def wrap(arguments):
        try:
            return fn(arguments)
        except SetError as exc:
            raise ToolError(exc.message) from exc
    wrap.__name__ = fn.__name__
    return wrap


@addon.tool(
    "api_list",
    "List the API spec sets, or find endpoints: no arguments → the sets; set → every endpoint of that set; query → "
    "endpoints matching all the keywords (path, name, summary, tag). One endpoint per line: METHOD path — summary "
    "[set]. SOAP operations show as \"SOAP Service.operation\".",
    {"type": "object", "properties": {
        "query": {"type": "string", "description": "Keywords, e.g. 'order cancel' or '/customers'"},
        "set": {"type": "string", "description": "Spec set id (or exact name) to look in"},
        "limit": {"type": "integer", "description": "Max endpoints (default 60, max 500)"},
    }},
)
@_tool_call
def api_list(arguments):
    query = str(arguments.get("query") or "").strip()
    set_key = str(arguments.get("set") or "").strip()
    limit = int_arg(arguments, "limit", 60, 1, 500)
    if not query and not set_key:
        metas = sets.all()
        if not metas:
            return "No API specs yet: the user adds them on the 'API Specs' page."
        lines = [f"{len(metas)} spec set(s). id | name | content | description"]
        for meta in metas:
            s = _summary(meta)
            content = s.get("problem") or f"{s['endpoints']} endpoint(s), {s['schemas']} schema(s), {', '.join(s['kinds']) or 'no API file'}"
            desc = " ".join(str(meta.get("description") or "").split())[:200]
            lines.append(f"{meta['id']} | {meta['name']} | {content} | {desc}")
        lines.append("Next: api_list with a set or query, then api_describe.")
        return "\n".join(lines)
    loaded_sets = _all_loaded(set_key or None)
    if not query:
        loaded = loaded_sets[0]
        eps = loaded.endpoints
        lines = [f"{loaded.meta['name']} [{loaded.meta['id']}]: {len(eps)} endpoint(s)"]
        for api in loaded.apis:
            lines.append(f"# {api['title']} {api['version']} ({api['specVersion']}, {api['file']})".replace("  ", " "))
        lines += [_ep_line(ep) for ep in eps[:limit]]
        if len(eps) > limit:
            lines.append(f"… {len(eps) - limit} more (raise limit or add a query)")
        return "\n".join(lines)
    hits = _search(loaded_sets, query)
    if not hits:
        return f"No endpoint matches {query!r}." + ("" if set_key else " Try fewer words, or api_list with no arguments to see the sets.")
    lines = [f"{len(hits)} endpoint(s) match {query!r}:"]
    lines += [_ep_line(ep, set_id) for _score, set_id, ep in hits[:limit]]
    if len(hits) > limit:
        lines.append(f"… {len(hits) - limit} more")
    return "\n".join(lines)


@addon.tool(
    "api_describe",
    "Full detail of one endpoint or SOAP operation: parameters, request body, responses and error codes, examples; "
    "every $ref is already replaced by the schema it points to. endpoint: 'GET /orders/{id}', an operationId, a "
    "concrete path like '/orders/42', or 'Service.operation' for WSDL.",
    {"type": "object", "properties": {
        "endpoint": {"type": "string", "description": "e.g. 'POST /orders', 'getOrder', 'OrderService.GetOrder'"},
        "set": {"type": "string", "description": "Spec set id, when the same endpoint exists in several sets"},
    }, "required": ["endpoint"]},
)
@_tool_call
def api_describe(arguments):
    wanted = str(arguments.get("endpoint") or "").strip()
    if not wanted:
        raise ToolError("endpoint is required (see api_list)")
    set_key = str(arguments.get("set") or "").strip()
    matches = _match_endpoints(_all_loaded(set_key or None), wanted)
    if not matches:
        raise ToolError(f"No endpoint {wanted!r}. Use api_list with a query to find it.")
    if len(matches) > 1:
        lines = [f"{len(matches)} endpoints match {wanted!r}; call again with the exact 'METHOD path' and/or set:"]
        lines += [_ep_line(ep, loaded.meta["id"]) for loaded, ep in matches[:40]]
        return "\n".join(lines)
    loaded, ep = matches[0]
    return describe_text(loaded.detail(ep), loaded.meta)


@addon.tool(
    "api_schema",
    "One schema / data type by name (e.g. 'Order', 'CustomerType'): OpenAPI components.schemas, Swagger definitions "
    "or WSDL/XSD types and elements, with nested $refs inlined.",
    {"type": "object", "properties": {
        "name": {"type": "string", "description": "Schema or type name"},
        "set": {"type": "string", "description": "Spec set id, when several sets define the name"},
    }, "required": ["name"]},
)
@_tool_call
def api_schema(arguments):
    name = str(arguments.get("name") or "").strip()
    if not name:
        raise ToolError("name is required")
    set_key = str(arguments.get("set") or "").strip()
    found, similar = [], []
    for loaded in _all_loaded(set_key or None):
        for entry in loaded.schemas:
            if entry["name"] == name:
                found.append((loaded, entry))
            elif entry["name"].lower() == name.lower() or name.lower() in entry["name"].lower():
                similar.append((loaded, entry))
    if not found:
        found = [p for p in similar if p[1]["name"].lower() == name.lower()]
    if not found:
        if similar:
            names = ", ".join(f"{e['name']} [{l.meta['id']}]" for l, e in similar[:30])
            raise ToolError(f"No schema {name!r}. Similar: {names}")
        raise ToolError(f"No schema {name!r}.")
    if len(found) > 1 and len({id(l) for l, _ in found}) > 1:
        lines = [f"{name!r} is defined in several sets; pass set:"]
        lines += [f"- {e['name']} ({e['kind']}, {e['file']}) [{l.meta['id']}]" for l, e in found]
        return "\n".join(lines)
    out = []
    for loaded, entry in found[:3]:
        schema = loaded.schema(entry)
        out.append(f"{entry['name']} ({'XSD ' + entry['kind'] if entry['kind'] != 'schema' else 'schema'}, "
                   f"{entry['file']}, set {loaded.meta['id']})")
        out += schema_text.render(schema, None, 1, 400)
        sample = schema_text.example(schema)
        if sample is not None:
            out += _example_lines({"example": sample, "exampleGenerated": "example" not in (schema or {})}, "  ")
        out.append("")
    return "\n".join(out).rstrip()


# ── exports: what other addons may read (addon.json "exports") ─────────────────────────────────────────────
def _exported(fn):
    def wrap(params):
        try:
            return fn(params)
        except SetError as exc:
            raise ApiError(exc.code, exc.message, exc.status) from exc
    wrap.__name__ = fn.__name__
    return wrap


def _ep_item(ep: dict, set_id: str) -> dict:
    return {"set": set_id, "kind": ep["kind"], "method": ep["method"], "path": ep["path"], "summary": ep["summary"],
            "operationId": ep["operationId"], "tags": list(ep["tags"]), "deprecated": bool(ep.get("deprecated")),
            "api": ep["api"]}


@addon.export("api_sets")
@_exported
def export_sets(_params):
    out = []
    for meta in sets.all():
        s = _summary(meta)
        item = {"id": meta["id"], "name": meta["name"], "description": str(meta.get("description") or ""),
                "endpoints": int(s.get("endpoints") or 0), "schemas": int(s.get("schemas") or 0), "kinds": s.get("kinds") or []}
        if s.get("problem"):
            item["problem"] = s["problem"]
        out.append(item)
    return {"sets": out}


@addon.export("api_endpoints")
@_exported
def export_endpoints(params):
    query = str(params.get("query") or "").strip()
    set_key = str(params.get("set") or "").strip()
    limit = int_arg(params, "limit", 100, 1, 500)
    loaded_sets = _all_loaded(set_key or None)
    if query:
        found = [(set_id, ep) for _score, set_id, ep in _search(loaded_sets, query)]
    else:
        found = [(loaded.meta["id"], ep) for loaded in loaded_sets for ep in loaded.endpoints]
    return {"total": len(found), "items": [_ep_item(ep, set_id) for set_id, ep in found[:limit]]}


@addon.export("api_endpoint")
@_exported
def export_endpoint(params):
    wanted = str(params.get("endpoint") or "").strip()
    matches = _match_endpoints(_all_loaded(str(params.get("set") or "").strip() or None), wanted)
    if not matches:
        raise ApiError("not_found", f"Không có endpoint {wanted!r}", 404)
    if len(matches) > 1:
        names = ", ".join(f"{ep['method']} {ep['path']} [{loaded.meta['id']}]" for loaded, ep in matches[:20])
        raise ApiError("ambiguous", f"Nhiều endpoint khớp {wanted!r}: {names}; ghi rõ 'METHOD path' và set", 409)
    loaded, ep = matches[0]
    return {"set": loaded.meta["id"], "endpoint": loaded.detail(ep)}


if __name__ == "__main__":
    addon.run()
