"""Resolved JSON-schema-like dicts → compact text (for the AI) and generated examples.

A resolved schema has every $ref replaced by its target, marked with "x-ref": "<Name>". Markers left by the resolver:
{"x-circular": name} (recursion), {"x-truncated": name} (too deep / too big), {"x-missing-ref": ref}.
WSDL types are converted to the same shape (xsd.py), so one renderer serves both.
"""
from __future__ import annotations

import json

MAX_LINES = 400
CONSTRAINTS = [("minLength", "min length"), ("maxLength", "max length"), ("minimum", "min"), ("maximum", "max"),
               ("exclusiveMinimum", "> "), ("exclusiveMaximum", "< "), ("minItems", "min items"),
               ("maxItems", "max items"), ("pattern", "pattern"), ("default", "default"), ("multipleOf", "multiple of"),
               ("uniqueItems", "unique")]


def _short(text, limit: int = 160) -> str:
    text = " ".join(str(text or "").split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _scalar(value) -> str:
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False)


def merge_all_of(schema: dict) -> dict:
    """allOf of object-like parts → one object (properties and required merged); other parts are kept."""
    parts = schema.get("allOf")
    if not isinstance(parts, list):
        return schema
    merged = {k: v for k, v in schema.items() if k != "allOf"}
    props = dict(merged.get("properties") or {})
    required = list(merged.get("required") or [])
    rest = []
    names = []
    for part in parts:
        if not isinstance(part, dict):
            continue
        part = merge_all_of(part)
        if part.get("properties") or part.get("type") == "object":
            for k, v in (part.get("properties") or {}).items():
                props.setdefault(k, v)
            required += [r for r in part.get("required") or [] if r not in required]
            if part.get("x-ref"):
                names.append(part["x-ref"])
            for k in ("description", "additionalProperties"):
                if k in part and k not in merged:
                    merged[k] = part[k]
        else:
            rest.append(part)
    if props or not rest:
        merged["type"] = merged.get("type") or "object"
        merged["properties"] = props
        if required:
            merged["required"] = required
        if names:
            merged["x-extends"] = names
    if rest:
        merged["allOf"] = rest
    return merged


def label(schema) -> str:
    """One-line type of a schema: "string (date-time)", "array of Order", "Order", "object"…"""
    if not isinstance(schema, dict):
        return "any"
    if "x-circular" in schema:
        return f"{schema['x-circular']} (recursive)"
    if "x-truncated" in schema:
        return f"{schema['x-truncated']} (not expanded)"
    if "x-missing-ref" in schema:
        return f"? (unresolved $ref {schema['x-missing-ref']})"
    schema = merge_all_of(schema)
    kind = schema.get("type")
    if isinstance(kind, list):
        kind = " | ".join(str(k) for k in kind)
    name = schema.get("x-ref")
    if kind == "array" or (kind is None and "items" in schema):
        text = f"array of {label(schema.get('items'))}"
    elif name and (kind in (None, "object") or schema.get("properties")):
        text = name
    elif kind:
        text = str(kind) + (f" ({schema['format']})" if schema.get("format") else "")
        if name and kind not in ("object",):
            text = f"{name}: {text}"
    elif schema.get("properties"):
        text = "object"
    elif "oneOf" in schema or "anyOf" in schema:
        key = "oneOf" if "oneOf" in schema else "anyOf"
        text = f"{key} " + " | ".join(label(s) for s in schema[key][:6])
    elif "enum" in schema:
        text = "enum"
    else:
        text = "any"
    if "enum" in schema and isinstance(schema["enum"], list):
        values = ", ".join(_scalar(v) for v in schema["enum"][:20])
        text += f" enum [{values}{', …' if len(schema['enum']) > 20 else ''}]"
    if "const" in schema:
        text += f" = {_scalar(schema['const'])}"
    if schema.get("nullable") or (isinstance(schema.get("type"), list) and "null" in schema["type"]):
        text += " | null" if "null" not in text else ""
    extras = []
    for key, word in CONSTRAINTS:
        if key in schema and not isinstance(schema[key], (dict, list)):
            extras.append(f"{word} {_scalar(schema[key])}".replace("  ", " "))
    if schema.get("readOnly"):
        extras.append("read-only")
    if schema.get("writeOnly"):
        extras.append("write-only")
    if schema.get("deprecated"):
        extras.append("deprecated")
    if extras:
        text += " [" + ", ".join(extras) + "]"
    return text


def _children(schema: dict) -> list[tuple[str, dict, bool]]:
    """(name, schema, required) rows shown under a schema."""
    if not isinstance(schema, dict) or any(k in schema for k in ("x-circular", "x-truncated", "x-missing-ref")):
        return []
    schema = merge_all_of(schema)
    kind = schema.get("type")
    if kind == "array" or (kind is None and "items" in schema):
        return _children(schema.get("items"))
    rows = []
    required = set(schema.get("required") or [])
    for name, sub in (schema.get("properties") or {}).items():
        rows.append((name, sub, name in required))
    extra = schema.get("additionalProperties")
    if isinstance(extra, dict) and extra:
        rows.append(("<any key>", extra, False))
    for key in ("oneOf", "anyOf"):
        for index, sub in enumerate(schema.get(key) or [], 1):
            rows.append((f"({key} {index})", sub, False))
    for index, sub in enumerate(schema.get("allOf") or [], 1):
        rows.append((f"(allOf {index})", sub, False))
    return rows


def render(schema, title: str | None = None, indent: int = 0, max_lines: int = MAX_LINES) -> list[str]:
    """Indented text tree of a resolved schema."""
    out: list[str] = []
    seen_names: list[str] = []

    def walk(name, sub, required, depth):
        if len(out) >= max_lines:
            return
        pad = "  " * depth
        desc = _short(sub.get("description")) if isinstance(sub, dict) else ""
        head = f"{pad}{name}: {label(sub)}" if name is not None else f"{pad}{label(sub)}"
        if required:
            head += " *required"
        if desc:
            head += f" — {desc}"
        out.append(head)
        ref = sub.get("x-ref") if isinstance(sub, dict) else None
        if ref and ref in seen_names[-1:]:
            return
        if ref:
            seen_names.append(ref)
        for child, child_schema, child_required in _children(sub if isinstance(sub, dict) else {}):
            if len(out) >= max_lines:
                out.append(f"{pad}  … (cut: schema too large)")
                break
            walk(child, child_schema, child_required, depth + 1)
        if ref:
            seen_names.pop()

    walk(title, schema if isinstance(schema, dict) else {}, False, indent)
    return out


def example(schema, depth: int = 0, seen: tuple = ()):
    """A sample value generated from a resolved schema (used when the spec has no example)."""
    if not isinstance(schema, dict) or depth > 8:
        return None
    if any(k in schema for k in ("x-circular", "x-truncated", "x-missing-ref")):
        return None
    for key in ("example", "default", "const"):
        if key in schema:
            return schema[key]
    if isinstance(schema.get("examples"), list) and schema["examples"]:
        return schema["examples"][0]
    if isinstance(schema.get("enum"), list) and schema["enum"]:
        return schema["enum"][0]
    schema = merge_all_of(schema)
    for key in ("oneOf", "anyOf"):
        if schema.get(key):
            return example(schema[key][0], depth + 1, seen)
    kind = schema.get("type")
    if isinstance(kind, list):
        kind = next((k for k in kind if k != "null"), None)
    if kind == "array" or (kind is None and "items" in schema):
        item = example(schema.get("items"), depth + 1, seen)
        return [] if item is None else [item]
    if kind == "object" or schema.get("properties"):
        out = {}
        for name, sub in list((schema.get("properties") or {}).items())[:40]:
            value = example(sub, depth + 1, seen)
            if value is not None or (isinstance(sub, dict) and sub.get("nullable")):
                out[name] = value
        return out
    fmt = schema.get("format") or ""
    if kind == "string":
        return {"date-time": "2024-01-31T10:00:00Z", "date": "2024-01-31", "time": "10:00:00", "uuid":
                "3fa85f64-5717-4562-b3fc-2c963f66afa6", "email": "user@example.com", "uri": "https://example.com",
                "byte": "U3dhZ2dlcg==", "binary": "<binary>", "password": "********"}.get(fmt, "string")
    if kind == "integer":
        return 0
    if kind == "number":
        return 0.0
    if kind == "boolean":
        return True
    return None


def dump_example(value, limit: int = 3000) -> str:
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2)
    return text if len(text) <= limit else text[:limit] + "\n… (cut)"
