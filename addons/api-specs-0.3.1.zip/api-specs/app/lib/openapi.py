"""OpenAPI 3.x and Swagger 2.0: endpoint index, $ref resolution, endpoint detail in one normalised shape.

Normalised detail (both versions):
    {kind: "openapi", method, path, summary, description, operationId, tags, deprecated, servers, security,
     parameters: [{name, in, required, description, deprecated, schema, example}],
     requestBody: {required, description, content: [{mediaType, schema, example, exampleGenerated}]} | None,
     responses: [{code, description, headers: [{name, description, schema}], content: [...]}],
     spec: {title, version, specVersion, file}}
Schemas in it are resolved: every $ref replaced by its target (marked "x-ref": name), cycles cut with
{"x-circular": name}. Refs may point into other files of the same set ("common.yaml#/components/schemas/X"); URLs
are never fetched.
"""
from __future__ import annotations

import posixpath
from urllib.parse import unquote

from schema_text import example as gen_example

METHODS = ("get", "put", "post", "delete", "options", "head", "patch", "trace")
MAX_DEPTH = 40
MAX_NODES = 60_000
NOT_SCHEMAS = ("parameters", "responses", "requestBodies", "headers", "examples", "links", "callbacks",
               "securitySchemes", "pathItems", "paths")
SCHEMA_KEYS = ("type", "format", "items", "enum", "default", "minimum", "maximum", "exclusiveMinimum",
               "exclusiveMaximum", "minLength", "maxLength", "pattern", "minItems", "maxItems", "uniqueItems",
               "multipleOf", "collectionFormat", "allowEmptyValue")


def is_openapi(doc) -> bool:
    return isinstance(doc, dict) and isinstance(doc.get("paths", {}), dict) and (
        str(doc.get("openapi", "")).startswith("3") or str(doc.get("swagger", "")).startswith("2"))


def spec_version(doc) -> str:
    return f"OpenAPI {doc['openapi']}" if doc.get("openapi") else f"Swagger {doc.get('swagger')}"


def _pointer(doc, pointer: str):
    node = doc
    if pointer in ("", "/"):
        return node
    for raw in pointer.lstrip("/").split("/"):
        part = unquote(raw).replace("~1", "/").replace("~0", "~")
        if isinstance(node, dict) and part in node:
            node = node[part]
        elif isinstance(node, list) and part.isdigit() and int(part) < len(node):
            node = node[int(part)]
        else:
            raise KeyError(pointer)
    return node


class Resolver:
    """Inlines $refs across the documents of one set. load(path) → parsed doc or None."""

    def __init__(self, load):
        self.load = load
        self.nodes = 0

    def target(self, ref: str, file: str):
        """(file, pointer, node, name) of a $ref seen in `file`."""
        if "://" in ref:
            raise KeyError(ref)
        path, _, pointer = ref.partition("#")
        target_file = posixpath.normpath(posixpath.join(posixpath.dirname(file), path)) if path else file
        doc = self.load(target_file)
        if doc is None:
            raise KeyError(ref)
        node = _pointer(doc, pointer)
        name = unquote(pointer.rstrip("/").rsplit("/", 1)[-1]).replace("~1", "/").replace("~0", "~") if pointer \
            else posixpath.basename(target_file)
        return target_file, pointer, node, name

    def resolve(self, node, file: str, stack: tuple = ()):
        self.nodes += 1
        if isinstance(node, dict):
            ref = node.get("$ref")
            if isinstance(ref, str):
                try:
                    target_file, pointer, target, name = self.target(ref, file)
                except (KeyError, ValueError):
                    return {"x-missing-ref": ref}
                key = (target_file, pointer)
                if key in stack:
                    return {"x-circular": name}
                if len(stack) >= MAX_DEPTH or self.nodes > MAX_NODES:
                    return {"x-truncated": name}
                value = self.resolve(target, target_file, stack + (key,))
                if isinstance(value, dict):
                    siblings = {k: self.resolve(v, file, stack) for k, v in node.items() if k != "$ref"}
                    value = {**value, **siblings}
                    if pointer and not any(f"/{k}/" in pointer + "/" for k in NOT_SCHEMAS):
                        value.setdefault("x-ref", name)
                return value
            return {k: self.resolve(v, file, stack) for k, v in node.items()}
        if isinstance(node, list):
            return [self.resolve(v, file, stack) for v in node]
        return node

    def deref(self, node, file: str):
        """Follow $ref chains on one node only (for path items, parameters, responses…)."""
        seen = set()
        while isinstance(node, dict) and isinstance(node.get("$ref"), str):
            try:
                file, pointer, node, _name = self.target(node["$ref"], file)
            except (KeyError, ValueError):
                return {}, file
            if (file, pointer) in seen:
                return {}, file
            seen.add((file, pointer))
        return node, file


def _first_line(text, limit=200) -> str:
    text = " ".join(str(text or "").split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


def endpoints(doc: dict, file: str, resolver: Resolver) -> list[dict]:
    out = []
    title = (doc.get("info") or {}).get("title") or file
    for path, item in (doc.get("paths") or {}).items():
        item, item_file = resolver.deref(item, file)
        if not isinstance(item, dict):
            continue
        for method in METHODS:
            op = item.get(method)
            if not isinstance(op, dict):
                continue
            out.append({
                "kind": "openapi", "method": method.upper(), "path": str(path), "file": file, "api": title,
                "summary": _first_line(op.get("summary")), "description": _first_line(op.get("description"), 300),
                "operationId": str(op.get("operationId") or ""), "tags": [str(t) for t in op.get("tags") or []],
                "deprecated": bool(op.get("deprecated")),
            })
    return out


def schema_names(doc: dict) -> list[str]:
    if doc.get("openapi"):
        return [str(k) for k in ((doc.get("components") or {}).get("schemas") or {})]
    return [str(k) for k in (doc.get("definitions") or {})]


def schema(doc: dict, file: str, name: str, resolver: Resolver):
    escaped = name.replace("~", "~0").replace("/", "~1")
    pointer = f"#/components/schemas/{escaped}" if doc.get("openapi") else f"#/definitions/{escaped}"
    return resolver.resolve({"$ref": pointer}, file)


def servers(doc: dict) -> list[str]:
    if doc.get("openapi"):
        return [str(s.get("url")) for s in doc.get("servers") or [] if isinstance(s, dict) and s.get("url")]
    host = doc.get("host")
    if not host:
        return [doc["basePath"]] if doc.get("basePath") else []
    base = doc.get("basePath") or ""
    return [f"{scheme}://{host}{base}" for scheme in (doc.get("schemes") or ["https"])]


def _examples(media: dict):
    """(example, generated?) of an OpenAPI 3 media type object (already resolved)."""
    if "example" in media:
        return media["example"], False
    examples = media.get("examples")
    if isinstance(examples, dict) and examples:
        first = next(iter(examples.values()))
        if isinstance(first, dict) and "value" in first:
            return first["value"], False
    sample = gen_example(media.get("schema"))
    return sample, sample is not None


def _param(p: dict) -> dict:
    schema_value = p.get("schema")
    if schema_value is None:  # Swagger 2 non-body parameter: the schema keys are on the parameter itself
        schema_value = {k: p[k] for k in SCHEMA_KEYS if k in p}
    example = p.get("example")
    if example is None and isinstance(p.get("examples"), dict) and p["examples"]:
        first = next(iter(p["examples"].values()))
        example = first.get("value") if isinstance(first, dict) else None
    return {"name": str(p.get("name") or ""), "in": str(p.get("in") or ""), "required": bool(p.get("required")),
            "description": str(p.get("description") or ""), "deprecated": bool(p.get("deprecated")),
            "schema": schema_value, "example": example}


def detail(doc: dict, file: str, method: str, path: str, resolver: Resolver) -> dict:
    item, item_file = resolver.deref((doc.get("paths") or {}).get(path), file)
    op = item.get(method.lower()) if isinstance(item, dict) else None
    if not isinstance(op, dict):
        raise KeyError(f"{method} {path}")
    resolved_op = resolver.resolve(op, item_file)
    shared = resolver.resolve(item.get("parameters") or [], item_file)
    v3 = bool(doc.get("openapi"))
    params: dict[tuple, dict] = {}
    for p in list(shared) + list(resolved_op.get("parameters") or []):
        if isinstance(p, dict):
            params[(p.get("name"), p.get("in"))] = p
    parameters, body, form = [], None, []
    for p in params.values():
        if not v3 and p.get("in") == "body":
            body = p
        elif not v3 and p.get("in") == "formData":
            form.append(p)
        else:
            parameters.append(_param(p))
    order = {"path": 0, "query": 1, "header": 2, "cookie": 3}
    parameters.sort(key=lambda p: order.get(p["in"], 9))

    request = None
    if v3 and isinstance(resolved_op.get("requestBody"), dict):
        rb = resolved_op["requestBody"]
        content = []
        for media_type, media in (rb.get("content") or {}).items():
            media = media if isinstance(media, dict) else {}
            sample, generated = _examples(media)
            content.append({"mediaType": media_type, "schema": media.get("schema"), "example": sample,
                            "exampleGenerated": generated})
        request = {"required": bool(rb.get("required")), "description": str(rb.get("description") or ""),
                   "content": content}
    elif not v3 and (body or form):
        consumes = resolved_op.get("consumes") or doc.get("consumes") or (
            ["application/json"] if body else ["application/x-www-form-urlencoded"])
        if body:
            body_schema = body.get("schema")
            sample = gen_example(body_schema)
            request = {"required": bool(body.get("required")), "description": str(body.get("description") or ""),
                       "content": [{"mediaType": m, "schema": body_schema, "example": sample,
                                    "exampleGenerated": sample is not None} for m in consumes]}
        else:
            props = {str(p.get("name")): {k: p[k] for k in SCHEMA_KEYS + ("description",) if k in p} for p in form}
            form_schema = {"type": "object", "properties": props,
                           "required": [str(p.get("name")) for p in form if p.get("required")]}
            request = {"required": any(p.get("required") for p in form), "description": "",
                       "content": [{"mediaType": m, "schema": form_schema, "example": None, "exampleGenerated": False}
                                   for m in consumes]}

    responses = []
    produces = resolved_op.get("produces") or doc.get("produces") or ["application/json"]
    for code, resp in (resolved_op.get("responses") or {}).items():
        resp = resp if isinstance(resp, dict) else {}
        headers = [{"name": str(n), "description": str((h or {}).get("description") or ""),
                    "schema": (h or {}).get("schema") if v3 else {k: h[k] for k in SCHEMA_KEYS if k in (h or {})}}
                   for n, h in (resp.get("headers") or {}).items()]
        content = []
        if v3:
            for media_type, media in (resp.get("content") or {}).items():
                media = media if isinstance(media, dict) else {}
                sample, generated = _examples(media)
                content.append({"mediaType": media_type, "schema": media.get("schema"), "example": sample,
                                "exampleGenerated": generated})
        elif resp.get("schema") is not None:
            examples = resp.get("examples") if isinstance(resp.get("examples"), dict) else {}
            for media_type in produces:
                given = examples.get(media_type)
                sample = given if given is not None else gen_example(resp["schema"])
                content.append({"mediaType": media_type, "schema": resp["schema"], "example": sample,
                                "exampleGenerated": given is None and sample is not None})
        responses.append({"code": str(code), "description": str(resp.get("description") or ""),
                          "headers": headers, "content": content})
    responses.sort(key=lambda r: (r["code"] == "default", r["code"]))

    info = doc.get("info") or {}
    return {
        "kind": "openapi", "method": method.upper(), "path": path,
        "summary": str(resolved_op.get("summary") or ""), "description": str(resolved_op.get("description") or ""),
        "operationId": str(resolved_op.get("operationId") or ""), "tags": [str(t) for t in resolved_op.get("tags") or []],
        "deprecated": bool(resolved_op.get("deprecated")),
        "servers": servers(doc), "security": resolved_op.get("security", doc.get("security")) or [],
        "parameters": parameters, "requestBody": request, "responses": responses,
        "spec": {"title": str(info.get("title") or file), "version": str(info.get("version") or ""),
                 "specVersion": spec_version(doc), "file": file},
    }


def path_matches(template: str, concrete: str) -> bool:
    """"/orders/{id}" matches "/orders/42"."""
    a = template.strip("/").split("/")
    b = concrete.split("?")[0].strip("/").split("/")
    if len(a) != len(b):
        return False
    return all(x == y or (x.startswith("{") and x.endswith("}")) or ("{" in x and y) for x, y in zip(a, b))
