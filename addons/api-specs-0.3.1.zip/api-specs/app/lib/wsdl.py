"""WSDL 1.1 (+ the XSD it embeds or imports): services, ports, operations, messages and data types.

Names are matched by local name (prefixes dropped): enough for the usual one-namespace WSDL. XSD types are converted
to the same JSON-schema-like shape as OpenAPI schemas ("x-ref" for named types, "x-circular" for recursion), so
schema_text renders both. DOCTYPE / ENTITY declarations are refused (no entity expansion).
"""
from __future__ import annotations

import posixpath
from xml.etree import ElementTree

SOAP12 = "http://schemas.xmlsoap.org/wsdl/soap12/"
MAX_DEPTH = 30

BUILTIN = {
    "string": ("string", None), "normalizedString": ("string", None), "token": ("string", None),
    "anyURI": ("string", "uri"), "QName": ("string", "qname"), "NCName": ("string", None), "Name": ("string", None),
    "ID": ("string", None), "IDREF": ("string", None), "language": ("string", None), "NMTOKEN": ("string", None),
    "base64Binary": ("string", "byte"), "hexBinary": ("string", "hex"), "boolean": ("boolean", None),
    "int": ("integer", "int32"), "integer": ("integer", None), "long": ("integer", "int64"),
    "short": ("integer", "int16"), "byte": ("integer", "int8"), "unsignedInt": ("integer", "uint32"),
    "unsignedLong": ("integer", "uint64"), "unsignedShort": ("integer", "uint16"), "unsignedByte": ("integer", "uint8"),
    "nonNegativeInteger": ("integer", ">= 0"), "positiveInteger": ("integer", "> 0"),
    "nonPositiveInteger": ("integer", "<= 0"), "negativeInteger": ("integer", "< 0"),
    "decimal": ("number", "decimal"), "float": ("number", "float"), "double": ("number", "double"),
    "dateTime": ("string", "date-time"), "date": ("string", "date"), "time": ("string", "time"),
    "duration": ("string", "duration"), "gYear": ("string", "year"), "gYearMonth": ("string", "year-month"),
    "anyType": (None, None), "anySimpleType": ("string", None),
}
FACETS = {"minLength": "minLength", "maxLength": "maxLength", "length": "minLength", "pattern": "pattern",
          "minInclusive": "minimum", "maxInclusive": "maximum", "minExclusive": "exclusiveMinimum",
          "maxExclusive": "exclusiveMaximum", "totalDigits": "x-totalDigits", "fractionDigits": "x-fractionDigits"}


class WsdlError(ValueError):
    pass


def local(tag) -> str:
    return str(tag).rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def ns(tag) -> str:
    return tag[1:].split("}", 1)[0] if isinstance(tag, str) and tag.startswith("{") else ""


def qlocal(value) -> str:
    return str(value or "").rsplit(":", 1)[-1]


def parse_xml(text: str) -> ElementTree.Element:
    head = text[:5000]
    if "<!DOCTYPE" in head or "<!ENTITY" in text:
        raise WsdlError("XML có DOCTYPE / ENTITY: không đọc (an toàn)")
    try:
        return ElementTree.fromstring(text)
    except ElementTree.ParseError as exc:
        raise WsdlError(f"XML lỗi: {exc}") from exc


def is_wsdl(root) -> bool:
    return local(root.tag) in ("definitions", "description") and "wsdl" in ns(root.tag).lower()


def _doc(el) -> str:
    for child in el:
        if local(child.tag) == "documentation":
            return " ".join("".join(child.itertext()).split())
        if local(child.tag) == "annotation":
            for d in child:
                if local(d.tag) == "documentation":
                    return " ".join("".join(d.itertext()).split())
    return ""


class Types:
    """Named XSD elements / types of a WSDL and the schemas it imports (by local name)."""

    def __init__(self):
        self.elements: dict[str, ElementTree.Element] = {}
        self.types: dict[str, ElementTree.Element] = {}
        self.groups: dict[str, ElementTree.Element] = {}
        self.attribute_groups: dict[str, ElementTree.Element] = {}
        self.loaded: set[str] = set()

    def add_schema(self, schema: ElementTree.Element, file: str, load_xml):
        for child in schema:
            kind, name = local(child.tag), child.get("name")
            if kind == "element" and name:
                self.elements.setdefault(name, child)
            elif kind in ("complexType", "simpleType") and name:
                self.types.setdefault(name, child)
            elif kind == "group" and name:
                self.groups.setdefault(name, child)
            elif kind == "attributeGroup" and name:
                self.attribute_groups.setdefault(name, child)
            elif kind in ("import", "include", "redefine") and child.get("schemaLocation"):
                location = child.get("schemaLocation")
                if "://" in location:
                    continue
                path = posixpath.normpath(posixpath.join(posixpath.dirname(file), location))
                if path in self.loaded:
                    continue
                self.loaded.add(path)
                root = load_xml(path)
                if root is not None and local(root.tag) == "schema":
                    self.add_schema(root, path, load_xml)

    def names(self) -> list[tuple[str, str]]:
        return sorted([(n, local(t.tag)) for n, t in self.types.items()] +
                      [(n, "element") for n in self.elements if n not in self.types], key=lambda x: x[0].lower())

    # ── XSD → schema dict ───────────────────────────────────────────────────────────────────────────────────
    def type_ref(self, qname: str, stack: tuple) -> dict:
        name = qlocal(qname)
        if name in BUILTIN and name not in self.types:
            kind, fmt = BUILTIN[name]
            out = {} if kind is None else {"type": kind}
            if fmt:
                out["format"] = fmt
            return out
        node = self.types.get(name)
        if node is None:
            return {"x-missing-ref": qname}
        if ("type", name) in stack:
            return {"x-circular": name}
        if len(stack) > MAX_DEPTH:
            return {"x-truncated": name}
        value = self.convert_type(node, stack + (("type", name),))
        return {**value, "x-ref": name}

    def element(self, el, stack: tuple, required_out: list | None = None) -> tuple[str, dict]:
        """(name, schema) of an <element> (also handles ref=, occurs, nillable)."""
        if el.get("ref"):
            name = qlocal(el.get("ref"))
            target = self.elements.get(name)
            if target is None:
                schema = {"x-missing-ref": el.get("ref")}
            elif ("element", name) in stack:
                schema = {"x-circular": name}
            else:
                _n, schema = self.element(target, stack + (("element", name),))
        else:
            name = el.get("name") or "?"
            inline = next((c for c in el if local(c.tag) in ("complexType", "simpleType")), None)
            if el.get("type"):
                schema = self.type_ref(el.get("type"), stack)
            elif inline is not None:
                schema = self.convert_type(inline, stack)
            else:
                schema = {}
        schema = dict(schema)
        doc = _doc(el)
        if doc:
            schema["description"] = doc
        if el.get("nillable") == "true":
            schema["nullable"] = True
        if el.get("default") is not None:
            schema["default"] = el.get("default")
        max_occurs = el.get("maxOccurs", "1")
        min_occurs = el.get("minOccurs", "1")
        if max_occurs == "unbounded" or (max_occurs.isdigit() and int(max_occurs) > 1):
            schema = {"type": "array", "items": schema, "minItems": int(min_occurs) if min_occurs.isdigit() else 0}
            if max_occurs != "unbounded":
                schema["maxItems"] = int(max_occurs)
        if required_out is not None and min_occurs != "0":
            required_out.append(name)
        return name, schema

    def particles(self, node, props: dict, required: list, stack: tuple, choice: bool = False):
        for child in node:
            kind = local(child.tag)
            if kind == "element":
                name, schema = self.element(child, stack, None if choice else required)
                if choice:
                    schema = {**schema, "description": ("(choice) " + schema.get("description", "")).strip()}
                props[name] = schema
            elif kind in ("sequence", "all"):
                self.particles(child, props, required, stack, choice)
            elif kind == "choice":
                self.particles(child, props, required, stack, True)
            elif kind == "group" and child.get("ref"):
                group = self.groups.get(qlocal(child.get("ref")))
                if group is not None and ("group", child.get("ref")) not in stack:
                    self.particles(group, props, required, stack + (("group", child.get("ref")),), choice)
            elif kind == "any":
                props["<any element>"] = {"description": "xsd:any"}

    def attributes(self, node, props: dict, required: list, stack: tuple):
        for child in node:
            kind = local(child.tag)
            if kind == "attribute":
                name = child.get("name") or qlocal(child.get("ref")) or "?"
                schema = self.type_ref(child.get("type"), stack) if child.get("type") else {"type": "string"}
                inline = next((c for c in child if local(c.tag) == "simpleType"), None)
                if inline is not None:
                    schema = self.convert_type(inline, stack)
                doc = _doc(child)
                if doc:
                    schema = {**schema, "description": doc}
                props[f"@{name}"] = schema
                if child.get("use") == "required":
                    required.append(f"@{name}")
            elif kind == "attributeGroup" and child.get("ref"):
                group = self.attribute_groups.get(qlocal(child.get("ref")))
                if group is not None:
                    self.attributes(group, props, required, stack)

    def convert_type(self, node, stack: tuple) -> dict:
        kind = local(node.tag)
        doc = _doc(node)
        if kind == "simpleType":
            out = self.simple(node, stack)
        else:
            out = {"type": "object", "properties": {}, "required": []}
            for child in node:
                ck = local(child.tag)
                if ck in ("complexContent", "simpleContent"):
                    for der in child:
                        dk = local(der.tag)
                        if dk not in ("extension", "restriction"):
                            continue
                        base = self.type_ref(der.get("base"), stack) if der.get("base") else {}
                        if ck == "simpleContent":
                            out["properties"]["#text"] = {k: v for k, v in base.items() if k != "x-ref"}
                        elif dk == "extension" and base.get("properties"):
                            out["properties"].update(base["properties"])
                            out["required"] += [r for r in base.get("required") or [] if r not in out["required"]]
                            out["x-extends"] = [base.get("x-ref") or qlocal(der.get("base"))]
                        self.particles(der, out["properties"], out["required"], stack)
                        self.attributes(der, out["properties"], out["required"], stack)
            self.particles(node, out["properties"], out["required"], stack)   # sequence / all / choice / group
            self.attributes(node, out["properties"], out["required"], stack)
            if not out["required"]:
                del out["required"]
        if doc:
            out["description"] = doc
        return out

    def simple(self, node, stack: tuple) -> dict:
        for child in node:
            kind = local(child.tag)
            if kind == "restriction":
                out = dict(self.type_ref(child.get("base"), stack)) if child.get("base") else {"type": "string"}
                out.pop("x-ref", None)
                enum = [f.get("value") for f in child if local(f.tag) == "enumeration"]
                if enum:
                    out["enum"] = enum
                for f in child:
                    key = FACETS.get(local(f.tag))
                    if key and f.get("value") is not None:
                        value = f.get("value")
                        out[key] = int(value) if value.isdigit() and key != "pattern" else value
                return out
            if kind == "list":
                item = self.type_ref(child.get("itemType"), stack) if child.get("itemType") else {"type": "string"}
                return {"type": "array", "items": item, "description": "space-separated list"}
            if kind == "union":
                return {"type": "string", "description": f"union of {child.get('memberTypes') or 'types'}"}
        return {"type": "string"}

    def named(self, name: str) -> dict | None:
        """A named type or element (for api_schema)."""
        if name in self.types:
            return self.type_ref(name, ())
        if name in self.elements:
            _n, schema = self.element(self.elements[name], (("element", name),))
            return {**schema, "x-ref": name}
        return None


def index(root, file: str, load_xml) -> dict:
    """Parse one WSDL document: {kind, file, title, targetNamespace, services, operations, messages, types}."""
    if local(root.tag) == "description":
        raise WsdlError("WSDL 2.0 chưa được hỗ trợ (chỉ WSDL 1.1)")
    types = Types()
    for block in root:
        if local(block.tag) == "types":
            for schema in block:
                if local(schema.tag) == "schema":
                    types.add_schema(schema, file, load_xml)
        elif local(block.tag) == "import" and block.get("location") and "://" not in block.get("location"):
            path = posixpath.normpath(posixpath.join(posixpath.dirname(file), block.get("location")))
            imported = load_xml(path)
            if imported is not None and local(imported.tag) == "schema":
                types.add_schema(imported, path, load_xml)
    messages = {}
    for msg in root:
        if local(msg.tag) == "message" and msg.get("name"):
            messages[msg.get("name")] = [{"name": p.get("name") or "", "element": qlocal(p.get("element")) or None,
                                          "type": p.get("type")} for p in msg if local(p.tag) == "part"]
    port_types = {}
    for pt in root:
        if local(pt.tag) == "portType" and pt.get("name"):
            ops = []
            for op in pt:
                if local(op.tag) != "operation":
                    continue
                entry = {"name": op.get("name") or "", "documentation": _doc(op), "input": None, "output": None,
                         "faults": []}
                for io in op:
                    k = local(io.tag)
                    if k in ("input", "output"):
                        entry[k] = qlocal(io.get("message"))
                    elif k == "fault":
                        entry["faults"].append({"name": io.get("name") or "", "message": qlocal(io.get("message"))})
                ops.append(entry)
            port_types[pt.get("name")] = {"documentation": _doc(pt), "operations": ops}
    bindings = {}
    for b in root:
        if local(b.tag) != "binding" or not b.get("name"):
            continue
        info = {"portType": qlocal(b.get("type")), "soap": "", "style": "", "actions": {}}
        for child in b:
            if local(child.tag) == "binding":
                info["soap"] = "SOAP 1.2" if ns(child.tag) == SOAP12 else ("SOAP 1.1" if "soap" in ns(child.tag) else ns(child.tag))
                info["style"] = child.get("style") or ""
            elif local(child.tag) == "operation":
                for c in child:
                    if local(c.tag) == "operation":
                        info["actions"][child.get("name")] = {"soapAction": c.get("soapAction") or "",
                                                              "style": c.get("style") or ""}
        bindings[b.get("name")] = info
    services = []
    for s in root:
        if local(s.tag) != "service":
            continue
        ports = []
        for p in s:
            if local(p.tag) != "port":
                continue
            address = next((c.get("location") for c in p if local(c.tag) == "address"), "")
            binding = bindings.get(qlocal(p.get("binding")), {})
            ports.append({"name": p.get("name") or "", "binding": qlocal(p.get("binding")), "address": address or "",
                          "soap": binding.get("soap", ""), "portType": binding.get("portType", "")})
        services.append({"name": s.get("name") or "", "documentation": _doc(s), "ports": ports})

    operations = []
    seen = set()
    owners = [(svc["name"], port) for svc in services for port in svc["ports"]] or \
             [(None, {"portType": name, "binding": "", "address": "", "soap": ""}) for name in port_types]
    for service, port in owners:
        pt = port_types.get(port["portType"])
        if not pt:
            continue
        binding = bindings.get(port["binding"], {})
        for op in pt["operations"]:
            key = (service, port["portType"], op["name"])
            if key in seen:
                continue
            seen.add(key)
            action = (binding.get("actions") or {}).get(op["name"], {})
            operations.append({**op, "service": service or port["portType"], "portType": port["portType"],
                               "address": port["address"], "soap": port["soap"] or binding.get("soap", ""),
                               "soapAction": action.get("soapAction", ""),
                               "style": action.get("style") or binding.get("style", "")})
    title = root.get("name") or (services[0]["name"] if services else posixpath.basename(file))
    return {"kind": "wsdl", "file": file, "title": title, "targetNamespace": root.get("targetNamespace") or "",
            "documentation": _doc(root), "services": services, "operations": operations, "messages": messages,
            "types": types}


def message_schema(wsdl: dict, message: str | None) -> dict | None:
    """The parts of a message as one object schema (an element part shows the element's content)."""
    if not message:
        return None
    parts = wsdl["messages"].get(message)
    if parts is None:
        return {"x-missing-ref": message}
    types: Types = wsdl["types"]
    if len(parts) == 1 and parts[0]["element"]:
        element = types.elements.get(parts[0]["element"])
        if element is None:
            return {"x-missing-ref": parts[0]["element"]}
        _n, schema = types.element(element, (("element", parts[0]["element"]),))
        return {**schema, "x-ref": parts[0]["element"]}
    props = {}
    for part in parts:
        if part["element"]:
            element = types.elements.get(part["element"])
            props[part["name"]] = types.element(element, ())[1] if element is not None else {"x-missing-ref": part["element"]}
        else:
            props[part["name"]] = types.type_ref(part["type"], ())
    return {"type": "object", "x-ref": message, "properties": props}


def detail(wsdl: dict, op: dict) -> dict:
    return {
        "kind": "wsdl", "service": op["service"], "portType": op["portType"], "operation": op["name"],
        "documentation": op["documentation"], "address": op["address"], "soap": op["soap"],
        "soapAction": op["soapAction"], "style": op["style"],
        "input": {"message": op["input"], "parts": wsdl["messages"].get(op["input"] or "", []),
                  "schema": message_schema(wsdl, op["input"])},
        "output": {"message": op["output"], "parts": wsdl["messages"].get(op["output"] or "", []),
                   "schema": message_schema(wsdl, op["output"])},
        "faults": [{"name": f["name"], "message": f["message"], "schema": message_schema(wsdl, f["message"])}
                   for f in op["faults"]],
        "spec": {"title": wsdl["title"], "file": wsdl["file"], "targetNamespace": wsdl["targetNamespace"],
                 "specVersion": "WSDL 1.1"},
    }
