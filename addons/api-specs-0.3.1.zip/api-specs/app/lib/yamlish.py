"""A small, safe YAML reader (pure Python, no objects are ever constructed): enough YAML for OpenAPI / Swagger files.

Supports block mappings and sequences (including "- key: value" items and sequences at the parent key's indent),
flow collections ([...], {...}, multi-line), plain / single-quoted / double-quoted scalars (multi-line too), block
scalars (| and >, with chomping and indentation indicators), comments, anchors / aliases, merge keys (<<), the
"!!str" tag, document markers. Scalars follow the YAML 1.2 core schema (null, true / false, int, float); mapping keys
are always strings, as in JSON. Only the first document is read.
"""
from __future__ import annotations

import re

MAX_ALIASES = 10_000          # "billion laughs" guard: aliases are shared, but cap how many are followed

_INT = re.compile(r"[-+]?[0-9]+$")
_HEX = re.compile(r"0x[0-9a-fA-F]+$")
_OCT = re.compile(r"0o[0-7]+$")
_FLOAT = re.compile(r"[-+]?(\.[0-9]+|[0-9]+(\.[0-9]*)?)([eE][-+]?[0-9]+)?$")
_ESCAPES = {"0": "\0", "a": "\a", "b": "\b", "t": "\t", "\t": "\t", "n": "\n", "v": "\v", "f": "\f", "r": "\r",
            "e": "\x1b", " ": " ", '"': '"', "/": "/", "\\": "\\", "N": "\x85", "_": "\xa0", "L": " ",
            "P": " "}


class YamlError(ValueError):
    pass


def resolve_plain(text: str):
    if text in ("", "~", "null", "Null", "NULL"):
        return None
    if text in ("true", "True", "TRUE"):
        return True
    if text in ("false", "False", "FALSE"):
        return False
    if _INT.match(text):
        return int(text)
    if _HEX.match(text):
        return int(text, 16)
    if _OCT.match(text):
        return int(text[2:], 8)
    if _FLOAT.match(text) and any(ch.isdigit() for ch in text):
        return float(text)
    lowered = text.lower()
    if lowered in (".inf", "+.inf"):
        return float("inf")
    if lowered == "-.inf":
        return float("-inf")
    if lowered == ".nan":
        return float("nan")
    return text


def _indent(line: str) -> int:
    return len(line) - len(line.lstrip(" "))


def _strip_comment(text: str) -> str:
    """Plain text: a comment starts at " #" (or "#" at the start)."""
    if text.startswith("#"):
        return ""
    index = text.find(" #")
    tab = text.find("\t#")
    cut = min(i for i in (index, tab, len(text)) if i >= 0)
    return text[:cut].rstrip()


def _quoted_end(text: str, start: int = 0) -> int:
    """Index just after the closing quote of the quoted scalar starting at text[start], or -1 if not closed."""
    quote = text[start]
    i = start + 1
    while i < len(text):
        ch = text[i]
        if quote == "'" and ch == "'":
            if i + 1 < len(text) and text[i + 1] == "'":
                i += 2
                continue
            return i + 1
        if quote == '"':
            if ch == "\\":
                i += 2
                continue
            if ch == '"':
                return i + 1
        i += 1
    return -1


def _unquote(raw: str) -> str:
    """raw includes both quotes; line breaks inside are folded."""
    quote, body = raw[0], raw[1:-1]
    # fold: a single line break → space, n empty lines → n newlines, continuation indentation dropped
    if "\n" in body:
        lines = body.split("\n")
        out = lines[0].rstrip(" \t")
        blank = 0
        for line in lines[1:]:
            stripped = line.strip(" \t")
            if not stripped:
                blank += 1
                continue
            if out.endswith("\\") and quote == '"' and not out.endswith("\\\\"):
                out = out[:-1] + stripped        # escaped line break: join without space
            else:
                out += ("\n" * blank) if blank else " "
                out += stripped
            blank = 0
        if blank:
            out += "\n" * blank
        body = out
    if quote == "'":
        return body.replace("''", "'")
    out = []
    i = 0
    while i < len(body):
        ch = body[i]
        if ch != "\\":
            out.append(ch)
            i += 1
            continue
        nxt = body[i + 1] if i + 1 < len(body) else ""
        if nxt in _ESCAPES:
            out.append(_ESCAPES[nxt])
            i += 2
        elif nxt in ("x", "u", "U"):
            size = {"x": 2, "u": 4, "U": 8}[nxt]
            digits = body[i + 2:i + 2 + size]
            try:
                out.append(chr(int(digits, 16)))
            except ValueError:
                raise YamlError(f"bad escape \\{nxt}{digits}") from None
            i += 2 + size
        else:
            out.append(nxt)
            i += 2
    return "".join(out)


class _Flow:
    """Parser for one flow collection / scalar held in a string."""

    def __init__(self, text: str, owner: "_Parser"):
        self.s, self.i, self.owner = text, 0, owner

    def ws(self):
        while self.i < len(self.s):
            ch = self.s[self.i]
            if ch in " \t\n\r":
                self.i += 1
            elif ch == "#" and (self.i == 0 or self.s[self.i - 1] in " \t\n"):
                while self.i < len(self.s) and self.s[self.i] != "\n":
                    self.i += 1
            else:
                break

    def value(self, key: bool = False):
        self.ws()
        if self.i >= len(self.s):
            raise YamlError("unexpected end of flow collection")
        ch = self.s[self.i]
        anchor = None
        if ch == "&":
            m = re.compile(r"&([^\s,\[\]{}]+)").match(self.s, self.i)
            anchor = m.group(1)
            self.i = m.end()
            self.ws()
            ch = self.s[self.i] if self.i < len(self.s) else ""
        if ch == "!":
            m = re.compile(r"!\S*").match(self.s, self.i)
            self.i = m.end()
            self.ws()
            ch = self.s[self.i] if self.i < len(self.s) else ""
        if ch == "[":
            value = self.seq()
        elif ch == "{":
            value = self.map()
        elif ch == "*":
            m = re.compile(r"\*([^\s,\[\]{}]+)").match(self.s, self.i)
            self.i = m.end()
            value = self.owner.alias(m.group(1))
        elif ch in "\"'":
            end = _quoted_end(self.s, self.i)
            if end < 0:
                raise YamlError("unterminated quoted string")
            value = _unquote(self.s[self.i:end])
            self.i = end
        else:
            start = self.i
            while self.i < len(self.s):
                c = self.s[self.i]
                if c in ",]}":
                    break
                if c == ":" and (self.i + 1 >= len(self.s) or self.s[self.i + 1] in " \t\n,]}"):
                    break
                if c == "#" and self.s[self.i - 1] in " \t\n":
                    break
                self.i += 1
            raw = " ".join(self.s[start:self.i].split())
            value = raw if key else resolve_plain(raw)
        if anchor:
            self.owner.anchors[anchor] = value
        return value

    def seq(self):
        self.i += 1
        out = []
        while True:
            self.ws()
            if self.i >= len(self.s):
                raise YamlError("unterminated [")
            if self.s[self.i] == "]":
                self.i += 1
                return out
            item = self.value()
            self.ws()
            if self.i < len(self.s) and self.s[self.i] == ":":   # [a: 1] → [{a: 1}]
                self.i += 1
                item = {str(item): self.value()}
                self.ws()
            out.append(item)
            if self.i < len(self.s) and self.s[self.i] == ",":
                self.i += 1

    def map(self):
        self.i += 1
        out = {}
        while True:
            self.ws()
            if self.i >= len(self.s):
                raise YamlError("unterminated {")
            if self.s[self.i] == "}":
                self.i += 1
                return out
            key = self.value(key=True)
            self.ws()
            value = None
            if self.i < len(self.s) and self.s[self.i] == ":":
                self.i += 1
                self.ws()
                if self.i < len(self.s) and self.s[self.i] not in ",}":
                    value = self.value()
            if key == "<<":
                self.owner.merge(out, value)
            else:
                out[_key(key)] = value
            self.ws()
            if self.i < len(self.s) and self.s[self.i] == ",":
                self.i += 1


def _key(value) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    return str(value)


class _Parser:
    def __init__(self, text: str):
        self.lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        self.i = 0
        self.anchors: dict[str, object] = {}
        self.aliases = 0

    # ── helpers ─────────────────────────────────────────────────────────────────────────────────────────────
    def error(self, message: str):
        raise YamlError(f"line {min(self.i, len(self.lines) - 1) + 1}: {message}")

    def at_end(self) -> bool:
        if self.i >= len(self.lines):
            return True
        line = self.lines[self.i]
        return line.startswith(("---", "...")) and line[3:4] in ("", " ", "\t")

    def skip(self):
        while self.i < len(self.lines) and not self.at_end():
            stripped = self.lines[self.i].strip()
            if stripped and not stripped.startswith("#"):
                return
            self.i += 1

    def alias(self, name: str):
        self.aliases += 1
        if self.aliases > MAX_ALIASES:
            self.error("too many aliases")
        if name not in self.anchors:
            self.error(f"unknown alias *{name}")
        return self.anchors[name]

    def merge(self, target: dict, value):
        sources = value if isinstance(value, list) else [value]
        for source in sources:
            if not isinstance(source, dict):
                self.error("<< needs a mapping")
            for k, v in source.items():
                target.setdefault(k, v)

    @staticmethod
    def split_key(content: str):
        """(key, rest) when the line is "key: rest", else None."""
        if content[0] in "\"'":
            end = _quoted_end(content)
            if end < 0:
                return None
            rest = content[end:].lstrip(" \t")
            if rest.startswith(":") and (len(rest) == 1 or rest[1] in " \t"):
                return _unquote(content[:end]), rest[1:]
            return None
        if content[0] in "[{&*!|>%@`" or content.startswith(("- ", "? ")) or content == "-":
            if content[0] == "&" or content[0] == "!":
                # "&anchor key: value" / "!tag key: value" are rare; treat the token as part of the value
                return None
            return None
        for m in re.finditer(r":(?=[ \t]|$)", content):
            key = content[:m.start()]
            if " #" in key or "\t#" in key:
                return None
            return key.rstrip(), content[m.end():]
        return None

    # ── block structure ─────────────────────────────────────────────────────────────────────────────────────
    def parse(self):
        while self.i < len(self.lines):
            line = self.lines[self.i]
            if line.startswith("%") or not line.strip() or line.strip().startswith("#"):
                self.i += 1
                continue
            if line.startswith("---") and line[3:4] in ("", " ", "\t"):
                rest = line[3:].strip()
                if rest and not rest.startswith("#"):
                    self.lines[self.i] = rest
                else:
                    self.i += 1
            break
        return self.node(-1)

    def node(self, parent: int):
        self.skip()
        if self.at_end():
            return None
        line = self.lines[self.i]
        ind = _indent(line)
        if ind <= parent:
            return None
        content = line[ind:]
        if content == "-" or content.startswith(("- ", "-\t")):
            return self.seq(ind)
        if self.split_key(content):
            return self.map(ind)
        self.i += 1
        return self.inline(content, parent)

    def seq(self, ind: int) -> list:
        out = []
        while True:
            self.skip()
            if self.at_end():
                break
            line = self.lines[self.i]
            li = _indent(line)
            content = line[li:]
            if li != ind or not (content == "-" or content.startswith(("- ", "-\t"))):
                if li > ind:
                    self.error("bad indentation in a sequence")
                break
            rest = content[1:]
            text = rest.strip()
            if not text or text.startswith("#"):
                self.i += 1
                out.append(self.node(ind))
            else:
                pad = len(rest) - len(rest.lstrip(" \t"))
                self.lines[self.i] = " " * (ind + 1 + pad) + rest.lstrip(" \t")
                out.append(self.node(ind))
        return out

    def map(self, ind: int) -> dict:
        out: dict = {}
        while True:
            self.skip()
            if self.at_end():
                break
            line = self.lines[self.i]
            li = _indent(line)
            if li < ind:
                break
            content = line[li:]
            if li > ind:
                self.error("bad indentation in a mapping")
            if content == "-" or content.startswith(("- ", "-\t")):
                break
            kv = self.split_key(content)
            if not kv:
                self.error(f"expected 'key: value', got {content[:40]!r}")
            key, rest = kv
            self.i += 1
            value = self.inline(rest.strip(" \t"), ind, same_indent_seq=True)
            if key == "<<":
                self.merge(out, value)
            else:
                out[key if isinstance(key, str) else _key(key)] = value
        return out

    def inline(self, text: str, parent: int, same_indent_seq: bool = False):
        """The value written after "key:" / "- " (self.i is already on the next line)."""
        anchor = None
        force_str = False
        while text[:1] in ("&", "!"):
            m = re.match(r"([&!])(\S*)\s*", text)
            if m.group(1) == "&":
                anchor = m.group(2)
            elif m.group(2) == "!str":
                force_str = True
            text = text[m.end():]
        value = self._inline(text, parent, same_indent_seq, force_str)
        if anchor:
            self.anchors[anchor] = value
        return value

    def _inline(self, text: str, parent: int, same_indent_seq: bool, force_str: bool):
        if not text or text.startswith("#"):
            self.skip()
            if self.at_end():
                return None
            line = self.lines[self.i]
            li = _indent(line)
            content = line[li:]
            if same_indent_seq and li == parent and (content == "-" or content.startswith(("- ", "-\t"))):
                return self.seq(li)
            return self.node(parent)
        if text.startswith("*"):
            return self.alias(_strip_comment(text)[1:].strip())
        if text[0] in "|>":
            return self.block_scalar(text, parent)
        if text[0] in "[{":
            buf = text
            while True:
                try:
                    flow = _Flow(buf, self)
                    value = flow.value()
                    flow.ws()
                    return value
                except YamlError:
                    if self.i >= len(self.lines) or self.at_end():
                        raise
                    buf += "\n" + self.lines[self.i]
                    self.i += 1
        if text[0] in "\"'":
            buf = text
            while _quoted_end(buf) < 0:
                if self.i >= len(self.lines):
                    self.error("unterminated quoted string")
                buf += "\n" + self.lines[self.i]
                self.i += 1
            end = _quoted_end(buf)
            return _unquote(buf[:end])
        # plain scalar, maybe continued on more-indented lines
        parts = [_strip_comment(text)]
        multi = False
        while self.i < len(self.lines) and not self.at_end():
            line = self.lines[self.i]
            stripped = line.strip()
            if not stripped:
                j = self.i
                while j < len(self.lines) and not self.lines[j].strip():
                    j += 1
                if j < len(self.lines) and _indent(self.lines[j]) > parent and self.lines[j].strip()[:1] != "#":
                    parts.append("\n" * (j - self.i))
                    self.i = j
                    continue
                break
            if _indent(line) <= parent or stripped.startswith("#"):
                break
            parts.append(_strip_comment(stripped))
            multi = True
            self.i += 1
        if not multi:
            return parts[0] if force_str else resolve_plain(parts[0])
        out = parts[0]
        for part in parts[1:]:
            if part.startswith("\n"):
                out += part
            elif out.endswith("\n"):
                out += part
            else:
                out += " " + part
        return out

    def block_scalar(self, header: str, parent: int) -> str:
        m = re.match(r"([|>])([+-]?)([1-9]?)([+-]?)\s*(#.*)?$", header)
        if not m:
            self.error(f"bad block scalar header {header!r}")
        style, chomp, explicit = m.group(1), m.group(2) or m.group(4), m.group(3)
        base = max(parent, 0) if parent >= 0 else 0
        content_indent = base + int(explicit) if explicit else None
        lines = []
        while self.i < len(self.lines):
            line = self.lines[self.i]
            if not line.strip():
                lines.append("")
                self.i += 1
                continue
            li = _indent(line)
            if content_indent is None:
                if li <= parent:
                    break
                content_indent = li
            if li < content_indent:
                break
            lines.append(line[content_indent:])
            self.i += 1
        trailing = 0
        while lines and lines[-1] == "":
            lines.pop()
            trailing += 1
        if style == "|":
            text = "\n".join(lines)
        else:
            out = []
            for k, line in enumerate(lines):
                if k == 0:
                    out.append(line)
                    continue
                prev = lines[k - 1]
                if line == "":
                    out.append("\n")
                elif prev == "":
                    out.append(line)
                elif line.startswith((" ", "\t")) or prev.startswith((" ", "\t")):
                    out.append("\n" + line)
                else:
                    out.append(" " + line)
            text = "".join(out)
        if not lines:
            return "\n" * trailing if chomp == "+" else ""
        if chomp == "-":
            return text
        if chomp == "+":
            return text + "\n" * (1 + trailing)
        return text + "\n"


def loads(text: str):
    """Parse the first YAML document of text into dict / list / str / int / float / bool / None."""
    text = text.lstrip("﻿")
    try:
        return _Parser(text).parse()
    except RecursionError:
        raise YamlError("nesting too deep") from None
