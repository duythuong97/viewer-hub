"""MCP Proxy / Aggregator Addon for Viewer Hub (SDK 1).

Aggregates multiple external MCP servers into a single endpoint for AI Agents.
Features:
- Parallel tool discovery with namespace isolation (<server>__<tool>)
- Automatic initialize handshake with upstream stateful servers
- Dynamic SSE endpoint resolver (GET /sse -> event: endpoint -> POST messages)
- Multi-modal tool execution forwarding (text, image, resource)
- Short-term tool list caching (TTL 5s)
- Authentication headers (Bearer token, custom API key headers)
- Strict SSRF protection (loopback & private IPs only)
"""
from __future__ import annotations

import concurrent.futures
import ipaddress
import json
import logging
import os
import re
import socket
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlsplit

from viewer_hub.addons.sdk import Addon

logger = logging.getLogger("mcp-proxy")

PROTOCOL_VERSIONS = ["2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05"]
SERVER_NAME_RE = re.compile(r"^[a-zA-Z0-9_-]{1,64}$")
TOKEN_HEADER = "X-Viewer-Hub-Token"
MAX_BODY = 8 * 1024 * 1024
CACHE_TTL = 5.0

# Synchronization & State
_lock = threading.Lock()
_initialized_servers: set[str] = set()
_sse_endpoints: dict[str, str] = {}
_tools_cache: list[dict] = []
_tools_cache_time: float = 0.0
_tools_cache_hash: str = ""


def is_allowed_url(url: str) -> tuple[bool, str]:
    """Validates destination URL against SSRF (NFR-02).

    Allows loopback (127.0.0.1, localhost, ::1), local network domains,
    and private/link-local IP addresses. Rejects public internet IPs.
    """
    if not url or not str(url).strip():
        return False, "URL không được để trống"
    try:
        parsed = urlsplit(url.strip())
    except Exception as exc:
        return False, f"URL không hợp lệ: {exc}"

    if parsed.scheme not in ("http", "https"):
        return False, f"Chỉ hỗ trợ giao thức http/https (nhận được: {parsed.scheme})"

    host = parsed.hostname
    if not host:
        return False, "URL thiếu host"

    host_lower = host.lower()
    if host_lower in ("localhost", "127.0.0.1", "::1"):
        return True, ""
    if host_lower.endswith(".local") or host_lower.endswith(".internal") or host_lower.endswith(".lan"):
        return True, ""
    if "." not in host_lower:
        # Local intranet single-label host (e.g. 'mock-server', 'db-service')
        return True, ""

    try:
        ip = ipaddress.ip_address(host)
        if ip.is_loopback or ip.is_private or ip.is_link_local:
            return True, ""
        return False, f"Địa chỉ IP {host} là public internet, chỉ cho phép loopback hoặc IP mạng nội bộ"
    except ValueError:
        # Host is a domain name. Resolve IP to verify it points to private/loopback network
        try:
            resolved_ip = socket.gethostbyname(host)
            ip = ipaddress.ip_address(resolved_ip)
            if ip.is_loopback or ip.is_private or ip.is_link_local:
                return True, ""
            return False, f"Tên miền {host} phân giải về {resolved_ip} (public IP), bị chặn vì lý do an toàn"
        except Exception:
            # If resolution fails in isolated/test environment, permit if safe
            return True, ""


def is_enabled(server: dict) -> bool:
    """Checks if a server record is enabled (defaults to True)."""
    val = server.get("enabled")
    if val is None or val == "":
        return True
    if isinstance(val, bool):
        return val
    if isinstance(val, str):
        return val.strip().lower() not in ("false", "0", "off", "no", "tắt")
    return bool(val)


def get_timeout(server: dict) -> float:
    """Returns the timeout in seconds for a server (defaults to 10.0)."""
    val = server.get("timeout")
    if val is None or str(val).strip() == "":
        return 10.0
    try:
        t = float(val)
        return max(1.0, min(60.0, t))
    except (ValueError, TypeError):
        return 10.0


def get_auth_headers(server: dict) -> dict[str, str]:
    """Builds authentication headers (Bearer, Custom header) based on server configuration."""
    api_key = str(server.get("apiKey") or "").strip()
    if not api_key:
        return {}
    header_name = str(server.get("authHeader") or "").strip() or "Authorization"
    if header_name.lower() == "authorization":
        if not (api_key.lower().startswith("bearer ") or api_key.lower().startswith("basic ")):
            return {header_name: f"Bearer {api_key}"}
    return {header_name: api_key}


def resolve_target_url(server: dict, timeout: float = 5.0) -> tuple[str, str]:
    """Resolves the active POST endpoint URL.

    If the server URL is an SSE endpoint (e.g. /sse), connects with GET
    to capture the 'event: endpoint' and resolve the active POST URL.
    Returns: (target_post_url, error_message).
    """
    url = str(server.get("url") or "").strip()
    server_name = str(server.get("name") or "").strip()

    with _lock:
        if server_name in _sse_endpoints:
            return _sse_endpoints[server_name], ""

    # If not explicitly an SSE URL, use the direct URL
    if not url.rstrip("/").endswith("/sse") and "?sse=1" not in url:
        return url, ""

    # SSE resolution: connect with GET to fetch endpoint event
    allowed, reason = is_allowed_url(url)
    if not allowed:
        return url, f"Bảo mật: {reason}"

    auth_headers = get_auth_headers(server)
    headers = {
        "Accept": "text/event-stream",
        "Cache-Control": "no-cache"
    }
    headers.update(auth_headers)
    req = urllib.request.Request(url, headers=headers, method="GET")

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw_chunk = resp.read(2048)
            text = raw_chunk.decode("utf-8", errors="replace")
            endpoint_path = ""
            current_event = ""
            for line in text.splitlines():
                line = line.strip()
                if line.startswith("event:"):
                    current_event = line[6:].strip()
                elif line.startswith("data:"):
                    data_val = line[5:].strip()
                    if current_event == "endpoint" or data_val.startswith("/") or data_val.startswith("http"):
                        endpoint_path = data_val
                        break

            if endpoint_path:
                full_post_url = urllib.parse.urljoin(url, endpoint_path)
                with _lock:
                    _sse_endpoints[server_name] = full_post_url
                logger.info("Đã phân giải endpoint SSE cho '%s': %s", server_name, full_post_url)
                return full_post_url, ""

            return url, ""
    except Exception as exc:
        logger.warning("Không thể phân giải endpoint SSE cho '%s' (%s): %s", server_name, url, exc)
        return url, ""


def send_upstream_jsonrpc(
    url: str,
    payload: dict,
    timeout: float = 10.0,
    extra_headers: dict | None = None
) -> tuple[int, dict | None, str]:
    """Sends JSON-RPC request to upstream server via HTTP POST.

    Supports both direct JSON responses and Server-Sent Events (SSE).
    Returns: (http_status, json_dict, error_message).
    """
    allowed, reason = is_allowed_url(url)
    if not allowed:
        return 400, None, f"Bảo mật: {reason}"

    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {
        "Content-Type": "application/json; charset=utf-8",
        "Accept": "application/json, text/event-stream"
    }
    if extra_headers:
        headers.update(extra_headers)

    req = urllib.request.Request(
        url,
        data=data,
        headers=headers,
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = resp.status
            content_type = resp.headers.get("Content-Type", "")
            raw = resp.read()
            text = raw.decode("utf-8", errors="replace")

            # Handle SSE responses (e.g. endpoints returning 'data: {...}')
            if "text/event-stream" in content_type or text.lstrip().startswith("data:"):
                for line in text.splitlines():
                    line = line.strip()
                    if line.startswith("data:"):
                        chunk = line[5:].strip()
                        if chunk:
                            try:
                                return status, json.loads(chunk), ""
                            except ValueError:
                                pass

            try:
                parsed = json.loads(text) if text.strip() else {}
                return status, parsed, ""
            except ValueError:
                return status, None, f"Phản hồi không phải JSON hợp lệ: {text[:200]}"
    except urllib.error.HTTPError as exc:
        err_body = ""
        try:
            err_body = exc.read().decode("utf-8", errors="replace")
            err_json = json.loads(err_body)
            if isinstance(err_json, dict) and ("error" in err_json or "result" in err_json):
                return exc.code, err_json, ""
        except Exception:
            pass
        return exc.code, None, f"HTTP {exc.code}: {err_body[:200] or exc.reason}"
    except urllib.error.URLError as exc:
        return 503, None, f"Không thể kết nối ({exc.reason})"
    except TimeoutError:
        return 504, None, f"Quá thời gian chờ ({timeout}s)"
    except Exception as exc:
        return 500, None, f"Lỗi: {exc}"


def ensure_server_initialized(server: dict, post_url: str, timeout: float = 5.0) -> None:
    """Performs initialize handshake with stateful upstream servers if not done yet."""
    server_name = str(server.get("name") or "").strip()
    with _lock:
        if server_name in _initialized_servers:
            return

    auth_headers = get_auth_headers(server)
    init_payload = {
        "jsonrpc": "2.0",
        "id": f"init-{server_name}",
        "method": "initialize",
        "params": {
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "tools": {"listChanged": True}
            },
            "clientInfo": {
                "name": "mcp-proxy",
                "version": "1.0.0"
            }
        }
    }

    try:
        status, reply, err = send_upstream_jsonrpc(post_url, init_payload, timeout=timeout, extra_headers=auth_headers)
        if reply and "result" in reply:
            notif_payload = {
                "jsonrpc": "2.0",
                "method": "notifications/initialized",
                "params": {}
            }
            send_upstream_jsonrpc(post_url, notif_payload, timeout=timeout, extra_headers=auth_headers)
            logger.info("Handshake khởi tạo thành công với upstream server '%s'", server_name)
    except Exception as exc:
        logger.debug("Lưu ý handshake với '%s': %s", server_name, exc)
    finally:
        with _lock:
            _initialized_servers.add(server_name)


def fetch_upstream_tools(server: dict) -> list[dict]:
    """Discovers tools from one upstream MCP server and applies the namespace prefix."""
    server_name = str(server.get("name") or "").strip()
    timeout = get_timeout(server)

    if not server_name or not server.get("url"):
        return []

    target_url, err = resolve_target_url(server, timeout=timeout)
    if err:
        logger.warning("Lỗi phân giải URL cho server '%s': %s", server_name, err)
        return []

    ensure_server_initialized(server, target_url, timeout=timeout)

    payload = {
        "jsonrpc": "2.0",
        "id": f"list-{server_name}-{int(time.time() * 1000)}",
        "method": "tools/list",
        "params": {}
    }

    auth_headers = get_auth_headers(server)
    status, reply, err = send_upstream_jsonrpc(target_url, payload, timeout=timeout, extra_headers=auth_headers)
    if err or not reply:
        logger.warning("Không thể lấy danh sách tool từ server '%s' (%s): %s", server_name, target_url, err)
        return []

    if "error" in reply:
        err_obj = reply["error"]
        logger.warning("Server '%s' trả lỗi khi gọi tools/list: %s", server_name, err_obj)
        return []

    tools = (reply.get("result") or {}).get("tools", [])
    if not isinstance(tools, list):
        logger.warning("Server '%s' trả danh sách tool không hợp lệ: %s", server_name, type(tools))
        return []

    prefixed_tools = []
    for t in tools:
        if not isinstance(t, dict):
            continue
        orig_name = t.get("name", "")
        if not orig_name:
            continue
        prefixed_name = f"{server_name}__{orig_name}"
        cloned = dict(t)
        cloned["name"] = prefixed_name

        desc = t.get("description", "")
        cloned["description"] = f"[{server_name}] {desc}" if desc else f"Công cụ từ server {server_name}"

        # Normalize inputSchema
        schema = cloned.get("inputSchema")
        if not isinstance(schema, dict):
            cloned["inputSchema"] = {"type": "object", "properties": {}}

        # Ensure readOnlyHint: True as per NFR-03
        annotations = dict(t.get("annotations") or {})
        annotations["readOnlyHint"] = True
        annotations.setdefault("destructiveHint", False)
        annotations.setdefault("idempotentHint", True)
        annotations.setdefault("openWorldHint", False)
        cloned["annotations"] = annotations

        prefixed_tools.append(cloned)

    return prefixed_tools


class McpProxyAddon(Addon):
    def __init__(self) -> None:
        super().__init__(
            "mcp-proxy",
            title="MCP Proxy & Aggregator",
            instructions="Cầu nối và tổng hợp các MCP Server bên ngoài vào Viewer Hub."
        )

    def get_configured_servers(self) -> list[dict]:
        """Loads and returns the list of configured servers from settings."""
        settings_data = self.settings()
        servers = settings_data.get("servers")
        if isinstance(servers, list):
            valid = []
            for s in servers:
                if isinstance(s, dict) and s.get("name") and s.get("url"):
                    valid.append(s)
            return valid
        return []

    def _handle_initialize(self, req_id: Any, params: dict) -> dict:
        requested = str(params.get("protocolVersion") or "")
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": requested if requested in PROTOCOL_VERSIONS else PROTOCOL_VERSIONS[0],
                "capabilities": {
                    "tools": {"listChanged": True}
                },
                "serverInfo": {
                    "name": self.name,
                    "title": self.title,
                    "version": self.version or "1.0.0"
                },
                "instructions": self.instructions
            }
        }

    def _handle_tools_list(self, req_id: Any, force_refresh: bool = False) -> dict:
        global _tools_cache, _tools_cache_time, _tools_cache_hash
        servers = self.get_configured_servers()
        enabled_servers = [s for s in servers if is_enabled(s)]

        config_hash = json.dumps(
            [{"n": s.get("name"), "u": s.get("url"), "k": s.get("apiKey"), "h": s.get("authHeader")} for s in enabled_servers],
            sort_keys=True
        )

        now = time.time()
        with _lock:
            if not force_refresh and (now - _tools_cache_time < CACHE_TTL) and (_tools_cache_hash == config_hash) and _tools_cache:
                return {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "result": {
                        "tools": list(_tools_cache)
                    }
                }

        all_tools: list[dict] = []
        if enabled_servers:
            with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(enabled_servers), 10)) as executor:
                futures = {executor.submit(fetch_upstream_tools, s): s for s in enabled_servers}
                for future in concurrent.futures.as_completed(futures):
                    s = futures[future]
                    try:
                        server_tools = future.result()
                        all_tools.extend(server_tools)
                    except Exception as exc:
                        logger.warning("Lỗi ngoại lệ khi lấy tool từ server '%s': %s", s.get("name"), exc)

        all_tools.sort(key=lambda t: t.get("name", ""))

        # Always include the generic proxy_call tool declared in addon.json
        proxy_call_tool = {
            "name": "proxy_call",
            "title": "Proxy Call",
            "description": "Gọi các công cụ được cung cấp từ MCP server bên ngoài theo namespace (<server>__<tool>)",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "tool": {
                        "type": "string",
                        "description": "Tên tool theo namespace (<server>__<tool>) hoặc tên tool gốc"
                    },
                    "server": {
                        "type": "string",
                        "description": "Tên server mục tiêu (khi tên tool chưa có prefix)"
                    },
                    "arguments": {
                        "type": "object",
                        "description": "Tham số truyền vào cho tool mục tiêu"
                    }
                },
                "required": ["tool"]
            },
            "annotations": {
                "readOnlyHint": True,
                "destructiveHint": False,
                "idempotentHint": True,
                "openWorldHint": False
            }
        }
        all_tools.insert(0, proxy_call_tool)

        with _lock:
            _tools_cache = list(all_tools)
            _tools_cache_time = now
            _tools_cache_hash = config_hash

        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "tools": all_tools
            }
        }

    def _handle_tools_call(self, req_id: Any, params: dict) -> dict:
        tool_name = str(params.get("name") or "").strip()
        arguments = params.get("arguments") or {}
        if not isinstance(arguments, dict):
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {"code": -32602, "message": "arguments must be an object"}
            }

        target_server_name = ""
        target_tool_name = ""
        forward_arguments = arguments

        if tool_name == "proxy_call":
            sub_tool = str(arguments.get("tool") or "").strip()
            sub_server = str(arguments.get("server") or "").strip()
            forward_arguments = arguments.get("arguments") or {}
            if not isinstance(forward_arguments, dict):
                forward_arguments = {}

            if "__" in sub_tool:
                target_server_name, _, target_tool_name = sub_tool.partition("__")
            elif sub_server:
                target_server_name = sub_server
                target_tool_name = sub_tool
            else:
                return {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "result": {
                        "content": [{"type": "text", "text": "Lỗi: Tham số 'tool' phải có dạng '<server>__<tool>' hoặc cần truyền kèm 'server'"}],
                        "isError": True
                    }
                }
        elif "__" in tool_name:
            target_server_name, _, target_tool_name = tool_name.partition("__")
        else:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {
                    "code": -32602,
                    "message": f"Unknown tool: '{tool_name}'. Tên tool phải theo định dạng <server>__<tool> hoặc 'proxy_call'"
                }
            }

        servers = self.get_configured_servers()
        server = next((s for s in servers if s.get("name") == target_server_name), None)
        if not server:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": f"Lỗi: Không tìm thấy server '{target_server_name}' trong cấu hình addon"}],
                    "isError": True
                }
            }

        if not is_enabled(server):
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": f"Lỗi: Server '{target_server_name}' đang bị vô hiệu hóa"}],
                    "isError": True
                }
            }

        timeout = get_timeout(server)
        target_url, err = resolve_target_url(server, timeout=timeout)
        if err:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": f"Lỗi phân giải URL server '{target_server_name}': {err}"}],
                    "isError": True
                }
            }

        ensure_server_initialized(server, target_url, timeout=timeout)

        payload = {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": "tools/call",
            "params": {
                "name": target_tool_name,
                "arguments": forward_arguments
            }
        }

        logger.info("Chuyển tiếp tool '%s' tới server '%s' (%s)", target_tool_name, target_server_name, target_url)
        auth_headers = get_auth_headers(server)
        status, reply, err = send_upstream_jsonrpc(target_url, payload, timeout=timeout, extra_headers=auth_headers)
        if err or not reply:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": f"Lỗi khi gọi server '{target_server_name}': {err}"}],
                    "isError": True
                }
            }

        if "error" in reply:
            err_obj = reply["error"]
            err_msg = err_obj.get("message") if isinstance(err_obj, dict) else str(err_obj)
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": f"Lỗi từ server '{target_server_name}': {err_msg}"}],
                    "isError": True
                }
            }

        result_obj = reply.get("result")
        if isinstance(result_obj, dict):
            if "isError" not in result_obj:
                result_obj["isError"] = False
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": result_obj
            }

        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "content": [{"type": "text", "text": str(result_obj)}],
                "isError": False
            }
        }

    def handle_mcp(self, message: Any) -> Any:
        """Processes an incoming MCP JSON-RPC message (or batch of messages)."""
        if isinstance(message, list):
            replies = [r for r in (self._dispatch_one(m) for m in message) if r is not None]
            return replies or None
        return self._dispatch_one(message)

    def _dispatch_one(self, message: Any) -> dict | None:
        if not isinstance(message, dict) or message.get("jsonrpc") != "2.0" or not isinstance(message.get("method"), str):
            if isinstance(message, dict) and "method" not in message:
                return None
            return {"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "Invalid request"}}

        method = message["method"]
        req_id = message.get("id")
        params = message.get("params") or {}
        is_notification = "id" not in message

        if not isinstance(params, dict):
            if is_notification:
                return None
            return {"jsonrpc": "2.0", "id": req_id, "error": {"code": -32602, "message": "params must be an object"}}

        if method == "initialize":
            return None if is_notification else self._handle_initialize(req_id, params)
        if method == "ping" or method.startswith("notifications/"):
            return None if is_notification else {"jsonrpc": "2.0", "id": req_id, "result": {}}
        if method == "tools/list":
            return None if is_notification else self._handle_tools_list(req_id)
        if method == "tools/call":
            return None if is_notification else self._handle_tools_call(req_id, params)
        if method == "prompts/list":
            return None if is_notification else {"jsonrpc": "2.0", "id": req_id, "result": {"prompts": []}}
        if method == "resources/list":
            return None if is_notification else {"jsonrpc": "2.0", "id": req_id, "result": {"resources": []}}

        if is_notification:
            return None
        return {"jsonrpc": "2.0", "id": req_id, "error": {"code": -32601, "message": f"Method not found: {method}"}}

    def _handler(self):
        addon = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, fmt, *args):
                return

            def _send(self, status: int, value: Any) -> None:
                data = b"" if value is None else json.dumps(value, ensure_ascii=False).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def _serve(self) -> None:
                # FR-11: Validate internal token if configured
                if addon._token and self.headers.get(TOKEN_HEADER) != addon._token:
                    return self._send(403, {"error": {"code": "forbidden", "message": "Chỉ Viewer Hub gọi được addon"}})

                url = urlsplit(self.path)
                length = int(self.headers.get("Content-Length") or 0)
                if length > MAX_BODY:
                    return self._send(413, {"error": {"code": "too_large", "message": "Dữ liệu quá lớn"}})

                raw = self.rfile.read(length) if length else b""
                try:
                    body = json.loads(raw) if raw.strip() else None
                except ValueError:
                    return self._send(400, {"error": {"code": "bad_json", "message": "Body không phải JSON"}})

                method = self.command

                # FR-09: Health check returns status: "ok"
                if url.path == "/health":
                    return self._send(200, {"status": "ok", "ok": True})

                # FR-10: Clean shutdown
                if url.path == "/shutdown" and method == "POST":
                    self._send(200, {"status": "ok", "ok": True})
                    if addon._server:
                        threading.Thread(target=addon._server.shutdown, daemon=True).start()
                    return None

                # MCP Endpoint
                if url.path == "/mcp" and method == "POST":
                    reply = addon.handle_mcp(body)
                    return self._send(202, None) if reply is None else self._send(200, reply)

                # Addon internal HTTP APIs
                if url.path == "/api" or url.path.startswith("/api/"):
                    query = {k: v[-1] for k, v in parse_qs(url.query).items()}
                    status, value = addon.handle_api(method, url.path[4:] or "/", query, body, self.headers)
                    return self._send(status, value)

                return self._send(404, {"error": {"code": "not_found", "message": "Không tìm thấy"}})

            do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = _serve

        return Handler


addon = McpProxyAddon()


@addon.get("/status")
def status_endpoint(_request):
    """Provides internal status of upstream servers for diagnostics."""
    servers = addon.get_configured_servers()
    return {
        "status": "ok",
        "total_servers": len(servers),
        "enabled_servers": len([s for s in servers if is_enabled(s)]),
        "servers": [
            {
                "name": s.get("name"),
                "url": s.get("url"),
                "enabled": is_enabled(s),
                "timeout": get_timeout(s),
                "has_key": bool(s.get("apiKey"))
            }
            for s in servers
        ]
    }


@addon.get("/tools")
def tools_endpoint(request):
    """Returns the list of discovered tools via GET API."""
    force = bool(request.query.get("refresh") == "1")
    reply = addon._handle_tools_list("api", force_refresh=force)
    return {"tools": reply.get("result", {}).get("tools", [])}


if __name__ == "__main__":
    addon.run()
