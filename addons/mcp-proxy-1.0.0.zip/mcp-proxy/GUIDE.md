## MCP Ngoài

Addon tổng hợp và chuyển tiếp các lời gọi tool tới các MCP Server cục bộ hoặc trong mạng nội bộ.

### Giới thiệu
**MCP Proxy / Aggregator** đóng vai trò là một cổng trung gian (Aggregator). Người dùng có thể khai báo nhiều MCP Server bên ngoài (chẳng hạn như database server, Jira API, hệ thống nội bộ...) mà không cần phải cấu hình riêng rẽ từng server vào ứng dụng AI của mình.

### Cách cấu hình Server
1. Mở menu **Cài đặt** của addon trên Viewer Hub (hoặc bấm nút **Cài đặt** ở thanh tiêu đề của trang addon).
2. Tại mục **Danh sách MCP Server bên ngoài**, bấm thêm dòng mới cho mỗi server muốn kết nối:
   - **Tên định danh (prefix):** Tên ngắn gọn đại diện cho server (chữ thường, số, dấu gạch ngang; ví dụ `postgres-db`, `jira-api`). Tên này là duy nhất và dùng làm tiền tố để phân biệt các tool giữa các server.
   - **Endpoint URL:** Địa chỉ HTTP endpoint của MCP server (ví dụ: `http://127.0.0.1:8080/mcp` hoặc `http://localhost:3001/sse`). Lưu ý chỉ hỗ trợ loopback (`127.0.0.1`, `localhost`) hoặc IP nội bộ (private IP).
   - **Timeout (giây):** Thời gian chờ tối đa khi gửi request (mặc định là 10 giây).
   - **API Key / Token (tuỳ chọn):** Điền key hoặc token nếu server ngoài yêu cầu xác thực. Addon tự động thêm tiền tố `Bearer <key>` nếu gửi qua header `Authorization`.
   - **Tên Header xác thực (tuỳ chọn):** Mặc định là `Authorization`. Nếu server đích yêu cầu header riêng (ví dụ `X-API-Key`, `X-Auth-Token`), hãy điền tên header vào ô này.
3. Bấm **Lưu** để áp dụng thay đổi.

### Quy ước đặt tên Tool (Namespace)
Để tránh trùng lặp tên tool giữa các server khác nhau, mọi tool thu thập được từ server ngoài sẽ tự động được gán tiền tố theo định dạng:
$$\text{<server\_name>}\_\_\text{<original\_tool\_name>}$$

*Ví dụ:* Nếu server có tên định danh là `postgres` cung cấp tool `query_table`, tool hiển thị cho AI sẽ là:
`postgres__query_table`

Khi AI gửi yêu cầu thực thi `postgres__query_table`, addon sẽ tự động phân tích tên server và chuyển tiếp nguyên vẹn request tới server `postgres` với tên tool gốc `query_table`.

### Chế độ hoạt động bền bỉ (Resilience)
Nếu một server bên ngoài bị tắt hoặc mất kết nối, addon sẽ không làm gián đoạn toàn bộ hệ thống. Danh sách tool của các server còn sống vẫn được cung cấp đầy đủ cho AI Agent kèm thông báo cảnh báo trong nhật ký.

### Tool cho AI
| Tool | AI dùng để |
|---|---|
| `proxy_call` | Gọi các công cụ được cung cấp từ MCP server bên ngoài theo namespace |
