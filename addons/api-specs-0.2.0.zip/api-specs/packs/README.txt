Data pack cho addon "Đặc tả API"

Admin đặt mỗi bộ đặc tả vào một thư mục con ở đây trước khi đóng gói addon (hoặc ở một thư mục khai báo trong
cài đặt "Thư mục data pack"):

  packs/
    ten-bo-dac-ta/
      pack.json          (tuỳ chọn) {"name": "Tên hiện trên web", "description": "Mô tả cho người và AI"}
      openapi.yaml       .yaml .yml .json (OpenAPI 3 / Swagger 2), .wsdl, .xsd
      schemas/common.yaml   file được $ref tới (đường dẫn tương đối) cũng để trong thư mục này

Bộ đặc tả từ data pack là chỉ đọc trên web; cập nhật bằng cách phát data pack mới.
