"""Spec sets: named groups of OpenAPI / Swagger / WSDL files, from three sources.

    upload  files sent from the page, copied to <data>/sets/<id>/files/        (editable, deletable)
    folder  a folder on this machine, read live every time it changes          (editable, deletable)
    pack    a data pack shipped by the admin: <addon>/packs/<name>/ or a sub-folder of a "packFolders" setting
            (read only). An optional pack.json {"name", "description"} names it.

A set is parsed on first use and cached until one of its files changes (path, size, mtime).
"""
from __future__ import annotations

import base64
import json
import os
import re
import secrets
import shutil
import threading
import time
import unicodedata
from pathlib import Path

from viewer_hub.addons.sdk import decode_text

import openapi
import wsdl
import yamlish

SPEC_EXT = (".yaml", ".yml", ".json", ".wsdl", ".xsd", ".xml")
MAX_FILES = 1000
MAX_FILE = 20 * 1024 * 1024
MAX_UPLOAD = 60 * 1024 * 1024
SKIP_DIRS = {"node_modules", ".git", ".svn", "__pycache__", "dist", "build", "target"}


class SetError(ValueError):
    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


def slug(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.lower().replace("đ", "d")).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", text).strip("-")[:40] or "dac-ta"


def _safe_rel(path: str) -> str:
    parts = [p for p in str(path).replace("\\", "/").split("/") if p not in ("", ".")]
    if not parts or any(p == ".." for p in parts) or any(p.startswith(".") for p in parts):
        raise SetError("bad_path", f"Tên file không hợp lệ: {path}")
    return "/".join(parts)


def scan(folder: Path) -> list[tuple[str, Path]]:
    """(relative posix path, absolute path) of every spec-looking file under folder."""
    out = []
    for root, dirs, files in os.walk(folder):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith("."))
        for name in sorted(files):
            if name.lower().endswith(SPEC_EXT) and not name.startswith(".") and name != "pack.json":
                path = Path(root) / name
                out.append((path.relative_to(folder).as_posix(), path))
                if len(out) > MAX_FILES:
                    raise SetError("too_many", f"Thư mục có hơn {MAX_FILES} file đặc tả")
    return out


class Loaded:
    """One parsed set: its APIs (OpenAPI docs / WSDLs), flat endpoint index, schema names, per-file errors."""

    def __init__(self, meta: dict, files: list[tuple[str, Path]]):
        self.meta = meta
        self.paths = dict(files)
        self.docs: dict[str, object] = {}
        self.xml: dict[str, object] = {}
        self.errors: list[str] = []
        self.apis: list[dict] = []
        self.endpoints: list[dict] = []
        self.schemas: list[dict] = []
        for rel, _path in files:
            self._index(rel)

    # ── file access (also used to follow $ref / schemaLocation into other files of the set) ────────────────
    def _text(self, rel: str) -> str | None:
        path = self.paths.get(rel)
        if path is None:
            return None
        try:
            if path.stat().st_size > MAX_FILE:
                self.errors.append(f"{rel}: lớn quá {MAX_FILE // (1024 * 1024)} MB, bỏ qua")
                return None
            return decode_text(path.read_bytes(), rel)[0]  # UTF-8, Shift_JIS, EUC-JP, UTF-16, <?xml encoding=…?>
        except OSError as exc:
            self.errors.append(f"{rel}: không đọc được ({exc.strerror or exc})")
            return None

    def doc(self, rel: str):
        if rel not in self.docs:
            self.docs[rel] = None
            if rel.lower().endswith((".yaml", ".yml", ".json")):
                text = self._text(rel)
                if text is not None:
                    try:
                        self.docs[rel] = json.loads(text) if text.lstrip()[:1] in "{[" else yamlish.loads(text)
                    except (ValueError, RecursionError) as exc:
                        try:
                            self.docs[rel] = yamlish.loads(text)
                        except (ValueError, RecursionError):
                            self.errors.append(f"{rel}: không đọc được, lỗi cú pháp ({str(exc)[:160]})")
        return self.docs[rel]

    def xml_root(self, rel: str):
        if rel not in self.xml:
            self.xml[rel] = None
            if rel.lower().endswith((".wsdl", ".xsd", ".xml")):
                text = self._text(rel)
                if text is not None:
                    try:
                        self.xml[rel] = wsdl.parse_xml(text)
                    except wsdl.WsdlError as exc:
                        self.errors.append(f"{rel}: {exc}")
        return self.xml[rel]

    def _index(self, rel: str):
        lower = rel.lower()
        if lower.endswith((".yaml", ".yml", ".json")):
            doc = self.doc(rel)
            if not openapi.is_openapi(doc):
                return
            resolver = openapi.Resolver(self.doc)
            info = doc.get("info") or {}
            eps = openapi.endpoints(doc, rel, resolver)
            api = {"kind": "openapi", "file": rel, "title": str(info.get("title") or rel),
                   "version": str(info.get("version") or ""), "specVersion": openapi.spec_version(doc),
                   "description": str(info.get("description") or "")[:2000], "servers": openapi.servers(doc),
                   "endpoints": len(eps), "tags": [{"name": str(t.get("name")), "description": str(t.get("description") or "")}
                                                   for t in doc.get("tags") or [] if isinstance(t, dict)]}
            self.apis.append(api)
            for ep in eps:
                ep["id"] = f"{rel}#{ep['method']} {ep['path']}"
                ep["key"] = f"{ep['method']} {ep['path']}"
                self.endpoints.append(ep)
            for name in openapi.schema_names(doc):
                self.schemas.append({"name": name, "file": rel, "kind": "schema"})
        elif lower.endswith((".wsdl", ".xml")):
            root = self.xml_root(rel)
            if root is None or not wsdl.is_wsdl(root):
                return
            try:
                parsed = wsdl.index(root, rel, self.xml_root)
            except wsdl.WsdlError as exc:
                self.errors.append(f"{rel}: {exc}")
                return
            self.docs[rel] = parsed
            self.apis.append({"kind": "wsdl", "file": rel, "title": parsed["title"], "version": "",
                              "specVersion": "WSDL 1.1", "description": parsed["documentation"],
                              "targetNamespace": parsed["targetNamespace"], "endpoints": len(parsed["operations"]),
                              "services": parsed["services"], "messages": sorted(parsed["messages"])})
            for op in parsed["operations"]:
                key = f"{op['service']}.{op['name']}"
                self.endpoints.append({
                    "kind": "wsdl", "method": "SOAP", "path": key, "file": rel, "api": parsed["title"],
                    "summary": op["documentation"][:200], "description": "", "operationId": op["name"],
                    "tags": [op["service"]], "deprecated": False, "id": f"{rel}#SOAP {key}", "key": f"SOAP {key}",
                    "input": op["input"], "output": op["output"],
                })
            for name, kind in parsed["types"].names():
                self.schemas.append({"name": name, "file": rel, "kind": kind})

    # ── lookups ─────────────────────────────────────────────────────────────────────────────────────────────
    def detail(self, ep: dict) -> dict:
        if ep["kind"] == "wsdl":
            parsed = self.docs[ep["file"]]
            op = next(o for o in parsed["operations"] if f"{o['service']}.{o['name']}" == ep["path"])
            return wsdl.detail(parsed, op)
        doc = self.doc(ep["file"])
        return openapi.detail(doc, ep["file"], ep["method"], ep["path"], openapi.Resolver(self.doc))

    def schema(self, entry: dict):
        if entry["kind"] == "schema":
            return openapi.schema(self.doc(entry["file"]), entry["file"], entry["name"], openapi.Resolver(self.doc))
        return self.docs[entry["file"]]["types"].named(entry["name"])


class Sets:
    def __init__(self, data: Path, addon_dir: Path, settings):
        self.root = data / "sets"
        self.addon_dir = addon_dir
        self.settings = settings
        self.lock = threading.Lock()
        self.cache: dict[str, tuple[tuple, Loaded]] = {}

    # ── listing ─────────────────────────────────────────────────────────────────────────────────────────────
    def _pack_roots(self) -> list[Path]:
        roots = [self.addon_dir / "packs"]
        value = self.settings().get("packFolders") or []
        if isinstance(value, str):
            value = value.splitlines()
        roots += [Path(str(v).strip()).expanduser() for v in value if str(v).strip()]
        return roots

    def _packs(self) -> list[dict]:
        out = []
        seen = set()
        for root in self._pack_roots():
            if not root.is_dir():
                continue
            candidates = [d for d in sorted(root.iterdir()) if d.is_dir() and not d.name.startswith(".")]
            if any(f.is_file() and f.name.lower().endswith(SPEC_EXT) for f in root.iterdir()):
                candidates.insert(0, root)
            for folder in candidates:
                info = {}
                try:
                    info = json.loads((folder / "pack.json").read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    pass
                info = info if isinstance(info, dict) else {}
                name = str(info.get("name") or folder.name)
                set_id = f"pack-{slug(folder.name)}"
                if set_id in seen:
                    set_id = f"{set_id}-{len(seen)}"
                seen.add(set_id)
                out.append({"id": set_id, "name": name, "description": str(info.get("description") or ""),
                            "source": "pack", "folder": str(folder), "readOnly": True})
        return out

    def all(self) -> list[dict]:
        items = []
        if self.root.is_dir():
            for meta_file in sorted(self.root.glob("*/meta.json")):
                try:
                    meta = json.loads(meta_file.read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    continue
                if isinstance(meta, dict) and meta.get("id"):
                    meta["readOnly"] = False
                    items.append(meta)
        items.sort(key=lambda m: m.get("name", "").lower())
        return items + self._packs()

    def get(self, set_id: str) -> dict:
        for meta in self.all():
            if meta["id"] == set_id:
                return meta
        raise SetError("not_found", "Không có bộ đặc tả này", 404)

    def find(self, key: str) -> dict:
        key = str(key or "").strip()
        items = self.all()
        for meta in items:
            if meta["id"] == key:
                return meta
        matches = [m for m in items if m["name"].lower() == key.lower()]
        if len(matches) == 1:
            return matches[0]
        raise SetError("not_found", f"No spec set {key!r} (api_list shows the ids)", 404)

    # ── files ───────────────────────────────────────────────────────────────────────────────────────────────
    def files(self, meta: dict) -> list[tuple[str, Path]]:
        if meta["source"] == "upload":
            folder = self.root / meta["id"] / "files"
        else:
            folder = Path(meta["folder"])
        if not folder.is_dir():
            raise SetError("missing_folder", f"Không thấy thư mục {folder}", 404)
        return scan(folder)

    def load(self, meta: dict) -> Loaded:
        files = self.files(meta)
        signature = []
        for rel, path in files:
            try:
                st = path.stat()
                signature.append((rel, st.st_size, st.st_mtime_ns))
            except OSError:
                signature.append((rel, -1, 0))
        signature = tuple(signature)
        with self.lock:
            cached = self.cache.get(meta["id"])
            if cached and cached[0] == signature:
                cached[1].meta = meta
                return cached[1]
        loaded = Loaded(meta, files)
        with self.lock:
            self.cache[meta["id"]] = (signature, loaded)
        return loaded

    # ── changes ─────────────────────────────────────────────────────────────────────────────────────────────
    @staticmethod
    def _clean(value, limit: int, what: str, required: bool = False) -> str:
        text = str(value or "").strip()
        if required and not text:
            raise SetError("missing", f"Thiếu {what}")
        if len(text) > limit:
            raise SetError("too_long", f"{what[:1].upper()}{what[1:]} dài quá (tối đa {limit} ký tự)")
        return text

    def _write_meta(self, meta: dict):
        folder = self.root / meta["id"]
        folder.mkdir(parents=True, exist_ok=True)
        tmp = folder / "meta.tmp"
        tmp.write_text(json.dumps({k: v for k, v in meta.items() if k != "readOnly"}, ensure_ascii=False, indent=1),
                       encoding="utf-8")
        tmp.replace(folder / "meta.json")

    def _write_files(self, set_id: str, files) -> int:
        if not isinstance(files, list) or not files:
            raise SetError("no_files", "Chưa chọn file nào")
        clean = []
        total = 0
        for item in files:
            if not isinstance(item, dict):
                continue
            rel = _safe_rel(item.get("path") or item.get("name") or "")
            if not rel.lower().endswith(SPEC_EXT):
                continue
            if item.get("base64"):  # bytes the page could not read as UTF-8 (Shift_JIS, EUC-JP…): kept as they are
                try:
                    content = base64.b64decode(str(item["base64"]), validate=True)
                except ValueError:
                    raise SetError("bad_file", f"File {rel} gửi lên bị hỏng") from None
            else:
                content = str(item.get("content") or "").encode("utf-8")
            total += len(content)
            clean.append((rel, content))
        if not clean:
            raise SetError("no_files", "Không có file .yaml, .yml, .json, .wsdl, .xsd nào")
        if len(clean) > MAX_FILES:
            raise SetError("too_many", f"Nhiều quá {MAX_FILES} file")
        if total > MAX_UPLOAD:
            raise SetError("too_large", "Tổng dung lượng lớn quá; hãy dùng cách đọc thẳng thư mục")
        target = self.root / set_id / "files"
        staging = self.root / set_id / f"files.new-{secrets.token_hex(3)}"
        for rel, content in clean:
            path = staging / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        old = None
        if target.exists():
            old = self.root / set_id / f"files.old-{secrets.token_hex(3)}"
            target.replace(old)
        staging.replace(target)
        if old is not None:
            _rmtree(old)
        return len(clean)

    def create(self, *, name, description="", files=None, folder=None) -> dict:
        name = self._clean(name, 120, "tên bộ đặc tả", required=True)
        description = self._clean(description, 2000, "mô tả")
        with self.lock:
            set_id = f"{slug(name)}-{secrets.token_hex(3)}"
            meta = {"id": set_id, "name": name, "description": description,
                    "created": time.strftime("%Y-%m-%d %H:%M:%S")}
            if folder:
                path = Path(str(folder).strip()).expanduser()
                if not path.is_absolute() or not path.is_dir():
                    raise SetError("bad_folder", f"Không thấy thư mục {folder} (cần đường dẫn đầy đủ)")
                scan(path)
                meta |= {"source": "folder", "folder": str(path)}
            else:
                meta |= {"source": "upload"}
                (self.root / set_id).mkdir(parents=True, exist_ok=True)
                try:
                    meta["files"] = self._write_files(set_id, files)
                except Exception:
                    _rmtree(self.root / set_id)
                    raise
            meta["updated"] = meta["created"]
            self._write_meta(meta)
        return self.get(set_id)

    def update(self, set_id: str, *, name=None, description=None, files=None, folder=None) -> dict:
        meta = self.get(set_id)
        if meta.get("readOnly"):
            raise SetError("read_only", "Bộ đặc tả từ data pack chỉ đọc (admin cập nhật bằng data pack mới)")
        with self.lock:
            if name is not None:
                meta["name"] = self._clean(name, 120, "tên bộ đặc tả", required=True)
            if description is not None:
                meta["description"] = self._clean(description, 2000, "mô tả")
            if files is not None:
                if meta["source"] != "upload":
                    raise SetError("bad_source", "Bộ này đọc thẳng thư mục, không tải file lên được")
                meta["files"] = self._write_files(set_id, files)
            if folder is not None and meta["source"] == "folder":
                path = Path(str(folder).strip()).expanduser()
                if not path.is_absolute() or not path.is_dir():
                    raise SetError("bad_folder", f"Không thấy thư mục {folder}")
                meta["folder"] = str(path)
            meta["updated"] = time.strftime("%Y-%m-%d %H:%M:%S")
            self._write_meta(meta)
            self.cache.pop(set_id, None)
        return self.get(set_id)

    def delete(self, set_id: str):
        meta = self.get(set_id)
        if meta.get("readOnly"):
            raise SetError("read_only", "Bộ đặc tả từ data pack không xoá được ở đây")
        with self.lock:
            _rmtree(self.root / set_id)
            self.cache.pop(set_id, None)


def _rmtree(path: Path):
    """Delete a folder this addon created under its data folder."""
    if path.exists():
        shutil.rmtree(path)
