## SVN

Cho AI đọc file **thẳng trên repo SVN theo đúng branch / tag / revision**, không cần checkout về máy.

1. Vào **SVN** trên menu → **Thêm repository**: đặt tên ngắn (vd. `core`), dán **URL gốc** của repo (vd. `https://svn.congty/repos/core`) và ghi mô tả (hệ thống gì) để AI chọn đúng repo.
2. Repo vừa lưu hiện trong danh sách. Bấm **Kiểm tra** để xem kết nối được không, [icon:delete] để xoá.
3. AI chỉ đọc được các repo trong danh sách đó, và chỉ **đọc** (không commit, không sửa gì).

Đăng nhập dùng thông tin SVN đã lưu trên máy (đã từng checkout hoặc đăng nhập bằng TortoiseSVN). Addon không hỏi và không lưu mật khẩu; URL có kèm mật khẩu sẽ bị từ chối.

Cần có lệnh `svn`: cài **TortoiseSVN** và chọn thêm **command line client tools**. Trang SVN báo nếu chưa có. Đường dẫn khác: đặt biến môi trường `VIEWER_HUB_SVN=<đường dẫn tới svn>` rồi mở lại Viewer Hub.

### Tool cho AI
| Tool | AI dùng để |
|---|---|
| `svn_repos` | Xem các repo được phép đọc: tên, URL, mô tả |
| `svn_branches` | Liệt kê trunk, branch, tag của một repo |
| `svn_list` | Xem thư mục trên một branch (hoặc revision) |
| `svn_read` | Đọc file trên đúng branch / revision: cả file, một đoạn dòng, hoặc chỉ các dòng có chữ cần tìm |
| `svn_log` | Lịch sử commit (ai, khi nào, sửa file nào) |
| `svn_diff` | Xem thay đổi của một commit |

### Dữ liệu cho addon khác
Addon khác (đã khai trong addon.json của nó) đọc được qua Viewer Hub, cùng các repo trong danh sách, chỉ đọc:

| Export | Trả về |
|---|---|
| `svn_repos` | Danh sách repo: tên, URL, mô tả |
| `svn_log` | Lịch sử commit của branch / đường dẫn |
| `svn_cat` | Nội dung một file trên branch / revision |

Branch ghi tên ngắn (`feature-x` = `branches/feature-x`), hoặc `trunk`, `tags/v1.0`. Không ghi thì là `trunk`.
