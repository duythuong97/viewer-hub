import { useState as e } from "/static/dist/sdk/react.js";
import { Button as t, Dialog as n, Empty as r, ErrorBanner as i, IconButton as a, Loading as o, TextField as s } from "/static/dist/sdk/md.js";
import { ListItem as c, useAction as l, useApp as u, useConfirm as d, useLoad as f, useTitle as p } from "/static/dist/sdk/ui.js";
import { Fragment as m, jsx as h, jsxs as g } from "/static/dist/sdk/jsx-runtime.js";
// web/index.jsx
var _ = {
	name: "",
	url: "",
	description: ""
};
function v({ api: v }) {
	p("SVN");
	let { app: y } = u(), { data: b, error: x } = f(() => v.get("/repos"), []), [S, C] = e(null), [w, T] = e(null), [E, D] = l(), [O, k] = d(), A = S || b, j = (e) => (t) => T({
		...w,
		[e]: t
	}), M = (e) => (e && C(e), e), N = (e) => `/repos/${encodeURIComponent(e.name)}`, P = async (e) => {
		await O({
			title: `Xoá repository “${e.name}”?`,
			confirm: "Xoá",
			icon: "delete",
			text: "AI không đọc được repository này nữa. Trên SVN không có gì bị xoá; thêm lại lúc nào cũng được."
		}) && M(await E(() => v.delete(N(e)), (e) => e.message));
	}, F = async (e) => {
		M(await E(() => v.post("/repos", w), (e) => e.message)) && e();
	}, I = !!y?.readonly;
	return /* @__PURE__ */ g(m, { children: [
		k,
		w ? /* @__PURE__ */ h(n, {
			icon: "add",
			headline: "Thêm repository",
			onClose: () => T(null),
			actions: (e) => /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(t, {
				onClick: e,
				children: "Huỷ"
			}), /* @__PURE__ */ h(t, {
				variant: "filled",
				icon: "save",
				disabled: D || !w.name || !w.url,
				onClick: () => F(e),
				children: "Lưu"
			})] }),
			children: /* @__PURE__ */ g("form", {
				className: "md-stack vh-form",
				onSubmit: (e) => {
					e.preventDefault();
				},
				children: [
					/* @__PURE__ */ h("p", {
						className: "md-card__subtitle",
						children: "URL gốc của repository (chứa trunk/, branches/, tags/). Đăng nhập SVN một lần bằng TortoiseSVN hoặc lệnh svn để máy nhớ; addon không hỏi và không lưu mật khẩu."
					}),
					/* @__PURE__ */ h(s, {
						label: "Tên",
						value: w.name,
						onChange: j("name"),
						maxLength: 40
					}),
					/* @__PURE__ */ h(s, {
						label: "URL gốc repository",
						value: w.url,
						onChange: j("url"),
						placeholder: "https://svn.example.local/svn/project"
					}),
					/* @__PURE__ */ h(s, {
						label: "Mô tả cho AI (repo chứa gì)",
						type: "textarea",
						rows: 3,
						value: w.description,
						onChange: j("description"),
						maxLength: 500
					})
				]
			})
		}) : null,
		/* @__PURE__ */ g("div", {
			className: "md-stack",
			children: [
				/* @__PURE__ */ g("div", {
					className: "md-row",
					style: {
						justifyContent: "space-between",
						flexWrap: "wrap",
						gap: 12
					},
					children: [/* @__PURE__ */ h("p", {
						className: "md-body-medium md-muted",
						style: { margin: 0 },
						children: "Chỉ đọc. svn dùng thông tin đăng nhập đã lưu trên máy này; addon không hỏi mật khẩu."
					}), I ? null : /* @__PURE__ */ h(t, {
						variant: "filled",
						icon: "add",
						onClick: () => T(_),
						children: "Thêm repository"
					})]
				}),
				x ? /* @__PURE__ */ h(i, { children: x.message }) : null,
				!A && !x ? /* @__PURE__ */ h(o, {}) : null,
				A && !A.svn ? /* @__PURE__ */ g("div", {
					className: "md-banner md-banner--error",
					role: "alert",
					children: [/* @__PURE__ */ h("md-icon", { children: "error" }), /* @__PURE__ */ g("div", {
						className: "md-banner__text",
						children: [
							/* @__PURE__ */ h("b", { children: "Chưa có lệnh svn." }),
							" ",
							A.missing
						]
					})]
				}) : null,
				A && A.repos.length ? /* @__PURE__ */ g("section", {
					className: "md-card md-card--outlined",
					children: [/* @__PURE__ */ h("div", {
						className: "md-card__body",
						children: /* @__PURE__ */ h("p", {
							className: "md-card__subtitle",
							children: "AI chỉ đọc được các repository dưới đây."
						})
					}), /* @__PURE__ */ h("ul", {
						className: "md-list",
						children: A.repos.map((e) => /* @__PURE__ */ g(c, {
							icon: "source",
							headline: e.name,
							supporting: e.description ? `${e.url} · ${e.description}` : e.url,
							children: [/* @__PURE__ */ g("md-text-button", {
								disabled: !A.svn || D || void 0,
								onClick: () => E(() => v.post(`${N(e)}/check`), (e) => e.message),
								children: [/* @__PURE__ */ h("md-icon", {
									slot: "icon",
									children: "wifi_tethering"
								}), "Kiểm tra"]
							}), /* @__PURE__ */ h(a, {
								icon: "delete",
								danger: !0,
								label: `Xoá ${e.name}`,
								disabled: I || D,
								onClick: () => P(e)
							})]
						}, e.name))
					})]
				}) : null,
				A && !A.repos.length ? /* @__PURE__ */ g(r, {
					icon: "source",
					title: "Chưa có repository nào",
					children: [
						"AI chưa đọc được gì trên SVN. Bấm ",
						/* @__PURE__ */ h("b", { children: "Thêm repository" }),
						" để thêm."
					]
				}) : null
			]
		})
	] });
}
export { v as default };
