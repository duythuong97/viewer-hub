"""Addon "svn" (managed, Python): AI reads SVN repositories by URL, on the branch it names. Read-only, compact text.

Tools
  svn_repos     the repositories the owner allowed: name, description, URL
  svn_branches  trunk, branches and tags of one repository, with their last change
  svn_list      a folder of a branch (at HEAD or a revision)
  svn_read      a file of a branch: lines with numbers, a line range, or a search for text around which to read
  svn_log       history of a branch or a path: revision, author, date, message (changed paths with verbose)
  svn_diff      what one revision changed (whole branch or one path)

Exports (other addons read through the Hub, addon.json "exports"; same allowed repositories, read-only)
  svn_repos     the repositories: name, URL, description
  svn_log       history of a branch or a path, as data
  svn_cat       one text file of a branch (decoded, with its encoding)

The page lists the repositories (add, check, delete): API below. svn runs through lib/svn_client.py only (info /
list / cat / log / diff, --non-interactive, argument lists). Standard library only; writes only under addon.data.
"""
from __future__ import annotations

from viewer_hub.addons.sdk import Addon, ApiError, ToolError, decode_text, fold, int_arg, looks_binary

import svn_client as client
from svn_client import SvnError
from svn_repos import MAX_REPOS, Repo, Repos, branch_path, check

MAX_FILE_BYTES = 4 * 1024 * 1024
DEFAULT_LINES, MAX_LINES = 200, 800
MAX_LIST = 400
DEFAULT_LOG, MAX_LOG = 20, 100
MAX_DIFF_CHARS = 40_000
CONTEXT_LINES = 15

INSTRUCTIONS = (
    "Read source files straight from SVN repositories, on the exact branch. Call svn_repos first, then "
    "svn_branches to find the branch (trunk, branches/<name>, tags/<name>). Browse with svn_list, read with svn_read "
    "(use start_line/end_line or find to stay small), see history with svn_log and a change with svn_diff. "
    "Paths are relative to the branch, e.g. 'src/Order/OrderService.cs'. Give revision to read the file as it was."
)

addon = Addon("svn", title="SVN", instructions=INSTRUCTIONS)
repos = Repos(addon.data)


_REPO = {"repo": {"type": "string", "description": "Repository name from svn_repos"}}
_BRANCH = {"branch": {"type": "string", "description": "trunk (default), branches/<name> or <name>, tags/<name>; ROOT for a repository without that layout"}}
_REV = {"revision": {"type": "string", "description": "Revision number; empty = HEAD (latest)"}}
_PATH = {"path": {"type": "string", "description": "Path inside the branch, e.g. src/app/main.py; empty = branch root"}}

TOOLS: list[dict] = [
    {"name": "svn_repos", "description": "List the SVN repositories you may read: name, description, URL.",
     "inputSchema": {"type": "object", "properties": {}}},
    {"name": "svn_branches",
     "description": "trunk, branches and tags of a repository, each with its last revision, author and date. "
                    "Optional query keeps the names containing it.",
     "inputSchema": {"type": "object", "required": ["repo"], "properties": {
         **_REPO, "query": {"type": "string", "description": "Part of a branch or tag name"}}}},
    {"name": "svn_list",
     "description": "Files and folders of a folder on a branch: name (folders end with /), size, last revision, "
                    "author, date.",
     "inputSchema": {"type": "object", "required": ["repo"], "properties": {**_REPO, **_BRANCH, **_PATH, **_REV}}},
    {"name": "svn_read",
     "description": "A text file of a branch, with line numbers. Read part of it: start_line/end_line, or find "
                    "(text to look for; the lines around each match are returned). Binary or very large files are refused.",
     "inputSchema": {"type": "object", "required": ["repo", "path"], "properties": {
         **_REPO, **_BRANCH, **_PATH, **_REV,
         "start_line": {"type": "integer", "minimum": 1},
         "end_line": {"type": "integer", "minimum": 1},
         "find": {"type": "string", "description": "Text to look for (ignores case and half / full width: ｶﾀｶﾅ = カタカナ, ＡＢＣ = ABC)"}}}},
    {"name": "svn_log",
     "description": "History of a branch or a path on it, newest first: revision, author, date, message. "
                    "verbose adds the changed paths.",
     "inputSchema": {"type": "object", "required": ["repo"], "properties": {
         **_REPO, **_BRANCH, **_PATH,
         "limit": {"type": "integer", "minimum": 1, "maximum": MAX_LOG, "default": DEFAULT_LOG},
         "verbose": {"type": "boolean", "default": False},
         "from_revision": {"type": "string", "description": "Only revisions up to this one (older history)"}}}},
    {"name": "svn_diff",
     "description": "What one revision changed, as a unified diff; limit it to a path to keep it small.",
     "inputSchema": {"type": "object", "required": ["repo", "revision"], "properties": {
         **_REPO, **_BRANCH, **_PATH, "revision": {"type": "string", "description": "The revision to show"}}}},
]


def _target(arguments: dict) -> tuple[Repo, str, str]:
    """(repo, branch path, url of path on branch)."""
    repo = repos.find(str(arguments.get("repo") or ""))
    branch = branch_path(arguments.get("branch"))
    url = client.join(repo.url, branch, str(arguments.get("path") or ""))
    return repo, branch, url


def svn_repos(_arguments: dict) -> str:
    listed = repos.load()
    if not listed:
        return "No repository is allowed yet: the owner adds them on the SVN page of Viewer Hub."
    return "\n".join(f"{r.name} — {r.description or '(no description)'}\n  {r.url}" for r in listed)


def svn_branches(arguments: dict) -> str:
    repo = repos.find(str(arguments.get("repo") or ""))
    query = str(arguments.get("query") or "").lower()
    lines = []
    for folder in ("trunk", "branches", "tags"):
        try:
            if folder == "trunk":
                meta = client.info(client.join(repo.url, "trunk"))
                entries = [("trunk", meta["last_revision"], meta["last_author"], meta["last_date"])]
            else:
                entries = [(f"{folder}/{e.name}", e.revision, e.author, e.date)
                           for e in client.list_dir(client.join(repo.url, folder)) if e.kind == "dir"]
        except SvnError:
            continue  # no such folder in this repository
        lines += [f"{name}  r{rev} {author} {date}" for name, rev, author, date in entries
                  if not query or query in name.lower()]
    if not lines:
        return (f"{repo.name}: no trunk/branches/tags found{' matching ' + query if query else ''}. "
                "If the repository has another layout, use branch='ROOT' and svn_list.")
    return f"{repo.name} ({len(lines)}):\n" + "\n".join(lines)


def svn_list(arguments: dict) -> str:
    _repo, branch, url = _target(arguments)
    rev = client.revision(arguments.get("revision"))
    entries = client.list_dir(client.peg(url, rev))
    if not entries:
        return f"{branch}/{arguments.get('path') or ''}: empty folder"
    entries.sort(key=lambda e: (e.kind != "dir", e.name.lower()))
    shown = entries[:MAX_LIST]
    rows = [f"{e.name}{'/' if e.kind == 'dir' else ''}  {'' if e.kind == 'dir' else f'{e.size:,}B '}r{e.revision} {e.author} {e.date}"
            for e in shown]
    tail = f"\n(cut: {len(entries) - len(shown)} more; list a sub-folder)" if len(entries) > len(shown) else ""
    return f"{url}{'@' + rev if rev else ''} ({len(entries)} items)\n" + "\n".join(rows) + tail


def _decode(data: bytes, name: str = "") -> tuple[str, str]:
    """(text, encoding): UTF-8 / UTF-16 / CP932 (Shift_JIS) / EUC-JP / what the file declares (SDK decode_text)."""
    if looks_binary(data):
        raise ToolError("binary file: not shown")
    return decode_text(data, name)


def _decode_diff(data: bytes) -> str:
    """A diff mixes svn's own lines (UTF-8) with file lines in each file's encoding: lines that are not UTF-8 are read
    in the legacy encoding detected from all of them together."""
    lines = data.split(b"\n")
    bad = []
    for line in lines:
        try:
            line.decode("utf-8")
        except UnicodeDecodeError:
            bad.append(line)
    legacy = decode_text(b"\n".join(bad))[1].rstrip("?") if bad else "utf-8"
    out = []
    for line in lines:
        try:
            out.append(line.decode("utf-8"))
        except UnicodeDecodeError:
            out.append(line.decode(legacy, errors="replace"))
    return "\n".join(out)


def svn_read(arguments: dict) -> str:
    _repo, _branch, url = _target(arguments)
    if not str(arguments.get("path") or "").strip():
        raise ToolError("path is required (a file inside the branch)")
    rev = client.revision(arguments.get("revision"))
    target = client.peg(url, rev)
    entries = client.list_dir(target)
    if len(entries) != 1 or entries[0].kind != "file":
        raise ToolError("not a file; use svn_list to see what is in this folder")
    if entries[0].size > MAX_FILE_BYTES:
        raise ToolError(f"file is {entries[0].size:,} bytes; too large to read here")
    text, encoding = _decode(client.cat(target), url)
    lines = text.splitlines()
    shown_encoding = "" if encoding in ("utf-8", "utf-8-sig") else f", {encoding}"
    head = f"{url}{'@' + rev if rev else ''} (r{entries[0].revision}, {len(lines)} lines{shown_encoding})"
    find_text = str(arguments.get("find") or "").strip()
    if find_text:
        wanted = fold(find_text)  # half / full width and case do not matter: ｶﾀｶﾅ finds カタカナ
        hits = [i for i, line in enumerate(lines) if wanted in fold(line)]
        if not hits:
            return f"{head}\n'{find_text}' not found"
        keep: set[int] = set()
        for i in hits[:20]:
            keep.update(range(max(0, i - CONTEXT_LINES), min(len(lines), i + CONTEXT_LINES + 1)))
        out, last = [], -2
        for i in sorted(keep)[:MAX_LINES]:
            if i != last + 1:
                out.append("…")
            out.append(f"{i + 1:>5}  {lines[i]}")
            last = i
        more = f"\n({len(hits) - 20} more matches)" if len(hits) > 20 else ""
        return f"{head}, {len(hits)} matches\n" + "\n".join(out) + more
    start = int_arg(arguments, "start_line", 1, 1, max(1, len(lines)))
    end = int_arg(arguments, "end_line", start + DEFAULT_LINES - 1, start, start + MAX_LINES - 1)
    end = min(end, len(lines))
    body = "\n".join(f"{i:>5}  {lines[i - 1]}" for i in range(start, end + 1))
    tail = f"\n(lines {start}-{end} of {len(lines)}; call again with start_line={end + 1})" if end < len(lines) else ""
    return f"{head}\n{body}{tail}"


def svn_log(arguments: dict) -> str:
    _repo, _branch, url = _target(arguments)
    limit = int_arg(arguments, "limit", DEFAULT_LOG, 1, MAX_LOG)
    verbose = bool(arguments.get("verbose"))
    start = client.revision(arguments.get("from_revision"))
    entries = client.log(client.peg(url, start), limit, verbose, f"{start}:1" if start else "")
    if not entries:
        return f"{url}: no history"
    out = []
    for e in entries:
        message = " ".join(e["message"].split())[:300]
        out.append(f"r{e['revision']} {e['author']} {e['date']}  {message}")
        if verbose:
            out += [f"    {action} {path}" for action, path in e["paths"][:40]]
            if len(e["paths"]) > 40:
                out.append(f"    … {len(e['paths']) - 40} more paths")
    return f"{url} (newest first)\n" + "\n".join(out)


def svn_diff(arguments: dict) -> str:
    _repo, _branch, url = _target(arguments)
    rev = client.revision(arguments.get("revision"))
    if not rev:
        raise ToolError("revision is required")
    text = _decode_diff(client.diff(client.peg(url, rev), rev))
    if not text.strip():
        return f"r{rev} changed nothing under {url}"
    if len(text) > MAX_DIFF_CHARS:
        return text[:MAX_DIFF_CHARS] + f"\n(cut at {MAX_DIFF_CHARS:,} chars; pass a path to see one file)"
    return text


HANDLERS = {
    "svn_repos": svn_repos, "svn_branches": svn_branches, "svn_list": svn_list, "svn_read": svn_read,
    "svn_log": svn_log, "svn_diff": svn_diff,
}


def _tool(name: str):
    def run(arguments: dict) -> str:
        try:
            return HANDLERS[name](arguments)
        except SvnError as exc:
            raise ToolError(str(exc)) from None
    return run


for _spec in TOOLS:
    addon.tool(_spec["name"], _spec["description"], _spec["inputSchema"])(_tool(_spec["name"]))


# ── Exports: what other addons may read (addon.json "exports"), the same repositories as the AI ─────────────────

def _exported(handler):
    def run(params: dict):
        try:
            return handler(params)
        except (SvnError, ToolError) as exc:
            raise ApiError("svn", str(exc), 400) from None
    return run


@addon.export("svn_repos")
@_exported
def export_repos(_params: dict) -> dict:
    return {"repos": [{"name": r.name, "url": r.url, "description": r.description} for r in repos.load()]}


@addon.export("svn_log")
@_exported
def export_log(params: dict) -> dict:
    _repo, branch, url = _target(params)
    start = client.revision(params.get("from_revision"))
    entries = client.log(client.peg(url, start), int_arg(params, "limit", DEFAULT_LOG, 1, MAX_LOG),
                         bool(params.get("verbose")), f"{start}:1" if start else "")
    return {"url": url, "branch": branch, "items": [
        {"revision": int(e["revision"] or 0), "author": e["author"], "date": e["date"], "message": e["message"],
         **({"paths": [{"action": a, "path": p} for a, p in e["paths"]]} if params.get("verbose") else {})}
        for e in entries]}


@addon.export("svn_cat")
@_exported
def export_cat(params: dict) -> dict:
    _repo, branch, url = _target(params)
    if not str(params.get("path") or "").strip():
        raise ToolError("path is required (a file inside the branch)")
    rev = client.revision(params.get("revision"))
    target = client.peg(url, rev)
    entries = client.list_dir(target)
    if len(entries) != 1 or entries[0].kind != "file":
        raise ToolError("not a file")
    if entries[0].size > MAX_FILE_BYTES:
        raise ToolError(f"file is {entries[0].size:,} bytes; too large")
    text, encoding = _decode(client.cat(target), url)
    return {"url": url, "branch": branch, "revision": int(entries[0].revision or 0), "encoding": encoding, "text": text}


# ── The page: the repositories AI may read ─────────────────────────────────────────────────────────────────────

def _state() -> dict:
    return {"repos": [{"name": r.name, "url": r.url, "description": r.description} for r in repos.load()],
            "svn": bool(client.executable()), "missing": client.MISSING, "maxRepos": MAX_REPOS}


@addon.get("/repos")
def list_repos(_request):
    return _state()


@addon.post("/repos")
def save_repo(request):
    body = request.body if isinstance(request.body, dict) else {}
    try:
        repo = check(str(body.get("name", "")), str(body.get("url", "")), str(body.get("description", "")))
    except SvnError as exc:
        raise ApiError("bad_repo", str(exc)) from exc
    current = [r for r in repos.load() if r.name != repo.name]
    if len(current) >= MAX_REPOS:
        raise ApiError("too_many", f"Tối đa {MAX_REPOS} repo")
    repos.save([*current, repo])
    return {**_state(), "message": f"Đã lưu repo {repo.name}"}


@addon.delete("/repos/<name>")
def delete_repo(request):
    name = request.params["name"]
    repos.save([r for r in repos.load() if r.name != name])
    return {**_state(), "message": f"Đã xoá repo {name}"}


@addon.post("/repos/<name>/check")
def check_repo(request):
    name = request.params["name"]
    try:
        meta = client.info(repos.find(name).url)
    except SvnError as exc:
        raise ApiError("svn", f"{name}: {exc}") from exc
    return {"message": f"{name}: kết nối được: r{meta['revision']}, sửa lần cuối bởi {meta['last_author']} {meta['last_date']}"}


if __name__ == "__main__":
    addon.run()
