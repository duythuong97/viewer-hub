"""Runs the machine's ``svn`` client, read-only, for the SVN addon.

Only ``info``, ``list``, ``cat``, ``log`` and ``diff`` run, always with ``--non-interactive`` and an argument list (no
shell). Credentials stay with svn: it uses what it has cached for the user; the addon never reads, asks for or stores
a password. Every URL is built from a repository the owner listed (svn_repos.py) plus a checked relative path, so AI
cannot reach another server or repository.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET  # noqa: S405  (svn's own XML output, parsed without DTDs or entities)
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import quote

TIMEOUT = 60
MAX_OUTPUT = 8 * 1024 * 1024
READ_COMMANDS = ("info", "list", "cat", "log", "diff")


class SvnError(RuntimeError):
    """svn is missing, failed or refused (message is safe to show)."""


def executable() -> str | None:
    """``svn`` on PATH, TortoiseSVN's command line client on Windows, or VIEWER_HUB_SVN."""
    if os.environ.get("VIEWER_HUB_SVN"):
        return os.environ["VIEWER_HUB_SVN"]
    found = shutil.which("svn")
    if found:
        return found
    if sys.platform == "win32":
        for base in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)")):
            candidate = Path(base or "") / "TortoiseSVN" / "bin" / "svn.exe"
            if base and candidate.is_file():
                return str(candidate)
    return None


MISSING = ("Không tìm thấy lệnh svn. Mac: cài Subversion (brew install subversion). Windows: cài TortoiseSVN và chọn "
           "'command line client tools'.")


def run(command: str, *args: str) -> bytes:
    """One read-only svn command; its stdout (bytes)."""
    if command not in READ_COMMANDS:
        raise SvnError(f"svn {command} không được phép")
    svn = executable()
    if not svn:
        raise SvnError(MISSING)
    argv = [svn, command, "--non-interactive", *args]
    if svn.endswith(".py"):  # tests: a stand-in svn written in Python
        argv.insert(0, sys.executable)
    try:
        result = subprocess.run(argv, capture_output=True, timeout=TIMEOUT, stdin=subprocess.DEVNULL,
                                env={**os.environ, "LC_MESSAGES": "C"})
    except subprocess.TimeoutExpired:
        raise SvnError(f"svn {command} quá {TIMEOUT} giây") from None
    except OSError as exc:
        raise SvnError(f"Không chạy được svn: {exc}") from None
    if result.returncode != 0:
        message = result.stderr.decode("utf-8", errors="replace").strip().splitlines()
        raise SvnError("svn: " + (" ".join(message[-2:]) if message else f"lỗi {result.returncode}"))
    if len(result.stdout) > MAX_OUTPUT:
        raise SvnError("Kết quả svn quá lớn; thu hẹp đường dẫn hoặc số revision")
    return result.stdout


def _xml(data: bytes) -> ET.Element:
    if b"<!DOCTYPE" in data or b"<!ENTITY" in data:
        raise SvnError("svn trả XML không hợp lệ")
    try:
        return ET.fromstring(data)
    except ET.ParseError as exc:
        raise SvnError(f"svn trả XML không đọc được: {exc}") from None


# ── URLs: a listed repository + a checked relative path ─────────────────────────────────────────────

def clean_path(path: str) -> str:
    """A relative path inside a repository ('' = its root); refuses '..', URLs and backslashes."""
    path = (path or "").strip().replace("\\", "/").strip("/")
    parts = [p for p in path.split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts) or "://" in path or "@" in path:
        raise SvnError(f"Đường dẫn không hợp lệ: {path}")
    return "/".join(parts)


def join(root: str, *paths: str) -> str:
    rel = "/".join(p for p in (clean_path(x) for x in paths) if p)
    return root.rstrip("/") + ("/" + quote(rel, safe="/") if rel else "")


def peg(url: str, rev: str | int | None) -> str:
    """``url@rev`` (peg revision: the file as it was at that revision, even if moved since)."""
    return f"{url}@{rev}" if rev not in (None, "", "HEAD") else url


def revision(value) -> str | None:
    if value in (None, "", "HEAD", "head"):
        return None
    text = str(value).strip().lstrip("r")
    if not text.isdigit():
        raise SvnError("revision phải là số (vd. 1234) hoặc HEAD")
    return text


# ── Commands ────────────────────────────────────────────────────────────────────────────────────────

@dataclass
class Entry:
    name: str
    kind: str          # file | dir
    size: int
    revision: str
    author: str
    date: str


def info(url: str) -> dict:
    root = _xml(run("info", "--xml", url))
    entry = root.find("entry")
    if entry is None:
        raise SvnError("svn info không có kết quả")
    commit = entry.find("commit")
    return {
        "url": entry.findtext("url", ""), "kind": entry.get("kind", ""), "revision": entry.get("revision", ""),
        "root": entry.findtext("repository/root", ""), "uuid": entry.findtext("repository/uuid", ""),
        "last_revision": commit.get("revision", "") if commit is not None else "",
        "last_author": entry.findtext("commit/author", ""), "last_date": entry.findtext("commit/date", "")[:19],
    }


def list_dir(url: str) -> list[Entry]:
    root = _xml(run("list", "--xml", url))
    out = []
    for item in root.iter("entry"):
        commit = item.find("commit")
        out.append(Entry(item.findtext("name", ""), item.get("kind", ""), int(item.findtext("size") or 0),
                         commit.get("revision", "") if commit is not None else "", item.findtext("commit/author", ""),
                         item.findtext("commit/date", "")[:19]))
    return out


def cat(url: str) -> bytes:
    return run("cat", url)


def log(url: str, limit: int, verbose: bool, revision_range: str = "") -> list[dict]:
    args = ["--xml", "-l", str(limit), *(["-v"] if verbose else []), *(["-r", revision_range] if revision_range else []), url]
    root = _xml(run("log", *args))
    out = []
    for item in root.iter("logentry"):
        out.append({
            "revision": item.get("revision", ""), "author": item.findtext("author", ""),
            "date": item.findtext("date", "")[:19], "message": (item.findtext("msg") or "").strip(),
            "paths": [(p.get("action", ""), p.text or "") for p in item.iter("path")],
        })
    return out


def diff(url: str, change: str) -> bytes:
    """Raw: file lines keep each file's own encoding (main.py decodes)."""
    return run("diff", "-c", change, url)
