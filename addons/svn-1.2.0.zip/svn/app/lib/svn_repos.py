"""The repositories AI may read: name, root URL, description; kept in ``<addon data>/repos.json``.

The root URL is the repository root that holds ``trunk/``, ``branches/`` and ``tags/``. A branch is named the SVN
way: ``trunk``, ``branches/<name>`` (or just ``<name>``) or ``tags/<name>``.

When SVN was a Viewer Hub module the list lived in hub.db (setting ``svn.repos``); the Hub copies it to
``repos.json`` once when it starts, so nothing is lost by moving to the addon.
"""
from __future__ import annotations

import json
import os
import re
import threading
from dataclasses import asdict, dataclass
from pathlib import Path
from urllib.parse import urlparse

from svn_client import SvnError, clean_path

NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,40}$")
SCHEMES = {"https", "http", "svn", "svn+ssh", "file"}
MAX_REPOS = 50


@dataclass
class Repo:
    name: str
    url: str
    description: str = ""


class Repos:
    def __init__(self, data: Path) -> None:
        self.file = Path(data) / "repos.json"
        self._lock = threading.Lock()

    def load(self) -> list[Repo]:
        try:
            raw = json.loads(self.file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []
        if not isinstance(raw, list):
            return []
        return [Repo(str(r.get("name", "")), str(r.get("url", "")), str(r.get("description", "")))
                for r in raw if isinstance(r, dict) and r.get("name") and r.get("url")]

    def save(self, repos: list[Repo]) -> None:
        """Atomic: a temporary file, then one rename."""
        with self._lock:
            self.file.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.file.with_suffix(".json.tmp")
            tmp.write_text(json.dumps([asdict(r) for r in repos], ensure_ascii=False, indent=1), encoding="utf-8")
            os.replace(tmp, self.file)

    def find(self, name: str) -> Repo:
        repos = self.load()
        for repo in repos:
            if repo.name == name:
                return repo
        known = ", ".join(r.name for r in repos) or "chưa có repo nào (thêm ở trang SVN)"
        raise SvnError(f"Không có repo '{name}'. Repo được phép: {known}")


def check(name: str, url: str, description: str = "") -> Repo:
    name, url = (name or "").strip(), (url or "").strip().rstrip("/")
    if not NAME_RE.match(name):
        raise SvnError("Tên repo: chữ, số, . _ - (tối đa 40 ký tự)")
    parsed = urlparse(url)
    if parsed.scheme not in SCHEMES or (parsed.scheme != "file" and not parsed.netloc):
        raise SvnError("URL phải là https://, http://, svn:// hoặc svn+ssh:// tới gốc repository")
    if parsed.username or parsed.password:
        raise SvnError("Không ghi user/mật khẩu trong URL; svn dùng thông tin đăng nhập đã lưu của nó")
    return Repo(name, url, (description or "").strip()[:500])


def branch_path(branch: str | None) -> str:
    """'' / 'trunk' -> trunk; 'branches/x' and 'tags/x' as given; a bare 'x' -> branches/x; 'ROOT' -> the
    repository root (repositories without the trunk/branches/tags layout)."""
    if (branch or "").strip().upper() == "ROOT":
        return ""
    branch = clean_path(branch or "trunk")
    if branch == "trunk" or branch.startswith(("trunk/", "branches/", "tags/")):
        return branch
    return f"branches/{branch}"
