## DB Query

Cho AI xem cấu trúc bảng và dữ liệu mẫu trong Oracle (**chỉ đọc**), để viết script data test (INSERT đúng thứ tự
khoá ngoại, kèm DELETE để dọn).

### Thêm kết nối

1. Mở mục **DB Query** trên menu, bấm nút **Cài đặt** (bánh răng) ở góc phải.
2. Ô **Kết nối Oracle**: mỗi dòng một kết nối, các phần cách nhau bằng `|`:

   `tên | connect string | user | schema | mô tả`

   Vd. `DEV | 10.0.0.5:1521/ORCLPDB1 | app_user | APP | DB dev dự án A`. Bỏ port thì dùng 1521.
   Connect string có thể là `host:port/service`, `tcps://host:port/service` (TLS), hoặc nguyên chuỗi
   `(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=...)(PORT=...))(CONNECT_DATA=(SERVICE_NAME=...)))` chép từ
   tnsnames.ora (viết trên một dòng). Chưa hỗ trợ tên alias TNS.
   Schema là nơi AI tìm bảng (có thể khác user).
3. Lưu. Kết nối hiện ở phía dưới trang.

### Nhập mật khẩu

Mật khẩu **không lưu xuống đĩa**: chỉ giữ trong bộ nhớ của addon, mất khi đóng Viewer Hub. Mỗi lần mở lại Hub, nhập
mật khẩu ở thẻ của từng kết nối rồi bấm [icon:network_check] **Kiểm tra kết nối**. Đúng thì thẻ hiện
**Sẵn sàng** và AI dùng được kết nối đó. [icon:key_off] **Quên mật khẩu** để AI thôi dùng kết nối.

### An toàn

User Oracle thường có quyền ghi, nên addon tự chặn:

- Chỉ nhận **một** câu `SELECT` hoặc `WITH` (bỏ qua comment và chuỗi khi kiểm tra); chặn `;` giữa các câu,
  `FOR UPDATE`, `NEXTVAL`, gọi hàm trong package (`xxx.yyy(...)`).
- Mỗi câu chạy trong `SET TRANSACTION READ ONLY`, rồi `ROLLBACK`.
- Tối đa 50 dòng, quá 30 giây thì dừng.

Hàm thường (không thuộc package) vẫn gọi được: nếu DB có hàm tự ghi dữ liệu (autonomous transaction), nên dùng user
chỉ có quyền đọc.

### Dữ liệu cho addon khác
Addon khác (đã khai trong addon.json của nó) đọc được **cấu trúc** database qua Viewer Hub, chỉ đọc. Dữ liệu trong
bảng (`db_query`) không chia sẻ cho addon khác. Kết nối phải đã nhập mật khẩu, như với AI.

| Export | Trả về |
|---|---|
| `db_connections` | Danh sách kết nối và đã sẵn sàng chưa |
| `db_tables` | Bảng / view tìm theo tên hoặc comment |
| `db_describe` | Cột, khoá chính, unique, khoá ngoại, check, bảng con của một bảng |

### Tool cho AI

| Tool | Làm gì |
|---|---|
| `db_connections` | Danh sách kết nối: tên, mô tả, schema, đã sẵn sàng (đã nhập mật khẩu) chưa |
| `db_tables` | Tìm bảng / view theo tên hoặc comment; trả tên, comment, số dòng ước tính |
| `db_describe` | Cấu trúc một bảng: cột (kiểu, độ dài, NOT NULL, mặc định, comment), PK, unique, FK tới bảng cha, check constraint, bảng con tham chiếu tới |
| `db_query` | Chạy một câu SELECT (tối đa 50 dòng) để xem dữ liệu mẫu, mã master, giá trị đang dùng |

Ví dụ nhờ AI: *“Viết data test cho case: khách hàng có 2 đơn chưa giao”*. AI tìm bảng (`db_tables`), xem cấu trúc
và khoá ngoại (`db_describe`), xem dữ liệu thật (`db_query`), rồi viết INSERT theo đúng thứ tự bảng cha → bảng con,
kèm câu DELETE để dọn sau khi test.
