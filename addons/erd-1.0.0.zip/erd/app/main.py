"""ERD addon (managed, Python): the whole-database ERD of a Code map pack, for its page and for AI.

Code map is a builtin module of Viewer Hub that exports its data model (docs/addons.md §3.2 of the Hub):

    erd_model    the ERD model (erd.build on the Hub: table + depth, schema, system or a list of tables), with
                 Mermaid / DBML text on request
    db_objects   table search (technical / logical names), schemas, systems, packs
    table_usage  features, APIs, jobs and code reading or writing one table

The ERD logic stays in the Hub (viewer_hub/codemap/erd.py); this addon only asks for it through ``addon.call`` and
draws it (web/index.jsx). Nothing is written: no data folder, read-only MCP tool.
"""
from __future__ import annotations

import json

from viewer_hub.addons.sdk import Addon, ApiError, CallError, ToolError

addon = Addon("erd", title="ERD",
              instructions="Read-only entity-relationship diagrams (foreign keys) of the databases in the user's "
                           "Code map packs. Use erd_diagram for the tables linked to a table, a whole schema or system, "
                           "or a given list of tables; it answers Mermaid erDiagram, DBML or JSON.")

MAX_TABLES = 80
DEFAULT_TABLES = 40
FORMATS = ("mermaid", "dbml", "json")
NO_CODEMAP = {"dependency_missing", "dependency_incompatible", "export_unknown"}


def _codemap(export: str, params: dict) -> dict:
    """One Code map export; its errors become the page's (Vietnamese message, same code)."""
    try:
        return addon.call("codemap", export, params)
    except CallError as exc:
        if exc.code in NO_CODEMAP:
            raise ApiError("no_codemap", f"Viewer Hub này chưa cho đọc dữ liệu Code map ({exc.message}). "
                                         "Cần Viewer Hub bản mới hơn.", 424) from exc
        status = exc.status if 400 <= exc.status < 600 else 502
        raise ApiError(exc.code, exc.message, status) from exc


def _text(query: dict, name: str, limit: int = 300) -> str:
    value = str(query.get(name) or "").strip()
    if len(value) > limit:
        raise ApiError("bad_argument", f"{name} dài quá {limit} ký tự")
    return value


def _tables(value: str) -> list[str]:
    names = [part.strip() for part in value.split(",") if part.strip()]
    if len(names) > MAX_TABLES:
        raise ApiError("bad_argument", f"Tối đa {MAX_TABLES} bảng")
    return names


def _scope(query: dict) -> dict:
    """The model request of the page: exactly one of table (+ depth), schema, system, tables."""
    params: dict = {}
    pack = _text(query, "pack", 100)
    if pack:
        params["pack"] = pack
    table, schema, system = _text(query, "table"), _text(query, "schema"), _text(query, "system")
    tables = _tables(_text(query, "tables", 30_000))
    if table:
        params["table"] = table
        depth = _text(query, "depth", 1) or "1"
        if depth not in ("1", "2"):
            raise ApiError("bad_depth", "depth phải là 1 hoặc 2")
        params["depth"] = int(depth)
    elif schema:
        params["schema"] = schema
    elif system:
        params["system"] = system
    elif tables:
        params["tables"] = tables
    else:
        raise ApiError("bad_scope", "Chọn một bảng, một schema, một hệ thống hoặc danh sách bảng")
    return params


@addon.get("/model")
def model(request):
    return _codemap("erd_model", _scope(request.query))


@addon.get("/text")
def text(request):
    """Mermaid / DBML of the same scope (the export dialog)."""
    fmt = _text(request.query, "format", 10) or "mermaid"
    if fmt not in ("mermaid", "dbml"):
        raise ApiError("bad_format", "format phải là mermaid hoặc dbml")
    params = {**_scope(request.query), "format": fmt, "columns": "keys" if request.query.get("keys") == "1" else "all"}
    reply = _codemap("erd_model", params)
    return {"text": reply.get("text", ""), "filename": reply.get("filename") or f"erd.{fmt}"}


@addon.get("/tables")
def tables(request):
    params = {"q": _text(request.query, "q", 200), "schema": _text(request.query, "schema")}
    pack = _text(request.query, "pack", 100)
    if pack:
        params["pack"] = pack
    limit = _text(request.query, "limit", 3) or "30"
    if not limit.isdigit() or not 1 <= int(limit) <= 100:
        raise ApiError("bad_argument", "limit phải là số từ 1 tới 100")
    params["limit"] = int(limit)
    return _codemap("db_objects", params)


@addon.get("/usage")
def usage(request):
    table = _text(request.query, "table")
    if not table:
        raise ApiError("table_required", "Cần tên bảng")
    params = {"table": table, "limit": 50}
    pack = _text(request.query, "pack", 100)
    if pack:
        params["pack"] = pack
    return _codemap("table_usage", params)


# ── MCP ─────────────────────────────────────────────────────────────────────────────────────────────────────────

ERD_SCHEMA = {
    "type": "object",
    "properties": {
        "table": {"type": "string", "description": "Focus table: name (ORDERS), SCHEMA.TABLE, DB.SCHEMA.TABLE or node id."},
        "schema": {"type": "string", "description": "Instead of table: every table of a schema, e.g. DB1.APP."},
        "system": {"type": "string", "description": "Instead of table: every table of a system (system key)."},
        "tables": {"type": "array", "items": {"type": "string"},
                   "description": "Instead of table: exactly these tables (foreign keys only between them)."},
        "depth": {"type": "integer", "enum": [1, 2], "description": "FK hops from the focus table (default 1)."},
        "format": {"type": "string", "enum": list(FORMATS), "description": "Diagram format (default mermaid)."},
        "columns": {"type": "string", "enum": ["all", "keys"], "description": "all columns (default) or only PK/FK columns."},
        "max_tables": {"type": "integer", "minimum": 1, "maximum": MAX_TABLES,
                       "description": f"Most tables in the diagram (default {DEFAULT_TABLES})."},
        "pack": {"type": "string", "description": "Code map pack id (default: the first active one)."},
    },
}


def _arg_text(arguments: dict, name: str, limit: int = 300) -> str:
    value = arguments.get(name)
    if value is None:
        return ""
    if not isinstance(value, str) or len(value) > limit:
        raise ToolError(f"{name} must be a string of at most {limit} characters")
    return value.strip()


def diagram_answer(arguments: dict) -> str:
    params: dict = {}
    for name in ("table", "schema", "system"):
        value = _arg_text(arguments, name)
        if value:
            params[name] = value
    tables = arguments.get("tables")
    if tables is not None:
        if not isinstance(tables, list) or not all(isinstance(item, str) for item in tables) or len(tables) > MAX_TABLES:
            raise ToolError(f"tables must be a list of at most {MAX_TABLES} table names")
        params["tables"] = [item.strip() for item in tables if item.strip()]
    if len(params) != 1:
        raise ToolError("give exactly one of table, schema, system or tables")
    fmt = _arg_text(arguments, "format", 10) or "mermaid"
    if fmt not in FORMATS:
        raise ToolError("format must be mermaid, dbml or json")
    depth = arguments.get("depth", 1)
    if depth not in (1, 2, "1", "2"):
        raise ToolError("depth must be 1 or 2")
    if "table" in params:
        params["depth"] = int(depth)
    max_tables = arguments.get("max_tables", DEFAULT_TABLES)
    if not isinstance(max_tables, int) or isinstance(max_tables, bool) or not 1 <= max_tables <= MAX_TABLES:
        raise ToolError(f"max_tables must be an integer from 1 to {MAX_TABLES}")
    columns = _arg_text(arguments, "columns", 10) or "all"
    if columns not in ("all", "keys"):
        raise ToolError("columns must be all or keys")
    pack = _arg_text(arguments, "pack", 100)
    if pack:
        params["pack"] = pack
    params.update(limit=max_tables, format="mermaid" if fmt == "json" else fmt, columns=columns)
    try:
        model = addon.call("codemap", "erd_model", params)
    except CallError as exc:
        raise ToolError(exc.message) from exc
    return render_answer(model, fmt)


def render_answer(model: dict, fmt: str) -> str:
    tables = {item["id"]: item for item in model.get("tables", [])}
    body = [f"## {model.get('summary', 'ERD')}"]
    if model.get("pack"):
        body.append(f"Code map pack: {model['pack']}")
    relations = model.get("relations", [])
    if relations:
        body += ["", "Foreign keys (child → parent):"]
        for relation in relations:
            source, target = tables.get(relation["from_table"], {}), tables.get(relation["to_table"], {})
            extras = [relation.get("cardinality") or "many-to-one"]
            if relation.get("delete_rule") and relation["delete_rule"] != "NO ACTION":
                extras.append(f"ON DELETE {relation['delete_rule']}")
            if relation.get("source"):
                extras.append(f"from {relation['source']}")
            body.append(f"- {relation.get('constraint') or '(unnamed)'}: "
                        f"{source.get('qualified_name', relation['from_table'])}.({', '.join(relation['from_columns'])}) → "
                        f"{target.get('qualified_name', relation['to_table'])}.({', '.join(relation['to_columns'])}) "
                        f"[{'; '.join(extras)}]")
    body.append("")
    if fmt == "json":
        shown = {key: value for key, value in model.items() if key not in ("text", "filename")}
        body += ["```json", json.dumps(shown, ensure_ascii=False), "```"]
    else:
        body += [f"```{fmt}", str(model.get("text", "")).rstrip("\n"), "```"]
    uncertain: list[str] = []
    if not model.get("has_fk_data"):
        uncertain.append(f"- {model.get('message') or 'No foreign-key data in this pack.'} "
                         "(This pack has no foreign-key data: re-extract with the new code-map.)")
    if model.get("truncated"):
        uncertain.append(f"- {model.get('omitted')} table(s) beyond max_tables={model.get('limit')} are not shown; "
                         "narrow with table + depth=1 or raise max_tables.")
    if model.get("outside_relations"):
        uncertain.append(f"- {model['outside_relations']} foreign key(s) of these tables point to or come from tables not shown.")
    if model.get("missing"):
        uncertain.append("- Not found in the pack: " + ", ".join(model["missing"][:20]))
    ddl = [relation.get("constraint") or relation["id"] for relation in relations if relation.get("source") == "ddl"]
    if ddl:
        uncertain.append("- Parsed from DDL files, not the database catalog (may differ from the live schema): " + ", ".join(ddl[:20]))
    if relations:
        uncertain.append("- Cardinality is a guess: one-to-one only when the FK columns are the whole primary key "
                         "(unique constraints are not in the graph).")
    uncertain.append("- Only declared foreign-key constraints are shown; joins written in code without a constraint are not. "
                     "Use codemap_impact (Code map) for the code that reads and writes these tables.")
    return "\n".join(body + ["", "## Not certain", *uncertain])


@addon.tool(
    "erd_diagram",
    "Entity-relationship diagram from the database catalog of a Code map pack: the tables linked to a table by "
    "foreign keys (depth 1-2, both directions), every table of a schema or system, or exactly a given list of tables, "
    "with columns, types, PK/FK flags, logical names (ja/en) and each FK's columns and ON DELETE rule. Use it for "
    "impact analysis of a table or column change (which child tables break, what cascades on delete), to understand "
    "a data model before writing SQL, or to give a diagram (Mermaid erDiagram by default, DBML for dbdiagram.io, or JSON).",
    ERD_SCHEMA,
)
def erd_diagram(arguments):
    return diagram_answer(arguments)


if __name__ == "__main__":
    addon.run()
