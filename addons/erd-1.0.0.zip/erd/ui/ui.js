import { memo as e, useCallback as t, useEffect as n, useMemo as r, useRef as i, useState as a } from "/static/dist/sdk/react.js";
import { Background as o, Controls as s, Handle as c, Position as l, ReactFlow as u, ReactFlowProvider as d, useEdgesState as f, useNodesInitialized as p, useNodesState as m, useReactFlow as h } from "/static/dist/sdk/flow.js";
import { Badge as g, useLayout as _, useQuery as v, useTitle as y } from "/static/dist/sdk/ui.js";
import { Button as b, Dialog as x, Empty as ee, ErrorBanner as S, FilterBar as C, IconButton as te, Loading as w, Progress as T, Select as E } from "/static/dist/sdk/md.js";
import { Fragment as D, jsx as O, jsxs as k } from "/static/dist/sdk/jsx-runtime.js";
// web/erd-layout.js
var A = {
	header: 52,
	row: 28,
	pad: 8,
	gapX: 140,
	gapY: 36
}, j = {
	tech: 300,
	logical: 400
};
function M(e, t) {
	return (e.columns || []).filter((e) => !t || e.pk || e.fk || e.referenced);
}
function N(e) {
	return A.header + Math.max(1, e) * A.row + A.pad;
}
function P(e) {
	let t = e.tables || [], n = (e.relations || []).filter((e) => e.from_table !== e.to_table), r = /* @__PURE__ */ new Map();
	if (e.mode === "table" && t.every((e) => Number.isInteger(e.layer))) return t.forEach((e) => r.set(e.id, e.layer)), r;
	let i = new Set(n.flatMap((e) => [e.from_table, e.to_table])), a = new Map(t.map((e) => [e.id, 0])), o = t.length;
	for (let e = 0; e < o; e += 1) {
		let e = !1;
		for (let t of n) {
			if (!a.has(t.from_table) || !a.has(t.to_table)) continue;
			let n = a.get(t.from_table) + 1;
			n > a.get(t.to_table) && n <= o && (a.set(t.to_table, n), e = !0);
		}
		if (!e) break;
	}
	return t.forEach((e) => r.set(e.id, i.has(e.id) ? a.get(e.id) : null)), r;
}
function F(e, { width: t = j.tech, rowsOf: n = (e) => (e.columns || []).length } = {}) {
	let r = e.tables || [], i = P(e), a = new Map(r.map((e) => [e.id, []]));
	for (let t of e.relations || []) a.get(t.from_table)?.push(t.to_table), a.get(t.to_table)?.push(t.from_table);
	let o = /* @__PURE__ */ new Map(), s = [];
	for (let e of r) {
		let t = i.get(e.id);
		t == null ? s.push(e) : (o.has(t) || o.set(t, []), o.get(t).push(e));
	}
	let c = [...o.keys()].sort((e, t) => e - t), l = /* @__PURE__ */ new Map(), u = {}, d = (e) => N(n(e)), f = 0;
	if (c.forEach((e, n) => {
		let r = o.get(e);
		if (n > 0) {
			let e = (e) => {
				let t = a.get(e.id).filter((e) => l.has(e)).map((e) => l.get(e));
				return t.length ? t.reduce((e, t) => e + t, 0) / t.length : Infinity;
			}, t = new Map(r.map((t) => [t.id, e(t)]));
			r.sort((e, n) => t.get(e.id) - t.get(n.id) || 0);
		}
		r.forEach((e, t) => l.set(e.id, t));
		let i = -(r.reduce((e, t) => e + d(t), 0) + A.gapY * (r.length - 1)) / 2;
		for (let e of r) u[e.id] = {
			x: f,
			y: i
		}, i += d(e) + A.gapY;
		f += t + A.gapX;
	}), s.length) {
		let e = Math.max(1, Math.ceil(Math.sqrt(s.length))), n = c.length ? -A.header : 0;
		for (let r = 0; r < s.length; r += e) {
			let i = s.slice(r, r + e);
			i.forEach((e, r) => {
				u[e.id] = {
					x: f + r * (t + A.gapY),
					y: n
				};
			}), n += Math.max(...i.map(d)) + A.gapY;
		}
	}
	return u;
}
function I(e, t) {
	return e < t ? {
		source: "r",
		target: "l"
	} : e > t ? {
		source: "l",
		target: "r"
	} : {
		source: "r",
		target: "r"
	};
}
function L(e, t) {
	if (!e || t === "tech") return "";
	let n = e.logical || {};
	return n[t] || n.ja || n.en || "";
}
function R(e = {}) {
	let t = e.depth === "2" ? "2" : "1", n = [
		"ja",
		"en",
		"tech"
	].includes(e.names) ? e.names : "ja", r = e.cols === "keys" ? "keys" : "all", i = e.table || "", a = i ? "" : e.schema || "", o = i || a ? "" : e.system || "";
	return {
		table: i,
		schema: a,
		system: o,
		tables: i || a || o ? "" : e.tables || "",
		depth: t,
		names: n,
		cols: r,
		pack: e.pack || ""
	};
}
function z(e) {
	let t = R(e), n = {};
	for (let e of [
		"table",
		"schema",
		"system",
		"tables",
		"pack"
	]) t[e] && (n[e] = t[e]);
	return t.table && t.depth !== "1" && (n.depth = t.depth), t.names !== "ja" && (n.names = t.names), t.cols !== "all" && (n.cols = t.cols), n;
}
function B(e, t) {
	return `erd-${String(e || "erd").replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^[._]+|[._]+$/g, "").slice(0, 80) || "erd"}.${t === "mermaid" ? "mmd" : t}`;
}
// web/index.jsx
var V = [
	["ja", "日本語"],
	["en", "English"],
	["tech", "Tên kỹ thuật"]
], H = [["1", "1 bước"], ["2", "2 bước"]], ne = [["all", "Tất cả cột"], ["keys", "Chỉ cột khoá"]], U = {
	CASCADE: "xoá dây chuyền",
	"SET NULL": "đặt NULL",
	"SET DEFAULT": "đặt mặc định",
	RESTRICT: "chặn xoá"
}, W = {
	C: "Tạo",
	R: "Đọc",
	U: "Sửa",
	D: "Xoá"
}, G = {
	screen: "Màn hình",
	job: "Job",
	api: "API",
	plsql: "PL/SQL",
	sql: "SQL",
	other: "Khác"
}, K = (e) => window.md?.snackbar(e), q = (e) => String(e || "").split("").map((e) => W[e] || e).join(", ");
async function J(e, t) {
	try {
		return await navigator.clipboard.writeText(e), !0;
	} catch {
		return t?.focus(), t?.select(), !1;
	}
}
function Y(e, t) {
	let n = URL.createObjectURL(new Blob([t], { type: "text/plain;charset=utf-8" })), r = document.createElement("a");
	r.href = n, r.download = e, document.body.appendChild(r), r.click(), r.remove(), setTimeout(() => URL.revokeObjectURL(n), 1e3);
}
function X({ api: e, schema: t, pack: r, onPick: o }) {
	let [s, c] = a(""), [l, u] = a(!1), [d, f] = a({
		loading: !1,
		error: "",
		tables: [],
		total: 0
	}), [p, m] = a(0), h = i(null), g = i(null);
	n(() => {
		if (!l) return;
		let n = !0, i = setTimeout(async () => {
			f((e) => ({
				...e,
				loading: !0,
				error: ""
			}));
			try {
				let i = await e.get("/tables", {
					q: s.trim(),
					schema: t,
					pack: r,
					limit: 30
				});
				if (!n) return;
				f({
					loading: !1,
					error: "",
					tables: i.tables || [],
					total: i.total || 0
				}), m(0);
			} catch (e) {
				n && f({
					loading: !1,
					error: e.message,
					tables: [],
					total: 0
				});
			}
		}, 160);
		return () => {
			n = !1, clearTimeout(i);
		};
	}, [
		e,
		s,
		t,
		r,
		l
	]), n(() => {
		let e = (e) => {
			g.current?.contains(e.target) || u(!1);
		};
		return document.addEventListener("mousedown", e), () => document.removeEventListener("mousedown", e);
	}, []);
	function _(e) {
		e && (u(!1), c(""), h.current?.blur(), o(e.id));
	}
	function v(e) {
		e.key === "ArrowDown" ? (m((e) => Math.min(e + 1, d.tables.length - 1)), e.preventDefault()) : e.key === "ArrowUp" ? (m((e) => Math.max(e - 1, 0)), e.preventDefault()) : e.key === "Enter" ? (_(d.tables[p]), e.preventDefault()) : e.key === "Escape" && (u(!1), h.current?.blur());
	}
	return /* @__PURE__ */ k("div", {
		className: "erd-picker",
		ref: g,
		children: [/* @__PURE__ */ k("div", {
			className: "md-search-bar erd-picker__bar",
			children: [
				/* @__PURE__ */ O("md-icon", { children: "table" }),
				/* @__PURE__ */ O("input", {
					ref: h,
					type: "search",
					value: s,
					autoComplete: "off",
					spellCheck: !1,
					"aria-label": "Chọn bảng",
					role: "combobox",
					"aria-expanded": l,
					placeholder: "Chọn bảng: tên kỹ thuật hoặc tên logic (日本語 / English)…",
					onChange: (e) => {
						c(e.target.value), u(!0);
					},
					onFocus: () => u(!0),
					onKeyDown: v
				}),
				/* @__PURE__ */ O("md-icon-button", {
					class: "md-search-bar__clear",
					"aria-label": "Xoá nội dung tìm",
					hidden: !s || void 0,
					onClick: () => {
						c(""), h.current?.focus();
					},
					children: /* @__PURE__ */ O("md-icon", { children: "close" })
				}),
				/* @__PURE__ */ O("md-filled-icon-button", {
					class: "md-search-bar__submit",
					"aria-label": "Mở bảng đang chọn",
					title: "Mở bảng đang chọn (Enter)",
					onClick: () => {
						l && d.tables[p] ? _(d.tables[p]) : (u(!0), h.current?.focus());
					},
					children: /* @__PURE__ */ O("md-icon", { children: "search" })
				})
			]
		}), l ? /* @__PURE__ */ k("div", {
			className: "erd-picker__menu",
			role: "listbox",
			children: [
				d.loading ? /* @__PURE__ */ O(T, {}) : null,
				d.error ? /* @__PURE__ */ O("p", {
					className: "erd-picker__empty",
					children: d.error
				}) : null,
				!d.error && !d.tables.length ? /* @__PURE__ */ O("p", {
					className: "erd-picker__empty",
					children: d.loading ? "Đang tìm…" : `Không có bảng nào khớp “${s}”.`
				}) : null,
				d.tables.length ? /* @__PURE__ */ k("h6", {
					className: "erd-picker__group",
					children: ["Bảng", d.total > d.tables.length ? ` · ${d.tables.length}/${d.total}` : ""]
				}) : null,
				d.tables.map((e, t) => /* @__PURE__ */ k("button", {
					type: "button",
					role: "option",
					"aria-selected": t === p,
					className: `erd-hit${t === p ? " is-active" : ""}`,
					onMouseEnter: () => m(t),
					onClick: () => _(e),
					children: [/* @__PURE__ */ O("span", {
						className: "erd-hit__icon",
						children: /* @__PURE__ */ O("md-icon", { children: "table" })
					}), /* @__PURE__ */ k("span", {
						className: "erd-hit__text",
						children: [/* @__PURE__ */ O("b", {
							className: "erd-mono",
							children: e.name
						}), /* @__PURE__ */ O("small", { children: [
							`${e.database}.${e.schema}`,
							e.logical?.ja,
							e.logical?.en
						].filter(Boolean).join(" · ") })]
					})]
				}, e.id))
			]
		}) : null]
	});
}
var re = {
	isConnectable: !1,
	className: "erd-handle"
}, ie = [
	[
		"source",
		l.Left,
		"s-l"
	],
	[
		"source",
		l.Right,
		"s-r"
	],
	[
		"target",
		l.Left,
		"t-l"
	],
	[
		"target",
		l.Right,
		"t-r"
	]
];
function Z({ index: e, used: t }) {
	return t?.size ? /* @__PURE__ */ O(D, { children: ie.map(([n, r, i]) => {
		let a = `${i}-${e}`;
		return t.has(a) ? /* @__PURE__ */ O(c, {
			type: n,
			position: r,
			id: a,
			...re
		}, a) : null;
	}) }) : null;
}
var Q = { erdTable: e(function({ data: e }) {
	let { table: t, names: n, keysOnly: r, focus: i, width: a, handles: o } = e, s = M(t, r), c = L(t, n), l = (t.columns || []).length - s.length;
	return /* @__PURE__ */ k("div", {
		className: `erd-table${n === "tech" ? "" : " erd-table--logical"}${i ? " is-focus" : ""}`,
		style: { width: a },
		title: t.comment || void 0,
		children: [/* @__PURE__ */ k("div", {
			className: "erd-table__head",
			children: [
				/* @__PURE__ */ O(Z, {
					index: "head",
					used: o
				}),
				/* @__PURE__ */ O("md-icon", {
					"aria-hidden": "true",
					children: "table"
				}),
				/* @__PURE__ */ k("span", {
					className: "erd-table__names",
					children: [/* @__PURE__ */ O("strong", {
						className: "erd-mono",
						title: t.qualified_name,
						children: t.name
					}), /* @__PURE__ */ O("small", { children: [c, `${t.database}.${t.schema}`].filter(Boolean).join(" · ") })]
				})
			]
		}), /* @__PURE__ */ k("div", {
			className: "erd-table__rows",
			role: "list",
			children: [
				s.map((e, t) => {
					let r = L(e, n), i = [
						`${e.name} ${e.type || ""}`.trim(),
						e.nullable ? "NULL" : "NOT NULL",
						r,
						e.comment
					].filter(Boolean).join(" · ");
					return /* @__PURE__ */ k("div", {
						role: "listitem",
						className: `erd-row${e.pk ? " is-pk" : ""}${e.fk ? " is-fk" : ""}`,
						title: i,
						children: [
							/* @__PURE__ */ O(Z, {
								index: t,
								used: o
							}),
							/* @__PURE__ */ k("span", {
								className: "erd-row__keys",
								"aria-label": [e.pk ? "khoá chính" : "", e.fk ? "khoá ngoại" : ""].filter(Boolean).join(", ") || void 0,
								children: [e.pk ? /* @__PURE__ */ O("md-icon", {
									class: "erd-row__pk",
									children: "key"
								}) : null, e.fk ? /* @__PURE__ */ O("md-icon", {
									class: "erd-row__fk",
									children: "link"
								}) : null]
							}),
							/* @__PURE__ */ O("span", {
								className: `erd-row__name erd-mono${e.nullable ? "" : " is-required"}`,
								children: e.name
							}),
							/* @__PURE__ */ O("span", {
								className: "erd-row__type",
								children: e.type
							}),
							n === "tech" ? null : /* @__PURE__ */ O("span", {
								className: "erd-row__logical",
								children: r
							})
						]
					}, e.id);
				}),
				s.length ? null : /* @__PURE__ */ O("div", {
					className: "erd-row erd-row--none",
					children: (t.columns || []).length ? "Không có cột khoá" : "Pack không có cột của bảng này"
				}),
				l > 0 ? /* @__PURE__ */ k("div", {
					className: "erd-row erd-row--none",
					children: [
						"+ ",
						l,
						" cột khác"
					]
				}) : null
			]
		})]
	});
}) };
function ae() {
	return /* @__PURE__ */ O("svg", {
		className: "erd-markers",
		"aria-hidden": "true",
		width: "0",
		height: "0",
		children: /* @__PURE__ */ k("defs", { children: [
			/* @__PURE__ */ O("marker", {
				id: "erd-one",
				viewBox: "0 0 20 20",
				refX: "20",
				refY: "10",
				markerWidth: "20",
				markerHeight: "20",
				markerUnits: "userSpaceOnUse",
				orient: "auto-start-reverse",
				children: /* @__PURE__ */ O("path", { d: "M11 3 V17 M15 3 V17" })
			}),
			/* @__PURE__ */ k("marker", {
				id: "erd-zero-one",
				viewBox: "0 0 20 20",
				refX: "20",
				refY: "10",
				markerWidth: "20",
				markerHeight: "20",
				markerUnits: "userSpaceOnUse",
				orient: "auto-start-reverse",
				children: [/* @__PURE__ */ O("circle", {
					cx: "7",
					cy: "10",
					r: "3.5"
				}), /* @__PURE__ */ O("path", { d: "M15 3 V17" })]
			}),
			/* @__PURE__ */ k("marker", {
				id: "erd-many",
				viewBox: "0 0 20 20",
				refX: "20",
				refY: "10",
				markerWidth: "20",
				markerHeight: "20",
				markerUnits: "userSpaceOnUse",
				orient: "auto-start-reverse",
				children: [/* @__PURE__ */ O("circle", {
					cx: "5",
					cy: "10",
					r: "3.5"
				}), /* @__PURE__ */ O("path", { d: "M10 10 L20 3 M10 10 L20 10 M10 10 L20 17" })]
			})
		] })
	});
}
function oe(e, { names: t, keysOnly: n }) {
	let r = t === "tech" ? j.tech : j.logical, i = F(e, {
		width: r,
		rowsOf: (e) => {
			let t = M(e, n).length;
			return Math.max(1, t) + ((e.columns || []).length > t && t ? 1 : 0);
		}
	}), a = new Map(e.tables.map((e) => [e.id, new Map(M(e, n).map((e, t) => [e.id, t]))])), o = [];
	for (let t of e.relations) {
		let e = i[t.from_table], n = i[t.to_table];
		if (!e || !n) continue;
		let r = I(e.x, n.x), s = U[t.delete_rule];
		t.from_column_ids.forEach((e, n) => {
			let i = a.get(t.from_table)?.get(e), c = a.get(t.to_table)?.get(t.to_column_ids[n]);
			o.push({
				id: `${t.id}#${n}`,
				source: t.from_table,
				target: t.to_table,
				type: "smoothstep",
				sourceHandle: `s-${r.source}-${i ?? "head"}`,
				targetHandle: `t-${r.target}-${c ?? "head"}`,
				label: n === 0 ? `${t.label}${s ? ` · ${s}` : ""}` : void 0,
				markerStart: t.cardinality === "one-to-one" ? "erd-zero-one" : "erd-many",
				markerEnd: t.optional ? "erd-zero-one" : "erd-one",
				className: `erd-edge${t.delete_rule === "CASCADE" ? " is-cascade" : ""}${t.source === "ddl" ? " is-ddl" : ""}`,
				labelBgPadding: [6, 3],
				labelBgBorderRadius: 4,
				pathOptions: {
					borderRadius: 10,
					offset: 24
				}
			});
		});
	}
	let s = /* @__PURE__ */ new Map();
	for (let e of o) s.has(e.source) || s.set(e.source, /* @__PURE__ */ new Set()), s.has(e.target) || s.set(e.target, /* @__PURE__ */ new Set()), s.get(e.source).add(e.sourceHandle), s.get(e.target).add(e.targetHandle);
	return {
		nodes: e.tables.map((a) => ({
			id: a.id,
			type: "erdTable",
			position: i[a.id] || {
				x: 0,
				y: 0
			},
			data: {
				table: a,
				names: t,
				keysOnly: n,
				width: r,
				focus: a.id === e.focus,
				handles: s.get(a.id)
			}
		})),
		edges: o
	};
}
var $ = {
	padding: .12,
	maxZoom: 1,
	duration: 250
};
function se({ signature: e }) {
	let t = p(), r = h();
	return n(() => {
		t && r.fitView($);
	}, [
		t,
		e,
		r
	]), null;
}
function ce({ model: e, names: t, keysOnly: r, onFocus: a, fitRef: c }) {
	let [l, d, p] = m([]), [h, g, _] = f([]), v = i(null);
	return n(() => {
		let n = oe(e, {
			names: t,
			keysOnly: r
		});
		d(n.nodes), g(n.edges);
	}, [
		e,
		t,
		r,
		d,
		g
	]), c.current = () => v.current?.fitView($), /* @__PURE__ */ k("div", {
		className: "erd-canvas",
		children: [/* @__PURE__ */ O(ae, {}), /* @__PURE__ */ k(u, {
			nodes: l,
			edges: h,
			nodeTypes: Q,
			onNodesChange: p,
			onEdgesChange: _,
			onInit: (e) => {
				v.current = e;
			},
			onNodeClick: (e, t) => a(t.id),
			nodesConnectable: !1,
			minZoom: .1,
			maxZoom: 1.6,
			onlyRenderVisibleElements: !0,
			proOptions: { hideAttribution: !0 },
			children: [
				/* @__PURE__ */ O(o, {
					gap: 20,
					size: 1.2
				}),
				/* @__PURE__ */ O(s, { showInteractive: !1 }),
				/* @__PURE__ */ O(se, { signature: `${e.scope}|${e.depth}|${t}|${r}` })
			]
		})]
	});
}
function le({ api: e, table: t, pack: r }) {
	let [i, o] = a({
		data: null,
		error: ""
	});
	n(() => {
		let n = !0;
		return o({
			data: null,
			error: ""
		}), e.get("/usage", {
			table: t,
			pack: r
		}).then((e) => {
			n && o({
				data: e,
				error: ""
			});
		}, (e) => {
			n && o({
				data: null,
				error: e.message
			});
		}), () => {
			n = !1;
		};
	}, [
		e,
		t,
		r
	]);
	let { data: s, error: c } = i;
	return /* @__PURE__ */ O("aside", {
		className: "md-card md-card--outlined erd-side",
		"aria-label": "Tính năng dùng bảng",
		children: /* @__PURE__ */ k("div", {
			className: "md-card__body",
			children: [
				/* @__PURE__ */ O("h2", {
					className: "md-card__title",
					children: "Ai dùng bảng này"
				}),
				c ? /* @__PURE__ */ O(S, { children: c }) : null,
				!s && !c ? /* @__PURE__ */ O(w, { children: "Đang tìm tính năng…" }) : null,
				s ? /* @__PURE__ */ k(D, { children: [
					/* @__PURE__ */ k("p", {
						className: "md-card__subtitle",
						children: [/* @__PURE__ */ O("span", {
							className: "erd-mono",
							children: s.table?.qualified_name || t
						}), s.ops ? /* @__PURE__ */ k(D, { children: [" · ", /* @__PURE__ */ O("span", {
							title: q(s.ops),
							children: s.ops
						})] }) : null]
					}),
					s.features?.length ? null : /* @__PURE__ */ O("p", {
						className: "md-muted md-body-small",
						children: "Không có tính năng nào trong Code map đọc hay ghi bảng này."
					}),
					/* @__PURE__ */ O("ul", {
						className: "erd-usage",
						children: (s.features || []).map((e) => /* @__PURE__ */ O("li", { children: /* @__PURE__ */ k("a", {
							href: e.url,
							title: "Mở tính năng trong Code map",
							children: [/* @__PURE__ */ k("span", { children: [/* @__PURE__ */ O("b", { children: e.name }), /* @__PURE__ */ O("small", { children: G[e.kind] || e.kind })] }), /* @__PURE__ */ O(g, {
								tone: /[CUD]/.test(e.ops || "") ? "warning" : void 0,
								children: e.ops
							})]
						}) }, e.id))
					}),
					s.truncated || s.total_features > (s.features || []).length ? /* @__PURE__ */ k("p", {
						className: "md-muted md-body-small",
						children: [
							"Hiện ",
							(s.features || []).length,
							"/",
							s.total_features,
							" tính năng."
						]
					}) : null,
					s.accessors?.length ? /* @__PURE__ */ k(D, { children: [
						/* @__PURE__ */ O("h3", {
							className: "md-title-small",
							children: "Code đọc / ghi trực tiếp"
						}),
						/* @__PURE__ */ O("ul", {
							className: "erd-usage",
							children: s.accessors.slice(0, 30).map((e) => /* @__PURE__ */ O("li", { children: /* @__PURE__ */ k("span", {
								className: "erd-usage__row",
								children: [/* @__PURE__ */ k("span", { children: [/* @__PURE__ */ O("b", {
									className: "erd-mono",
									children: e.name
								}), /* @__PURE__ */ O("small", { children: e.node_type })] }), /* @__PURE__ */ O("span", {
									className: "erd-mono",
									title: q(e.ops),
									children: e.ops
								})]
							}) }, e.id))
						}),
						s.total_accessors > 30 ? /* @__PURE__ */ k("p", {
							className: "md-muted md-body-small",
							children: [
								"+ ",
								s.total_accessors - 30,
								" mục khác"
							]
						}) : null
					] }) : null
				] }) : null
			]
		})
	});
}
var ue = {
	mermaid: "Mermaid",
	dbml: "DBML"
}, de = {
	mermaid: "Sơ đồ erDiagram của Mermaid: dán vào Markdown của GitLab, GitHub, Confluence hoặc VS Code (có extension Mermaid) để xem.",
	dbml: "DBML cho dbdiagram.io: dán vào trình soạn của dbdiagram (hoặc dùng @dbml/cli) để xem và chỉnh sơ đồ."
};
function fe({ api: e, format: t, request: r, scope: o, onClose: s }) {
	let [c, l] = a(""), [u, d] = a(B(o, t)), [f, p] = a(""), m = i(null);
	return n(() => {
		let n = !0;
		return e.get("/text", {
			...r,
			format: t
		}).then((e) => {
			n && (l(e.text || ""), e.filename && d(e.filename));
		}, (e) => {
			n && p(e.message);
		}), () => {
			n = !1;
		};
	}, [
		e,
		t,
		r
	]), /* @__PURE__ */ k(x, {
		headline: `Xuất ${ue[t]}`,
		icon: "ios_share",
		onClose: s,
		actions: (e) => /* @__PURE__ */ k(D, { children: [
			/* @__PURE__ */ O(b, {
				onClick: e,
				children: "Đóng"
			}),
			/* @__PURE__ */ O(b, {
				variant: "outlined",
				icon: "content_copy",
				disabled: !c,
				onClick: async () => K(await J(c, m.current) ? "Đã sao chép" : "Đã chọn nội dung, nhấn Ctrl+C để sao chép"),
				children: "Sao chép"
			}),
			/* @__PURE__ */ O(b, {
				variant: "filled",
				icon: "download",
				disabled: !c,
				onClick: () => {
					Y(u, c), K(`Đã tải ${u}`);
				},
				children: "Tải file"
			})
		] }),
		wide: !0,
		children: [
			/* @__PURE__ */ O("p", {
				className: "md-muted",
				children: de[t]
			}),
			f ? /* @__PURE__ */ O(S, { children: f }) : null,
			/* @__PURE__ */ k("label", {
				className: "md-stack",
				children: [/* @__PURE__ */ k("span", {
					className: "md-body-small md-muted",
					children: ["Xem trước · ", u]
				}), /* @__PURE__ */ O("textarea", {
					ref: m,
					className: "erd-code",
					rows: 16,
					readOnly: !0,
					value: c || (f ? "" : "Đang tạo…"),
					spellCheck: !1
				})]
			})
		]
	});
}
function pe({ api: e }) {
	y("ERD"), _("wide");
	let [o, s] = v(), c = R(o), { table: l, schema: u, system: d, tables: f, depth: p, names: m, cols: h, pack: g } = c, [x, w] = a(null), [A, j] = a(null), [M, N] = a({
		loading: !1,
		error: ""
	}), [P, F] = a(null), I = i(null), L = !!(l || u || d || f), B = r(() => {
		let e = {
			table: l,
			schema: u,
			system: d,
			tables: f,
			pack: g
		};
		return l && (e.depth = p), h === "keys" && (e.keys = "1"), Object.fromEntries(Object.entries(e).filter(([, e]) => e));
	}, [
		l,
		u,
		d,
		f,
		p,
		h,
		g
	]);
	n(() => {
		let t = !0;
		return e.get("/tables", {
			q: "",
			pack: g,
			limit: 1
		}).then((e) => {
			t && w(e);
		}, (e) => {
			t && w({
				schemas: [],
				packs: [],
				error: e.message
			});
		}), () => {
			t = !1;
		};
	}, [e, g]), n(() => {
		if (!L) {
			j(null), N({
				loading: !1,
				error: ""
			});
			return;
		}
		let t = !0;
		N({
			loading: !0,
			error: ""
		});
		let { keys: n, ...r } = B;
		return e.get("/model", r).then((e) => {
			t && (j(e), N({
				loading: !1,
				error: ""
			}));
		}, (e) => {
			t && (j(null), N({
				loading: !1,
				error: e.message
			}));
		}), () => {
			t = !1;
		};
	}, [
		e,
		B,
		L
	]);
	let U = t((e) => s(z({
		...c,
		...e
	})), [c, s]), W = (e) => {
		e && e !== A?.focus && U({
			table: e,
			schema: "",
			system: "",
			tables: ""
		});
	}, G = A && !A.has_fk_data || !L && x && x.has_fk_data === !1, K = A ? `${A.tables.length} bảng · ${A.relations.length} khoá ngoại` : "", q = x?.schemas || [], J = x?.packs || [], Y = [
		{
			key: "schema",
			label: "Schema",
			value: u,
			defaultValue: "",
			options: [["", l ? "Theo bảng đang chọn" : "Không chọn"], ...q.map((e) => [e.id, `${e.id} · ${e.tables} bảng`])]
		},
		{
			key: "depth",
			label: "Độ sâu quanh bảng",
			value: p,
			defaultValue: "1",
			options: H
		},
		{
			key: "names",
			label: "Tên hiển thị",
			value: m,
			defaultValue: "ja",
			options: V
		},
		{
			key: "cols",
			label: "Cột",
			value: h,
			defaultValue: "all",
			options: ne
		}
	];
	return x?.error && !L ? /* @__PURE__ */ O("div", {
		className: "erd-page",
		children: /* @__PURE__ */ O(S, { children: x.error })
	}) : /* @__PURE__ */ k("div", {
		className: "erd-page",
		children: [
			/* @__PURE__ */ k("div", {
				className: "erd-bar",
				children: [/* @__PURE__ */ O(X, {
					api: e,
					schema: u,
					pack: g,
					onPick: (e) => U({
						table: e,
						schema: "",
						system: "",
						tables: ""
					})
				}), /* @__PURE__ */ k("div", {
					className: "erd-bar__actions",
					children: [
						J.length > 1 ? /* @__PURE__ */ O(E, {
							label: "Pack",
							value: g || x?.pack || J[0].id,
							options: J.map((e) => [e.id, e.title || e.id]),
							onChange: (e) => U({ pack: e })
						}) : null,
						/* @__PURE__ */ O(b, {
							variant: "tonal",
							icon: "account_tree",
							disabled: !A,
							onClick: () => F("mermaid"),
							children: "Xuất Mermaid"
						}),
						/* @__PURE__ */ O(b, {
							variant: "tonal",
							icon: "database",
							disabled: !A,
							onClick: () => F("dbml"),
							children: "Xuất DBML"
						}),
						/* @__PURE__ */ O(te, {
							icon: "fit_screen",
							label: "Vừa khung",
							disabled: !A,
							onClick: () => I.current?.()
						})
					]
				})]
			}),
			/* @__PURE__ */ O(C, {
				filters: Y,
				summary: K,
				panelId: "erd-filters",
				onApply: (e) => U(e.schema && e.schema !== u ? {
					...e,
					table: "",
					system: "",
					tables: ""
				} : e)
			}, `${l}|${u}|${p}|${m}|${h}|${q.length}`),
			M.loading ? /* @__PURE__ */ O(T, {}) : null,
			/* @__PURE__ */ k("div", {
				className: "erd-notes",
				children: [
					M.error ? /* @__PURE__ */ O(S, { children: M.error }) : null,
					G ? /* @__PURE__ */ k("div", {
						className: "md-banner",
						role: "status",
						children: [/* @__PURE__ */ O("md-icon", { children: "info" }), /* @__PURE__ */ k("div", {
							className: "md-banner__text",
							children: [/* @__PURE__ */ O("b", { children: "Pack chưa có dữ liệu khoá ngoại: cần extract lại bằng code-map mới." }), " Pack này được extract bằng bản code-map cũ nên chỉ có bảng và cột; sơ đồ chưa vẽ được quan hệ giữa các bảng."]
						})]
					}) : null,
					A?.truncated ? /* @__PURE__ */ k("div", {
						className: "md-banner",
						role: "status",
						children: [/* @__PURE__ */ O("md-icon", { children: "filter_alt" }), /* @__PURE__ */ k("div", {
							className: "md-banner__text",
							children: [
								"Chỉ hiện ",
								A.limit,
								" bảng; ",
								A.omitted,
								" bảng khác bị ẩn. Chọn một bảng và độ sâu 1 để thu hẹp."
							]
						})]
					}) : null,
					A?.missing?.length ? /* @__PURE__ */ k("p", {
						className: "md-muted md-body-small",
						children: ["Không tìm thấy trong pack: ", A.missing.join(", ")]
					}) : null,
					A?.outside_tables ? /* @__PURE__ */ k("p", {
						className: "md-muted md-body-small",
						children: [
							A.outside_tables,
							" bảng khác có khoá ngoại tới các bảng này",
							A.outside?.length ? /* @__PURE__ */ k(D, { children: [" · ", /* @__PURE__ */ O("button", {
								type: "button",
								className: "erd-link",
								onClick: () => U({ tables: [...A.tables.map((e) => e.qualified_name), ...A.outside.map((e) => e.qualified_name)].join(",") }),
								children: "thêm vào sơ đồ"
							})] }) : null
						]
					}) : A?.outside_relations ? /* @__PURE__ */ k("p", {
						className: "md-muted md-body-small",
						children: [A.outside_relations, " khoá ngoại nối tới bảng ngoài sơ đồ này (bấm vào một bảng để xem quanh bảng đó)."]
					}) : null
				]
			}),
			/* @__PURE__ */ k("div", {
				className: `erd-stage${A?.focus ? "" : " erd-stage--full"}`,
				children: [A ? /* @__PURE__ */ O(ce, {
					model: A,
					names: m,
					keysOnly: h === "keys",
					onFocus: W,
					fitRef: I
				}) : L ? null : /* @__PURE__ */ k("div", {
					className: "erd-empty",
					children: [/* @__PURE__ */ O(ee, {
						icon: "schema",
						title: "Chọn một bảng để xem ERD",
						children: "Gõ tên bảng (tên kỹ thuật hoặc tên logic tiếng Nhật / tiếng Anh) vào ô phía trên. Sơ đồ hiện các bảng nối với bảng đó qua khoá ngoại; bấm vào một bảng trong sơ đồ để chuyển tâm sang bảng đó."
					}), q.length ? /* @__PURE__ */ k("div", {
						className: "erd-schemas",
						children: [/* @__PURE__ */ O("span", {
							className: "md-body-small md-muted",
							children: "Hoặc mở cả một schema"
						}), /* @__PURE__ */ O("md-chip-set", { children: q.map((e) => /* @__PURE__ */ O("md-assist-chip", {
							label: `${e.id} · ${e.tables} bảng`,
							onClick: () => U({
								table: "",
								schema: e.id,
								system: "",
								tables: ""
							}),
							children: /* @__PURE__ */ O("md-icon", {
								slot: "icon",
								children: "folder_data"
							})
						}, e.id)) })]
					}) : null]
				}), A?.focus ? /* @__PURE__ */ O(le, {
					api: e,
					table: A.focus,
					pack: g
				}) : null]
			}),
			P && A ? /* @__PURE__ */ O(fe, {
				api: e,
				format: P,
				request: B,
				scope: A.scope,
				onClose: () => F(null)
			}) : null
		]
	});
}
function me(e) {
	return /* @__PURE__ */ O(d, { children: /* @__PURE__ */ O(pe, { ...e }) });
}
export { me as default };
