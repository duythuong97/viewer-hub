## ERD

Sơ đồ quan hệ bảng (ERD) của **cả cơ sở dữ liệu** trong pack Code map: bảng nào trỏ tới bảng nào qua **khoá ngoại**,
bằng cột nào. Dữ liệu lấy từ Code map (chỉ đọc); cần ít nhất một pack Code map đang bật (**liên hệ admin** nếu chưa có).
Để xem riêng các bảng một tính năng dùng, mở tính năng đó trong Code map, tab **Dữ liệu**.

1. Gõ tên bảng vào ô **Chọn bảng** (tên kỹ thuật như `ORDER_LINE`, hoặc tên logic như 注文明細 / Order Line), hoặc bấm
   một schema để xem cả schema.
2. Đọc sơ đồ:
   - Mỗi hộp là một bảng: tên, tên logic, cột và kiểu dữ liệu. [icon:key] = khoá chính, [icon:link] = khoá ngoại.
   - **Bảng con** (có khoá ngoại) bên trái, **bảng được tham chiếu** bên phải; nhãn `cột → cột` (khoá nhiều cột:
     `(a, b) → (c, d)`). Đầu "chân chim" = phía *nhiều*, hai gạch = phía *một*; **xoá dây chuyền** = `ON DELETE CASCADE`.
3. Bấm một bảng để lấy nó làm tâm. Khung bên phải: **Ai dùng bảng này** (tính năng, API, job đọc / ghi, chữ CRUD);
   bấm một tính năng để mở nó trong Code map. [icon:fit_screen] **Vừa khung** đưa cả sơ đồ vào màn hình.
4. **Bộ lọc**: schema; độ sâu **1 bước** hay **2 bước** quanh bảng; tên hiển thị 日本語 / English / tên kỹ thuật;
   **Chỉ cột khoá** cho sơ đồ gọn. Mỗi sơ đồ tối đa 80 bảng.
5. **Xuất Mermaid** / **Xuất DBML**: xem trước, **Sao chép** hoặc **Tải file**. Mermaid dán được vào Markdown (GitLab,
   GitHub, Confluence…); DBML dán vào dbdiagram.io.
6. Nhiều pack Code map: chọn pack ở ô **Pack**.

Thấy *"Chưa có dữ liệu khoá ngoại"*: pack hiện tại chưa có thông tin khoá ngoại, **liên hệ admin**.

### Tool cho AI

| Tool | AI dùng để |
|---|---|
| `erd_diagram` | Sơ đồ quan hệ bảng theo khoá ngoại quanh một bảng (độ sâu 1–2), của cả schema / hệ thống hoặc một danh sách bảng: cột, kiểu, khoá, tên logic, `ON DELETE`; trả Mermaid, DBML hoặc JSON (thay `codemap_erd` của Code map) |
