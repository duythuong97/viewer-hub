import { useState as e } from "/static/dist/sdk/react.js";
import { Button as t, Empty as n, ErrorBanner as r, Loading as i, TextField as a } from "/static/dist/sdk/md.js";
import { Badge as o, useAction as s, useAddon as c, useLoad as l } from "/static/dist/sdk/ui.js";
import { jsx as u, jsxs as d } from "/static/dist/sdk/jsx-runtime.js";
// web/index.jsx
function f({ connection: n, api: r, onChange: i }) {
	let [c, l] = e(""), [f, p] = s(), m = `/connections/${encodeURIComponent(n.name)}`, h = () => f(() => r.post(`${m}/test`, c ? { password: c } : {})).then((e) => {
		if (!e) return;
		l(""), i();
		let t = e.connection?.test;
		window.md?.snackbar(t?.ok ? "Kết nối được" : "Không kết nối được");
	}), g = () => f(() => r.post(`${m}/forget`, {}), "Đã quên mật khẩu").then(i), _ = n.test;
	return /* @__PURE__ */ u("section", {
		className: "md-card md-card--outlined",
		children: /* @__PURE__ */ d("div", {
			className: "md-card__body md-stack",
			children: [
				/* @__PURE__ */ d("div", {
					className: "md-row",
					children: [
						/* @__PURE__ */ d("div", { children: [/* @__PURE__ */ u("div", {
							className: "md-card__title",
							children: n.name
						}), /* @__PURE__ */ u("div", {
							className: "md-card__subtitle",
							children: n.description || "Không có mô tả"
						})] }),
						/* @__PURE__ */ u("div", { className: "md-spacer" }),
						n.ready ? /* @__PURE__ */ u(o, {
							tone: "success",
							icon: "check_circle",
							children: "Sẵn sàng"
						}) : /* @__PURE__ */ u(o, {
							tone: "warning",
							icon: "key",
							children: "Chưa nhập mật khẩu"
						})
					]
				}),
				/* @__PURE__ */ d("div", {
					className: "md-body-small md-muted",
					children: [
						n.user,
						"@",
						n.connectString,
						" · schema ",
						n.schema
					]
				}),
				/* @__PURE__ */ d("form", {
					className: "md-row",
					onSubmit: (e) => {
						e.preventDefault(), h();
					},
					children: [
						/* @__PURE__ */ u(a, {
							label: n.ready ? "Mật khẩu (để trống: dùng mật khẩu đã nhập)" : "Mật khẩu",
							type: "password",
							value: c,
							onChange: l,
							autoComplete: "off"
						}),
						/* @__PURE__ */ u(t, {
							variant: "filled",
							icon: "network_check",
							type: "submit",
							disabled: p || !c && !n.ready,
							children: "Kiểm tra kết nối"
						}),
						n.ready ? /* @__PURE__ */ u(t, {
							variant: "text",
							icon: "key_off",
							onClick: g,
							disabled: p,
							children: "Quên mật khẩu"
						}) : null
					]
				}),
				_ ? /* @__PURE__ */ d("div", {
					className: "md-row",
					children: [
						/* @__PURE__ */ u(o, {
							tone: _.ok ? "success" : "error",
							icon: _.ok ? "check" : "error",
							children: _.ok ? "OK" : "Lỗi"
						}),
						/* @__PURE__ */ u("span", {
							className: "md-body-small",
							children: _.message
						}),
						/* @__PURE__ */ u("span", {
							className: "md-body-small md-muted",
							children: new Date(_.at).toLocaleTimeString()
						})
					]
				}) : null
			]
		})
	});
}
function p({ module: e, api: a, addon: o }) {
	let { openSettings: s } = c(), p = JSON.stringify(o?.values?.connections ?? null), { data: m, error: h, reload: g } = l(() => a.get("/connections"), [p]);
	return /* @__PURE__ */ d("div", {
		className: "md-stack",
		children: [
			/* @__PURE__ */ u("p", {
				className: "md-body-small md-muted",
				children: "Mật khẩu chỉ giữ trong bộ nhớ của addon, không lưu xuống đĩa: mỗi lần mở lại Viewer Hub phải nhập lại. AI chỉ chạy được câu SELECT, tối đa 50 dòng."
			}),
			h ? /* @__PURE__ */ u(r, { children: h.message }) : null,
			!m && !h ? /* @__PURE__ */ u(i, {}) : null,
			m?.errors?.length ? /* @__PURE__ */ u(r, { children: `Một số dòng cài đặt bị bỏ qua: ${m.errors.join("; ")}` }) : null,
			m && !m.connections.length ? /* @__PURE__ */ u(n, {
				icon: "database",
				title: "Chưa có kết nối Oracle",
				children: /* @__PURE__ */ u(t, {
					variant: "filled",
					icon: "add",
					onClick: () => s("connections"),
					children: "Thêm kết nối"
				})
			}) : null,
			m?.connections.length ? /* @__PURE__ */ d("div", {
				className: "md-row",
				children: [/* @__PURE__ */ u("span", { className: "md-spacer" }), /* @__PURE__ */ u(t, {
					icon: "edit",
					onClick: () => s("connections"),
					children: "Sửa danh sách kết nối"
				})]
			}) : null,
			m?.connections.map((e) => /* @__PURE__ */ u(f, {
				connection: e,
				api: a,
				onChange: g
			}, e.name))
		]
	});
}
export { p as default };
