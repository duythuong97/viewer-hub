## MCP Bridge

MCP Bridge chạy trên máy bạn và đưa các MCP (của Viewer Hub và MCP khác bạn thêm) cho **Copilot Studio** dùng.

- Hướng dẫn thiết lập nằm trong hộp **Cài đặt** (biểu tượng bánh răng): trang 1 chọn thư mục Box, rồi **Lưu và tiếp** qua các trang kiểm tra Box, chọn tool, cấu hình agent trong Copilot Studio (thêm tool Box, dán hướng dẫn đã điền sẵn token) và thử. Không cần dùng dòng lệnh hay Power Automate.
- Viewer Hub **tự chạy bridge khi mở** (tắt bằng **Tự chạy khi mở Viewer Hub**). Trên trang **MCP Bridge**: [icon:play_arrow] chạy, [icon:restart_alt] khởi động lại, [icon:stop_circle] dừng (có hỏi lại); [icon:receipt_long] **Nhật ký** xem toàn bộ log của bridge (mật khẩu / token đã che).
- **Thư mục Box**: nhập ở mục *Cài đặt* rồi bấm **Lưu**; bridge đang chạy sẽ tự khởi động lại với thư mục mới.
- **Đăng ký MCP của Viewer Hub**: khi bridge chạy, mọi MCP ở mục *Dùng với AI* được thêm vào bridge (tên `viewer-…`, chỉ tool đọc). Tắt công tắc này nếu không muốn.
- Tab **Server**: bật / tắt từng server, [icon:sync] đọc lại danh sách tool, [icon:terminal] log của server, [icon:delete] xoá server.
- Tab **Tool**: chọn quyền từng tool: *Tắt* (AI không thấy), *Cần duyệt*, *Cho phép*. Tool mới (kể cả của Viewer Hub) luôn bắt đầu ở *Tắt*: bạn tự bật, từng tool hoặc **Cho phép tất cả** / **Tắt tất cả** (áp dụng cho các tool đang hiện theo bộ lọc, có hỏi lại).
- Tab **Duyệt**: request gọi tool cần duyệt chờ ở đây; bấm **Duyệt** hoặc **Từ chối**.
- Tắt Viewer Hub thì bridge vẫn chạy; nhưng tool của Viewer Hub chỉ trả lời khi Viewer Hub đang mở.
