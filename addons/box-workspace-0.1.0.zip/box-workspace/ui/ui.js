import { useCallback as e, useEffect as t, useMemo as n, useState as r } from "/static/dist/sdk/react.js";
import { Button as i, Empty as a, ErrorBanner as o, Icon as s, IconButton as c, Loading as l, Segmented as u, TextField as d } from "/static/dist/sdk/md.js";
import { Badge as f, useAction as p, useTitle as m } from "/static/dist/sdk/ui.js";
import { Fragment as h, jsx as g, jsxs as _ } from "/static/dist/sdk/jsx-runtime.js";
// web/index.jsx
function v(e) {
	return e == null ? "" : e < 1024 ? `${e} B` : e < 1048576 ? `${(e / 1024).toFixed(1)} KB` : `${(e / 1048576).toFixed(2)} MB`;
}
function y(e) {
	return e ? (/* @__PURE__ */ new Date(e * 1e3)).toLocaleString("vi-VN", {
		hour: "2-digit",
		minute: "2-digit",
		day: "2-digit",
		month: "2-digit",
		year: "numeric"
	}) : "";
}
function b({ icon: e, name: t, className: n, style: r }) {
	let i = e || t;
	return /* @__PURE__ */ g(s, {
		icon: i,
		name: i,
		className: n,
		style: r,
		children: i
	});
}
var x = {
	markdown: {
		icon: "article",
		label: "Tài liệu Markdown",
		className: "box-icon-markdown"
	},
	text: {
		icon: "text_snippet",
		label: "Tệp văn bản",
		className: "box-icon-code"
	},
	code: {
		icon: "code",
		label: "Mã nguồn / Cấu hình",
		className: "box-icon-code"
	},
	excel: {
		icon: "table_chart",
		label: "Bảng tính Microsoft Excel",
		className: "box-icon-excel"
	},
	word: {
		icon: "description",
		label: "Tài liệu Microsoft Word",
		className: "box-icon-word"
	},
	powerpoint: {
		icon: "slideshow",
		label: "Bản trình bày PowerPoint",
		className: "box-icon-powerpoint"
	},
	pdf: {
		icon: "picture_as_pdf",
		label: "Tài liệu PDF",
		className: "box-icon-pdf"
	},
	archive: {
		icon: "folder_zip",
		label: "Tệp nén",
		className: "box-icon-other"
	},
	image: {
		icon: "image",
		label: "Hình ảnh",
		className: "box-icon-image"
	},
	other: {
		icon: "draft",
		label: "Tệp tin",
		className: "box-icon-other"
	}
};
function S(e) {
	return e ? e.split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*|\[[^\]]+\]\([^)]+\))/g).map((e, t) => {
		if (!e) return null;
		if (e.startsWith("`") && e.endsWith("`")) return /* @__PURE__ */ g("code", { children: e.slice(1, -1) }, t);
		if (e.startsWith("**") && e.endsWith("**")) return /* @__PURE__ */ g("strong", { children: e.slice(2, -2) }, t);
		if (e.startsWith("*") && e.endsWith("*")) return /* @__PURE__ */ g("em", { children: e.slice(1, -1) }, t);
		let n = e.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
		return n ? /* @__PURE__ */ g("a", {
			href: n[2],
			target: "_blank",
			rel: "noopener noreferrer",
			children: n[1]
		}, t) : e;
	}) : null;
}
function C({ content: e }) {
	let t = n(() => {
		if (!e) return [];
		let t = e.split("\n"), n = [], r = !1, i = [], a = "", o = [], s = [], c = null, l = () => {
			s.length > 0 && (n.push({
				type: c === "ol" ? "ol" : "ul",
				items: s
			}), s = [], c = null);
		}, u = () => {
			o.length > 0 && (n.push({
				type: "table",
				rows: o
			}), o = []);
		};
		for (let e = 0; e < t.length; e++) {
			let d = t[e];
			if (d.trim().startsWith("```")) {
				r ? (n.push({
					type: "code",
					code: i.join("\n"),
					lang: a
				}), i = [], a = "", r = !1) : (l(), u(), r = !0, a = d.trim().slice(3).trim());
				continue;
			}
			if (r) {
				i.push(d);
				continue;
			}
			if (d.trim().startsWith("|") && d.trim().endsWith("|")) {
				if (l(), /^\|[\s\-:|]+\|$/.test(d.trim())) continue;
				let e = d.trim().slice(1, -1).split("|").map((e) => e.trim());
				o.push(e);
				continue;
			}
			u();
			let f = d.match(/^(\s*)[-*+]\s+(.*)$/);
			if (f) {
				c !== "ul" && l(), c = "ul", s.push(f[2]);
				continue;
			}
			let p = d.match(/^(\s*)\d+\.\s+(.*)$/);
			if (p) {
				c !== "ol" && l(), c = "ol", s.push(p[2]);
				continue;
			}
			l();
			let m = d.trim();
			m && (m.startsWith("### ") ? n.push({
				type: "h3",
				text: m.slice(4)
			}) : m.startsWith("## ") ? n.push({
				type: "h2",
				text: m.slice(3)
			}) : m.startsWith("# ") ? n.push({
				type: "h1",
				text: m.slice(2)
			}) : m.startsWith("#### ") ? n.push({
				type: "h4",
				text: m.slice(5)
			}) : m.startsWith("> ") ? n.push({
				type: "blockquote",
				text: m.slice(2)
			}) : m === "---" || m === "***" ? n.push({ type: "hr" }) : n.push({
				type: "p",
				text: d
			}));
		}
		return r && n.push({
			type: "code",
			code: i.join("\n"),
			lang: a
		}), l(), u(), n;
	}, [e]);
	return /* @__PURE__ */ g("div", {
		className: "box-md-preview",
		children: t.map((e, t) => {
			switch (e.type) {
				case "h1": return /* @__PURE__ */ g("h1", { children: S(e.text) }, t);
				case "h2": return /* @__PURE__ */ g("h2", { children: S(e.text) }, t);
				case "h3": return /* @__PURE__ */ g("h3", { children: S(e.text) }, t);
				case "h4": return /* @__PURE__ */ g("h4", { children: S(e.text) }, t);
				case "p": return /* @__PURE__ */ g("p", { children: S(e.text) }, t);
				case "blockquote": return /* @__PURE__ */ g("blockquote", { children: S(e.text) }, t);
				case "hr": return /* @__PURE__ */ g("hr", {}, t);
				case "code": return /* @__PURE__ */ g("pre", { children: /* @__PURE__ */ g("code", { children: e.code }) }, t);
				case "ul": return /* @__PURE__ */ g("ul", { children: e.items.map((e, t) => /* @__PURE__ */ g("li", { children: S(e) }, t)) }, t);
				case "ol": return /* @__PURE__ */ g("ol", { children: e.items.map((e, t) => /* @__PURE__ */ g("li", { children: S(e) }, t)) }, t);
				case "table": {
					if (!e.rows.length) return null;
					let [n, ...r] = e.rows;
					return /* @__PURE__ */ _("table", { children: [/* @__PURE__ */ g("thead", { children: /* @__PURE__ */ g("tr", { children: n.map((e, t) => /* @__PURE__ */ g("th", { children: S(e) }, t)) }) }), /* @__PURE__ */ g("tbody", { children: r.map((e, t) => /* @__PURE__ */ g("tr", { children: e.map((e, t) => /* @__PURE__ */ g("td", { children: S(e) }, t)) }, t)) })] }, t);
				}
				default: return null;
			}
		})
	});
}
function w({ item: e, depth: t = 0, selectedPath: n, onSelect: r, openDirs: i, onToggleDir: a, onOpenExternal: o, now: s }) {
	let c = n === e.path, l = e.type === "dir", u = i.has(e.path), d = !l && e.mtime && s - e.mtime * 1e3 < 3e5, p = l ? null : x[e.category] || x.other, m = (t) => {
		t.stopPropagation(), l ? a(e.path) : r(e);
	}, h = (t) => {
		t.stopPropagation(), !l && !e.isText && o(e.path);
	}, y = u ? "folder_open" : "folder", S = p ? p.icon : "draft";
	return /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ _("div", {
		className: `box-tree-item ${c ? "box-tree-item--selected" : ""}`,
		style: { paddingLeft: `${6 + t * 14}px` },
		onClick: m,
		onDoubleClick: h,
		title: l ? e.name : `${e.name} (${v(e.size)})`,
		children: [
			l ? /* @__PURE__ */ g("span", {
				className: "box-tree-item__toggle",
				onClick: (t) => {
					t.stopPropagation(), a(e.path);
				},
				children: /* @__PURE__ */ g(b, { icon: u ? "expand_more" : "chevron_right" })
			}) : /* @__PURE__ */ g("span", { className: "box-tree-item__toggle" }),
			/* @__PURE__ */ g(b, {
				icon: l ? y : S,
				className: l ? "box-icon-folder" : p?.className
			}),
			/* @__PURE__ */ g("span", {
				className: `box-tree-item__name ${l ? "box-tree-item__name--dir" : "box-tree-item__name--file"}`,
				children: e.name
			}),
			d && /* @__PURE__ */ g("span", {
				className: "box-tree-item__badge",
				children: /* @__PURE__ */ g(f, {
					tone: "success",
					children: "Mới"
				})
			})
		]
	}), l && u && e.children && /* @__PURE__ */ g("div", { children: e.children.map((e) => /* @__PURE__ */ g(w, {
		item: e,
		depth: t + 1,
		selectedPath: n,
		onSelect: r,
		openDirs: i,
		onToggleDir: a,
		onOpenExternal: o,
		now: s
	}, e.path)) })] });
}
function T({ api: s, addon: f }) {
	m("Box Workspace");
	let [S, T] = p(), [E, ee] = r(null), [D, O] = r(null), [k, A] = r(!0), [j, M] = r(null), [N, P] = r(""), [F, I] = r(/* @__PURE__ */ new Set()), [L, R] = r(null), [z, B] = r(null), [te, V] = r(!1), [H, U] = r(null), [W, G] = r("preview"), [K, q] = r(Date.now()), J = e(async (e = !1) => {
		try {
			e || M(null);
			let t = await s.get("/workspace");
			if (ee(t), !t.configured || !t.exists) {
				A(!1);
				return;
			}
			let n = await s.get("/tree");
			O(n), q(Date.now()), I((e) => {
				if (e.size === 0 && n.items) {
					let e = /* @__PURE__ */ new Set();
					return n.items.forEach((t) => {
						t.type === "dir" && e.add(t.path);
					}), e;
				}
				return e;
			});
		} catch (t) {
			e || M(t.message || "Lỗi tải cây thư mục");
		} finally {
			e || A(!1);
		}
	}, [s]);
	t(() => {
		J();
	}, [J]), t(() => {
		if (!E?.configured || !E?.exists) return;
		let e = !0, t = Date.now() / 1e3;
		async function n() {
			for (; e;) try {
				let n = await s.get("/wait-change", { last_time: t });
				if (!e) break;
				n?.changed && (t = n.changeTime || Date.now() / 1e3, await J(!0));
			} catch {
				if (!e) break;
				await new Promise((e) => setTimeout(e, 2e3));
			}
		}
		return n(), () => {
			e = !1;
		};
	}, [
		E?.configured,
		E?.exists,
		J,
		s
	]);
	let Y = e(async (e) => {
		V(!0), U(null);
		try {
			let t = await s.get("/file", { path: e });
			B(t), !t.isMarkdown && t.isText ? G("raw") : t.isMarkdown && G("preview");
		} catch (e) {
			U(e.message || "Không thể đọc tệp");
		} finally {
			V(!1);
		}
	}, [s]), X = (e) => {
		R(e), Y(e.path);
	}, Z = (e) => {
		I((t) => {
			let n = new Set(t);
			return n.has(e) ? n.delete(e) : n.add(e), n;
		});
	}, Q = (e) => {
		S(() => s.post("/open-external", { path: e }), "Đã mở ứng dụng");
	}, $ = n(() => {
		if (!D?.items) return [];
		if (!N.trim()) return D.items;
		let e = N.trim().toLowerCase();
		function t(n) {
			if (n.type === "file") return n.name.toLowerCase().includes(e) ? n : null;
			if (n.type === "dir" && n.children) {
				let r = n.name.toLowerCase().includes(e), i = n.children.map(t).filter(Boolean);
				if (r || i.length > 0) return {
					...n,
					children: r ? n.children : i
				};
			}
			return null;
		}
		return D.items.map(t).filter(Boolean);
	}, [D, N]);
	return /* @__PURE__ */ _("div", {
		className: "box-workspace-page",
		children: [j && /* @__PURE__ */ g(o, { children: j }), /* @__PURE__ */ _("div", {
			className: "box-sheet",
			children: [/* @__PURE__ */ g("section", {
				className: "md-card md-card--outlined box-card-pane",
				children: /* @__PURE__ */ _("div", {
					className: "md-card__body",
					children: [/* @__PURE__ */ _("div", {
						className: "box-pane-header",
						children: [/* @__PURE__ */ _("div", {
							className: "md-row",
							style: { alignItems: "center" },
							children: [/* @__PURE__ */ _("div", {
								className: "md-spacer",
								style: {
									display: "flex",
									alignItems: "center",
									gap: 6,
									fontWeight: 600,
									fontSize: 14
								},
								children: [/* @__PURE__ */ g(b, {
									icon: "folder_open",
									className: "box-icon-folder"
								}), /* @__PURE__ */ g("span", {
									title: D?.path,
									style: {
										overflow: "hidden",
										textOverflow: "ellipsis",
										whiteSpace: "nowrap",
										maxWidth: 190
									},
									children: D?.root || "Workspace"
								})]
							}), /* @__PURE__ */ g(c, {
								icon: "refresh",
								label: "Làm mới",
								onClick: () => S(() => J(!1), "Đã làm mới"),
								disabled: T
							})]
						}), /* @__PURE__ */ g(d, {
							placeholder: "Tìm kiếm tệp...",
							value: N,
							onChange: P,
							leadingIcon: "search",
							trailingIcon: N ? "close" : null,
							onTrailingIconClick: () => P("")
						})]
					}), /* @__PURE__ */ g("div", {
						className: "box-tree-scroll",
						children: k ? /* @__PURE__ */ g(l, {}) : E?.configured ? $.length === 0 ? /* @__PURE__ */ g(a, {
							icon: "search_off",
							title: N ? "Không tìm thấy" : "Thư mục trống"
						}) : $.map((e) => /* @__PURE__ */ g(w, {
							item: e,
							depth: 0,
							selectedPath: L?.path,
							onSelect: X,
							openDirs: F,
							onToggleDir: Z,
							onOpenExternal: Q,
							now: K
						}, e.path)) : /* @__PURE__ */ g(a, {
							icon: "folder_open",
							title: "Chưa có thư mục"
						})
					})]
				})
			}), /* @__PURE__ */ g("section", {
				className: "md-card md-card--outlined box-card-pane",
				children: /* @__PURE__ */ g("div", {
					className: "md-card__body",
					children: L ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("div", {
						className: "box-pane-header",
						style: {
							borderBottom: "1px solid var(--md-sys-color-outline-variant, #e0e0e0)",
							paddingBottom: 10
						},
						children: [/* @__PURE__ */ _("div", {
							className: "md-row",
							style: {
								alignItems: "flex-start",
								justifyContent: "space-between"
							},
							children: [/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ _("div", {
								style: {
									display: "flex",
									alignItems: "center",
									gap: 8,
									fontSize: 16,
									fontWeight: 600
								},
								children: [/* @__PURE__ */ g(b, {
									icon: x[z?.category || L.category]?.icon || "draft",
									className: x[z?.category || L.category]?.className
								}), /* @__PURE__ */ g("span", { children: L.name })]
							}), /* @__PURE__ */ _("div", {
								className: "md-body-small md-muted",
								style: {
									display: "flex",
									flexWrap: "wrap",
									gap: 10,
									marginTop: 4
								},
								children: [
									/* @__PURE__ */ _("span", { children: ["Đường dẫn: ", /* @__PURE__ */ g("code", { children: L.path })] }),
									/* @__PURE__ */ g("span", { children: "•" }),
									/* @__PURE__ */ _("span", { children: ["Dung lượng: ", v(z?.size ?? L.size)] }),
									L.mtime && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("span", { children: "•" }), /* @__PURE__ */ _("span", { children: ["Cập nhật: ", y(L.mtime)] })] })
								]
							})] }), /* @__PURE__ */ g(i, {
								variant: "tonal",
								icon: "open_in_new",
								onClick: () => Q(L.path),
								disabled: T,
								title: "Mở tệp bằng phần mềm tương ứng trên máy tính",
								children: "Mở app ngoài"
							})]
						}), z?.isText && /* @__PURE__ */ g("div", {
							className: "md-row",
							style: {
								alignItems: "center",
								marginTop: 4
							},
							children: z.isMarkdown ? /* @__PURE__ */ g(u, {
								value: W,
								onChange: G,
								options: [[
									"preview",
									"Xem trước (Preview)",
									"visibility"
								], [
									"raw",
									"Văn bản thô (Text)",
									"code"
								]]
							}) : /* @__PURE__ */ g("div", {
								className: "md-body-small md-muted",
								children: "Hiển thị nội dung văn bản thô"
							})
						})]
					}), /* @__PURE__ */ g("div", {
						className: "box-content-scroll",
						children: te ? /* @__PURE__ */ g(l, {}) : H ? /* @__PURE__ */ g(o, { children: H }) : z?.isText ? W === "preview" && z.isMarkdown ? /* @__PURE__ */ g(C, { content: z.content }) : /* @__PURE__ */ g("pre", {
							className: "box-raw-viewer",
							children: /* @__PURE__ */ g("code", { children: z.content })
						}) : /* @__PURE__ */ _("div", {
							className: "box-binary-card",
							children: [
								/* @__PURE__ */ g("div", {
									className: "box-binary-card__icon",
									children: /* @__PURE__ */ g(b, {
										icon: x[z?.category || L.category]?.icon || "draft",
										className: x[z?.category || L.category]?.className,
										style: {
											fontSize: 64,
											width: 64,
											height: 64
										}
									})
								}),
								/* @__PURE__ */ g("div", {
									style: {
										fontSize: 18,
										fontWeight: 600
									},
									children: x[z?.category || L.category]?.label || "Tập tin nhị phân"
								}),
								/* @__PURE__ */ g("p", {
									className: "md-muted",
									style: {
										maxWidth: 480,
										margin: 0
									},
									children: "Định dạng tệp này không hỗ trợ hiển thị trực tiếp dưới dạng văn bản. Bạn có thể mở tệp trực tiếp bằng phần mềm mặc định trên máy tính của bạn (Microsoft Excel, Word, Adobe Acrobat...)."
								}),
								/* @__PURE__ */ g("div", {
									style: { marginTop: 12 },
									children: /* @__PURE__ */ g(i, {
										variant: "filled",
										icon: "open_in_new",
										onClick: () => Q(L.path),
										disabled: T,
										children: "Mở bằng ứng dụng mặc định"
									})
								})
							]
						})
					})] }) : /* @__PURE__ */ g("div", {
						style: {
							display: "flex",
							alignItems: "center",
							justifyContent: "center",
							height: "100%"
						},
						children: /* @__PURE__ */ g(a, {
							icon: "description",
							title: "Chưa chọn tệp",
							children: /* @__PURE__ */ g("div", {
								className: "md-muted",
								children: "Chọn một tệp từ cây thư mục bên trái để xem nội dung hoặc mở ứng dụng."
							})
						})
					})
				})
			})]
		})]
	});
}
export { T as default };
