## Box

Không gian làm việc cho các tệp đồng bộ từ Box Drive (ví dụ: các tệp kịch bản, prompt, dữ liệu xuất từ Microsoft Copilot Studio Agent).

### Cách sử dụng

1. **Cấu hình thư mục**: Bấm nút **Cài đặt** ở góc trên bên phải, chọn thư mục Box đã đồng bộ trên máy tính của bạn (ví dụ `~/Box/CopilotStudioExports`).
2. **Cây thư mục**: Cột bên trái hiển thị toàn bộ cây thư mục và tệp tin trong thư mục Box. Bạn có thể mở rộng/thu gọn thư mục và tìm kiếm nhanh tệp theo tên.
3. **Tự động nhận diện tệp mới**: Khi Copilot Studio xuất tệp mới về Box Drive, addon sẽ tự động cập nhật danh sách tệp theo tần suất đã chọn trong Cài đặt và gắn huy hiệu **Mới**. Bạn cũng có thể bấm nút **Làm mới** bất cứ lúc nào.
4. **Xem tệp Markdown (`.md`)**: Chọn tệp để xem nội dung ở 2 chế độ:
   - **Xem trước (Preview)**: Hiển thị văn bản định dạng đẹp mắt với tiêu đề, danh sách, khối mã và bảng biểu.
   - **Văn bản thô (Text)**: Xem trực tiếp mã nguồn văn bản thô kèm số dòng.
5. **Mở tệp Office và nhị phân (Excel, Word, PDF...)**:
   - Khi chọn các tệp `.xlsx`, `.docx`, `.pdf`, trang sẽ hiển thị thông tin tệp và nút **Mở bằng ứng dụng mặc định**.
   - Bấm nút này hoặc bấm đúp vào tệp ở cây thư mục để mở tệp trực tiếp trong Microsoft Excel, Word hoặc ứng dụng tương ứng trên máy tính của bạn.

### Tool cho AI

| Tool | Làm gì |
|---|---|
| `box_list_files` | Liệt kê tất cả tệp trong thư mục Box Workspace kèm đường dẫn tương đối và kích thước |
| `box_read_file` | Đọc toàn bộ nội dung của một tệp văn bản/markdown theo đường dẫn |
