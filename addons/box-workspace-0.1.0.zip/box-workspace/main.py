"""Box Workspace Addon for Viewer Hub (managed, Python).

Allows viewing Copilot Studio exports and files from a local Box sync folder:
- Recursive directory tree view
- Markdown preview and raw text modes
- Open non-plain-text files (Excel, Word, PDF, etc.) using system default app
- Real-time background watcher with Long-Polling for instant updates
- Read-only MCP tools for AI
"""
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

from viewer_hub.addons.sdk import Addon, ApiError, ToolError, decode_text

addon = Addon("box", title="Box Workspace", instructions="Read-only access to files in the configured Box Workspace directory.")

TEXT_EXTENSIONS = {
    ".md", ".markdown", ".txt", ".json", ".yaml", ".yml",
    ".csv", ".tsv", ".xml", ".html", ".css", ".js", ".mjs",
    ".ts", ".py", ".sh", ".sql", ".log", ".env.example", ".conf"
}

CATEGORY_MAP = {
    ".xlsx": "excel", ".xls": "excel", ".xlsm": "excel", ".xlsb": "excel",
    ".docx": "word", ".doc": "word",
    ".pptx": "powerpoint", ".ppt": "powerpoint",
    ".pdf": "pdf",
    ".zip": "archive", ".tar": "archive", ".gz": "archive", ".7z": "archive", ".rar": "archive",
    ".png": "image", ".jpg": "image", ".jpeg": "image", ".gif": "image", ".webp": "image", ".svg": "image",
    ".mp3": "audio", ".wav": "audio", ".mp4": "video", ".mov": "video"
}

MAX_TEXT_SIZE = 10 * 1024 * 1024  # 10 MB limit for text preview

# Thread-safe background watcher state
_watcher_lock = threading.Lock()
_last_change_time: float = time.time()
_change_event = threading.Event()
_last_scan_snapshot: tuple[float, int] = (0.0, 0)


def _get_workspace_root() -> Path | None:
    settings = addon.settings()
    configured = settings.get("workspacePath")
    if not configured:
        return None
    raw = str(configured).strip()
    if not raw:
        return None
    expanded = os.path.expanduser(raw)
    resolved = Path(expanded).resolve()
    return resolved


def _resolve_safe(root: Path, relative_path: str) -> Path:
    clean = relative_path.strip().lstrip("/").replace("\\", "/")
    target = (root / clean).resolve()
    if not target.is_relative_to(root):
        raise ApiError("access_denied", "Đường dẫn không hợp lệ (nằm ngoài thư mục workspace)", 403)
    return target


def _file_category(ext: str) -> str:
    if ext in {".md", ".markdown"}:
        return "markdown"
    if ext in {".json", ".yaml", ".yml", ".py", ".js", ".mjs", ".ts", ".sh", ".sql", ".xml"}:
        return "code"
    if ext in TEXT_EXTENSIONS:
        return "text"
    return CATEGORY_MAP.get(ext, "other")


def _scan_meta_recursive(dir_path: Path) -> tuple[float, int]:
    """Fast recursive scan returning (latest_mtime, file_count)."""
    max_mtime = 0.0
    count = 0
    stack = [dir_path]

    while stack:
        curr = stack.pop()
        try:
            with os.scandir(curr) as it:
                for entry in it:
                    if entry.name.startswith("."):
                        continue
                    try:
                        stat = entry.stat()
                        if entry.is_dir(follow_symlinks=False):
                            stack.append(Path(entry.path))
                            max_mtime = max(max_mtime, stat.st_mtime)
                        elif entry.is_file(follow_symlinks=False):
                            count += 1
                            max_mtime = max(max_mtime, stat.st_mtime)
                    except (OSError, PermissionError):
                        continue
        except (OSError, PermissionError):
            continue

    return max_mtime, count


def _background_watcher():
    """Background thread watching Box folder for changes."""
    global _last_change_time, _last_scan_snapshot

    while True:
        time.sleep(1.0)
        try:
            root = _get_workspace_root()
            if not root or not root.is_dir():
                continue

            latest_mtime, count = _scan_meta_recursive(root)
            with _watcher_lock:
                prev_mtime, prev_count = _last_scan_snapshot
                if (latest_mtime, count) != (prev_mtime, prev_count) and prev_count > 0:
                    # Debounce 400ms for Box Drive write completion
                    time.sleep(0.4)
                    final_mtime, final_count = _scan_meta_recursive(root)
                    _last_scan_snapshot = (final_mtime, final_count)
                    _last_change_time = time.time()
                    _change_event.set()
                    _change_event.clear()
                else:
                    _last_scan_snapshot = (latest_mtime, count)
        except Exception:
            pass


# Start the background watcher thread
_watcher_thread = threading.Thread(target=_background_watcher, daemon=True)
_watcher_thread.start()


def _build_tree(root: Path, current: Path) -> list[dict]:
    items = []
    try:
        entries = sorted(list(current.iterdir()), key=lambda e: (not e.is_dir(), e.name.lower()))
    except (OSError, PermissionError):
        return []

    for entry in entries:
        if entry.name.startswith("."):
            continue

        try:
            stat = entry.stat()
        except (OSError, PermissionError):
            continue

        rel_path = entry.relative_to(root).as_posix()
        ext = entry.suffix.lower()

        if entry.is_dir():
            children = _build_tree(root, entry)
            items.append({
                "name": entry.name,
                "path": rel_path,
                "type": "dir",
                "mtime": stat.st_mtime,
                "children": children
            })
        elif entry.is_file():
            is_text = ext in TEXT_EXTENSIONS
            is_md = ext in {".md", ".markdown"}
            items.append({
                "name": entry.name,
                "path": rel_path,
                "type": "file",
                "ext": ext,
                "size": stat.st_size,
                "mtime": stat.st_mtime,
                "isText": is_text,
                "isMarkdown": is_md,
                "category": _file_category(ext)
            })
    return items


@addon.get("/workspace")
def get_workspace(_request):
    root = _get_workspace_root()
    if not root:
        return {
            "configured": False,
            "path": "",
            "exists": False,
            "name": ""
        }
    return {
        "configured": True,
        "path": str(root),
        "exists": root.is_dir(),
        "name": root.name or str(root)
    }


@addon.get("/tree")
def get_tree(_request):
    root = _get_workspace_root()
    if not root:
        raise ApiError("not_configured", "Chưa cấu hình đường dẫn thư mục Box trong phần Cài đặt", 400)
    if not root.is_dir():
        raise ApiError("folder_not_found", f"Thư mục không tồn tại: {root}", 404)

    items = _build_tree(root, root)

    def count_and_latest(node_list: list[dict]) -> tuple[int, float]:
        total = 0
        latest = 0.0
        for node in node_list:
            if node["type"] == "file":
                total += 1
                latest = max(latest, node.get("mtime", 0.0))
            elif node["type"] == "dir":
                sub_total, sub_latest = count_and_latest(node.get("children", []))
                total += sub_total
                latest = max(latest, sub_latest)
        return total, latest

    total_files, latest_mtime = count_and_latest(items)

    return {
        "root": root.name or str(root),
        "path": str(root),
        "items": items,
        "totalFiles": total_files,
        "latestMtime": latest_mtime
    }


@addon.get("/wait-change")
def wait_change(request):
    root = _get_workspace_root()
    if not root or not root.is_dir():
        return {"changed": False, "changeTime": time.time(), "configured": False}

    try:
        since_time = float(request.query.get("last_time", 0.0))
    except (ValueError, TypeError):
        since_time = 0.0

    with _watcher_lock:
        current_time = _last_change_time

    if current_time > since_time:
        return {"changed": True, "changeTime": current_time}

    # Wait up to 25s for changes
    woken = _change_event.wait(timeout=25.0)
    with _watcher_lock:
        latest = _last_change_time
    return {"changed": woken or (latest > since_time), "changeTime": latest}


@addon.get("/file")
def get_file(request):
    root = _get_workspace_root()
    if not root:
        raise ApiError("not_configured", "Chưa cấu hình đường dẫn thư mục Box", 400)

    rel_path = request.query.get("path", "")
    if not rel_path:
        raise ApiError("missing_path", "Thiếu tham số path", 400)

    target = _resolve_safe(root, rel_path)
    if not target.is_file():
        raise ApiError("file_not_found", f"Không tìm thấy tệp: {rel_path}", 404)

    stat = target.stat()
    ext = target.suffix.lower()
    is_text = ext in TEXT_EXTENSIONS
    is_md = ext in {".md", ".markdown"}
    category = _file_category(ext)

    if is_text:
        if stat.st_size > MAX_TEXT_SIZE:
            raise ApiError("file_too_large", f"Tệp văn bản quá lớn (> 10MB) để hiển thị trong trình duyệt", 400)
        try:
            raw_bytes = target.read_bytes()
            content, encoding = decode_text(raw_bytes, name=target.name)
        except Exception as exc:
            raise ApiError("read_error", f"Lỗi đọc tệp: {exc}", 500)

        return {
            "name": target.name,
            "path": rel_path,
            "size": stat.st_size,
            "mtime": stat.st_mtime,
            "isText": True,
            "isMarkdown": is_md,
            "category": category,
            "content": content,
            "encoding": encoding,
            "ext": ext
        }

    return {
        "name": target.name,
        "path": rel_path,
        "size": stat.st_size,
        "mtime": stat.st_mtime,
        "isText": False,
        "isMarkdown": False,
        "category": category,
        "ext": ext
    }


@addon.post("/open-external")
def open_external(request):
    root = _get_workspace_root()
    if not root:
        raise ApiError("not_configured", "Chưa cấu hình đường dẫn thư mục Box", 400)

    rel_path = (request.body or {}).get("path", "")
    if not rel_path:
        raise ApiError("missing_path", "Thiếu đường dẫn tệp cần mở", 400)

    target = _resolve_safe(root, str(rel_path))
    if not target.exists():
        raise ApiError("file_not_found", f"Không tìm thấy tệp: {rel_path}", 404)

    try:
        if sys.platform == "win32":
            os.startfile(str(target))
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(target)])
        else:
            subprocess.Popen(["xdg-open", str(target)])
    except Exception as exc:
        raise ApiError("open_failed", f"Không thể mở ứng dụng mặc định: {exc}", 500)

    return {
        "ok": True,
        "opened": target.name,
        "message": f"Đã gửi lệnh mở {target.name} bằng ứng dụng mặc định"
    }


@addon.tool("box_list_files", "List files in the Box Workspace directory, showing relative path, size and modification time.")
def box_list_files(_arguments):
    root = _get_workspace_root()
    if not root or not root.is_dir():
        return "Box workspace is not configured or the folder does not exist."

    lines = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not d.startswith(".")]
        for f in filenames:
            if f.startswith("."):
                continue
            full = Path(dirpath) / f
            try:
                rel = full.relative_to(root).as_posix()
                size = full.stat().st_size
                lines.append(f"{rel} ({size} bytes)")
            except (OSError, PermissionError):
                continue

    if not lines:
        return "Workspace folder is empty."
    return "\n".join(sorted(lines))


@addon.tool("box_read_file", "Read text content of a file (markdown, txt, json, etc.) by relative path.",
            {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]})
def box_read_file(arguments):
    root = _get_workspace_root()
    if not root or not root.is_dir():
        raise ToolError("Box workspace is not configured or folder does not exist.")

    rel_path = str(arguments.get("path") or "").strip()
    if not rel_path:
        raise ToolError("Missing 'path' argument.")

    try:
        target = _resolve_safe(root, rel_path)
    except ApiError as exc:
        raise ToolError(exc.message)

    if not target.is_file():
        raise ToolError(f"File not found: {rel_path}")

    ext = target.suffix.lower()
    if ext not in TEXT_EXTENSIONS:
        raise ToolError(f"File '{target.name}' is a binary file ({ext}) and cannot be read as text.")

    try:
        data = target.read_bytes()
        text, _ = decode_text(data, name=target.name)
        return text
    except Exception as exc:
        raise ToolError(f"Failed to read file: {exc}")


if __name__ == "__main__":
    addon.run()
